# Direct Vertex V25.0 — Native Probability Integration

V25 persists the actual V22 composite probability on each recorded signal and validates it against settled WIN/LOSS outcomes only. V21's settled-outcome posterior is blended conservatively with V22 confidence according to learning reliability.

Metrics: Brier score, log loss, ECE, reliability bins, threshold coverage, selected win rate.

This is an analysis/research assistant. It does not log into Quotex, click buttons, place orders, or automate trading. Minimum 30 settled decisive samples are required before true reliability validation is considered meaningful.
