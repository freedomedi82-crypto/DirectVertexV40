# Direct Vertex V24.0 — Calibration & Probability Layer

V24 adds probability calibration diagnostics on settled replay outcomes:
- Brier score
- log loss
- Expected Calibration Error (ECE)
- reliability score
- probability buckets
- conservative abstention threshold selection
- coverage and win rate above the threshold

The UI connects V24 to the V23 replay report. The current replay adapter uses a conservative fixed confidence proxy for each directional decision; this is intentionally a diagnostic bridge, not a claim that the live model is perfectly calibrated. A future integration should feed the native V20/V21 probability directly.

No auto-trading, browser automation, login/session extraction, or order execution is included.
