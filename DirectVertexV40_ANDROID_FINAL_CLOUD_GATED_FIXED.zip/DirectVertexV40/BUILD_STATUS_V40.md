# Direct Vertex V40 — Build Status

## Verified in this environment
- Source tree present and unpacked successfully.
- `gradlew` executable present.
- Static project structure inspected.
- Android Gradle Plugin pinned to 8.13.2.
- Gradle pinned to 8.13 in CI.
- JDK pinned to 17 in CI/toolchain.
- compileSdk/targetSdk 36.
- Build Tools 35.0.0.
- CI contains a hard APK existence/size check and SHA-256 generation.

## Not verified in this sandbox
- A real Android APK binary has **not** been compiled here because this execution environment does not provide Android SDK and cannot resolve `services.gradle.org` for Gradle bootstrap.
- Device installation/runtime tests have therefore not been performed here.

## Definition of VERIFIED
V40 may be called **APK VERIFIED** only after a CI/local build produces:
`app/build/outputs/apk/debug/app-debug.apk`
and the verification step succeeds with a non-empty APK plus SHA-256.
