# DirectVertex V36 — Decision Integrity

V36 is the final abstention layer after V35. It uses settled-only directional evidence, Bayesian shrinkage toward global evidence, optional sufficiently-large regime evidence, recent-direction health, payout-adjusted break-even, and a Wilson 95% lower-bound uncertainty penalty.

Decision chain: V22 → V25 → V26 → V27 → V32 → V35 → V36 → final indicator.

V36 never creates a signal that upstream layers did not admit. It only preserves CALL/PUT when evidence is sufficient or returns WAIT.

Analysis-only: no broker login, session extraction, browser automation, auto-clicking, order execution, or bypassing platform protections.

Validation must remain chronological and out-of-sample; point win-rate alone is insufficient.
