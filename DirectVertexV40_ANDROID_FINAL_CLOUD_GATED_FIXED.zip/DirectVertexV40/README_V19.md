# Direct Vertex V19.0 — Adaptive Regime Simulator

V19 stress-tests the research stack across synthetic but deterministic market regimes:
- baseline
- up trend
- down trend
- range
- high volatility
- transition

It reports:
- scenario pass rate
- regime coverage
- worst-case scenario score
- overall robustness score
- ROBUST / PROMISING / FRAGILE / INCONCLUSIVE verdict

The simulator is deliberately conservative and is not a profitability guarantee.
It is analysis/research only and does not execute or automate Quotex trades.
