# DirectVertex V38 — Precision Profile

V38 applies a precision-first evidence profile. It is intentionally conservative: it increases independent evidence requirements, recent evidence requirements, Wilson lower-bound requirements, posterior requirements, and recent directional performance requirements.

This is a configuration hardening, not proof of profitability. The champion profile must be validated on untouched chronological OOS data. Forex data is a control dataset only and is not evidence for Quotex OTC.
