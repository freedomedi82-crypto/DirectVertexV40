# Direct Vertex V22.0 — Full Pipeline Integration & Verification

V22 stops adding isolated research layers and makes the live analysis path deterministic:

Camera/Visual Sonar → temporal smoothing → SignalEngine → AdaptiveEngine → V21 Learning → V20 Decision Intelligence → V22 verification/final WAIT filter.

## V22 additions
- `V22PipelineEngine.kt` as the single final analysis gate.
- Explicit data/vision/calibration/drift verification flags.
- Conservative forced-WAIT conditions for unstable data, missing calibration, or learning cooldown.
- V21 calibration remains outcome-only and ignores pending observations.
- UI exposes pipeline health and verification issues.
- Version 22.0.0 / code 220.

## Important
This remains an analysis/signal assistant. It does not log into Quotex, click buttons, place orders, extract session tokens, or bypass platform protections.

The source package is not an APK. Build with Android Studio/Gradle in an environment with the Android SDK installed.
