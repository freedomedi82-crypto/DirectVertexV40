# DirectVertex V39 — Champion Precision Android

V39 is the production candidate built around precision-first abstention.

Pipeline: V22 → V25 → V26 → V27 → V32 → V35 → V36 → V38 → V39.

V39 is a final **reject-only** gate. It cannot create CALL/PUT; it can only preserve a direction that already passed earlier gates or convert it to WAIT.

Default champion thresholds:
- probability >= 72%
- quality >= 78%
- independent evidence >= 24
- recent independent evidence >= 10
- posterior >= 62%
- Wilson lower 95% >= 54%
- recent win rate >= 58%
- independence ratio >= 35%

These are conservative research defaults, not a guarantee of profitability or accuracy. They must be validated on untouched chronological OOS data before being called optimal.

The application is analysis/signal assistance only. It does not log into Quotex, extract session tokens, automate clicks, or execute trades.

Android builds use the Gradle/Android Gradle Plugin system. See official Android documentation for build and release requirements.
