# V40 final build policy

The canonical build path is `.github/workflows/v40-final-gate.yml`.

A V40 build may only be described as **APK VERIFIED** when all three gates are green:

- APK binary exists and passes structural/hash checks.
- APK installs and launches on the CI Android emulator.
- A `V40_APK_VERIFIED.txt` report is produced and uploaded together with the APK and SHA-256.

No claim of APK verification should be made from static source inspection alone.
