
## V30.0
True end-to-end chronological replay using the actual ReplayEngine + SignalEngine, with V29 data gating and leakage checks.

## V29.0
Market Data Integrity & Market-Specific Calibration gate. Validates timestamps/prices, sampling continuity, return jumps, data coverage and derives an expiry-step calibration from the observed median sampling interval. Research/analysis only; no automatic order execution.
# Direct Vertex V12.0 Android

Offline visual signal analysis and research/backtest assistant.

V12 adds regime-aware rolling out-of-sample validation with a purge gap, conservative probability calibration, cross-window consistency and maximum losing streak reporting.

This project does not execute orders, automate Quotex, extract sessions, or bypass platform protections.

Replay CSV format:
`timestamp,price`

## V13 Research Lab
- Menggabungkan V12 purged walk-forward, multi-window robustness, ensemble, optimizer, dan statistical validation.
- Stress testing score threshold, expiry, serta blok periode awal/akhir.
- Research verdict: ROBUST / PROMISING / FRAGILE / OVERFIT RISK / INCONCLUSIVE.
- Menampilkan evidence score, stress pass rate, dan worst stress drop.
- Offline research only; tidak melakukan auto-trading atau mengirim order ke Quotex.


## V26.0 — Confidence-Aware Signal Governor
V26 applies calibrated probability, learning reliability, calibration error, drift, sample-size and evidence-agreement gates to the final analysis signal. The governor is conservative and can only abstain to WAIT; it does not execute orders.

Key safeguards:
- Minimum 30 settled calibration samples.
- Blocks fragile/inconclusive calibration.
- Blocks excessive ECE and low learning reliability.
- Blocks high drift / learning cooldown.
- Blocks low evidence agreement and below-threshold probability.
- CALL/PUT is admitted only when every gate passes.


## V28.0 — Walk-Forward Production Verification
Strict out-of-sample rolling verification. Each test decision is generated using only observations available before that decision timestamp. Includes fold-level WR, coverage, losing streak, leakage checks, and conservative verdicts. Research/replay only; no broker automation or order execution.


V32 adds an entry-quality/anti-chase gate and OOS baseline-vs-gated comparison.


## V35.0 — Research Integrity Upgrade
- V24/V25 calibration and probability thresholds are selected only on earlier chronological calibration data and evaluated on a later untouched test slice.
- Adds Wilson 95% confidence intervals to thresholded results.
- Removes the misleading V27 cooldown field semantics; session loss limits are explicit session blocks.
- Adds `V35WalkForwardQualityAudit`: multi-fold chronological OOS with warm-up, calibration, purge gap, untouched test, fold stability, coverage, and uncertainty.
- Market-only OHLC audits are explicitly labeled as proxies; they do not establish equivalence to Quotex OTC or the camera/ML Kit visual stream.
- No login/session extraction, browser automation, order execution, or protection bypass.


## V35
Temporal consensus + payout-adjusted expectancy gate ditambahkan setelah V32. Lihat README_V35.md.

## V37
V37 adds independence-adjusted evidence quality and conservative abstention after V36. See README_V37.md.
