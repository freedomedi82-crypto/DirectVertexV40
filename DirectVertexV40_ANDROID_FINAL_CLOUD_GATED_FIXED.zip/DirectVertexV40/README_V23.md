# Direct Vertex V23.0

## End-to-End Replay Verification

V23 adds an offline verification harness that replays a timestamped price series without looking ahead. At each decision point it uses only prices available up to that point, then evaluates the outcome after the configured number of replay steps.

### Metrics
- decisions and coverage
- wins/losses/draws
- win rate on settled outcomes
- maximum losing streak
- leakage-free verification flag
- conservative verdict: READY / USABLE / FRAGILE / INCONCLUSIVE

This is a research/verification diagnostic, not a profitability guarantee. It does not connect to Quotex execution and performs no automatic orders or clicks.
