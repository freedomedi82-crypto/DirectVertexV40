# Direct Vertex V14.0 — Live Signal Intelligence

V14 adds a live analysis layer on top of the existing Direct Vertex research/validation stack.

## Added
- Multi-factor live confirmation
- Momentum confirmation
- Dynamic support/resistance proximity filter
- Basic candle-sequence pattern recognition
- Confidence thresholding
- WAIT filtering when factors disagree

## Safety
This project is an analysis/signal assistant. It does not log into Quotex, automate clicks,
execute orders, extract session tokens, or bypass platform protections.

## Build
Open the Gradle project in Android Studio and sync/build with the Android SDK installed.
