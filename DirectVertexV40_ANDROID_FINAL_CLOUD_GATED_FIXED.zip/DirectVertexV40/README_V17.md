# Direct Vertex V17.0 — Autonomous Backtest & Model Selection Lab

V17 automatically evaluates parameter configurations with rolling
train/validation/test folds and rejects unstable candidates.

Outputs:
- selected configuration
- out-of-sample fold results
- stability
- stress/quality pass rate
- worst-fold performance
- robustness score
- verdict: ROBUST / PROMISING / FRAGILE / OVERFIT RISK / INCONCLUSIVE

Important:
This is a research/backtesting assistant. It is not a profitability guarantee.
It does not execute Quotex trades or automate platform interaction.
