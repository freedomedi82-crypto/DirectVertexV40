# Direct Vertex V30.0 — True End-to-End Walk-Forward

V30 replays the actual `ReplayEngine` + `SignalEngine` chronologically instead of using a separate baseline model. At decision index `i`, only observations through `i` are available; the expiry outcome at `i+h` is evaluated afterward.

Includes: V29 data gate, fresh engine per fold, fold-level W/L/D, win rate, coverage, maximum losing streak, and leakage audit.

This remains a research/analysis assistant. It does not log in to Quotex, click buttons, submit orders, size positions, or bypass platform protections.

V30 is an evaluation harness, not proof of future profitability.
