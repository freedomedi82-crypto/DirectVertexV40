# Direct Vertex V40 — Build & Install

## Recommended build

Use Android Studio with JDK 17, Android SDK Platform 36 and Build Tools 35.0.0.

Then run:

```bash
gradle :app:assembleDebug
```

The installable artifact is:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## CI build

The repository contains `.github/workflows/android.yml`. It provisions:

- JDK 17
- Gradle 8.13
- Android SDK Platform 36
- Android Build Tools 35.0.0

The workflow fails unless the APK exists and is non-empty, and publishes the APK plus SHA-256 checksum.

## Device installation

With ADB enabled:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Or copy the APK to the Android device and open it to install it manually.

## Important

A successful source/configuration check is not the same as a successful APK compilation. V40 is only considered **compiled** when a build environment produces `app-debug.apk` and the artifact verification step passes.
