# Direct Vertex V15.0 — Adaptive Vision Engine

V15 adds a robust temporal vision layer before signal generation.

Features:
- weighted multi-frame stabilization
- rejection of low-quality frames
- rejection of implausible chart-Y jumps
- weighted OCR-price stabilization
- short-term trend/momentum estimate
- visual volatility estimate
- frame-quality confidence
- accepted/rejected frame counters

This remains an analysis/signal assistant. It does not automate Quotex,
click buttons, place orders, extract session tokens, or bypass platform controls.

Build the Gradle project in Android Studio with the required Android SDK.
