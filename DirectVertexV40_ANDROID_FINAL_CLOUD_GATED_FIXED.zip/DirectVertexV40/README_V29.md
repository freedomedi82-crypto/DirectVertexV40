# Direct Vertex V29.0 — Market Data Integrity & Market-Specific Calibration

V29 is a research/analysis gate placed after the existing V27 safety guard. It does not log in to Quotex, automate the browser, click trades, submit orders, or bypass platform protections.

## What V29 adds
- Valid-price and timestamp integrity checks.
- Duplicate and non-monotonic timestamp detection.
- Sampling-interval median and coefficient of variation (CV).
- Return-magnitude diagnostics: median, P95, maximum and jump count.
- A data coverage score combining continuity, uniqueness, validity and jump stability.
- Expiry calibration from the observed median sampling interval instead of blindly assuming one row equals one fixed duration.
- A clear gate: `READY`, `USABLE`, `FRAGILE`, or `BLOCKED`.

## Interpretation
V29 does not claim that a clean dataset is profitable. It only answers whether the replay data is structurally suitable for downstream research and what replay-step horizon corresponds approximately to the requested wall-clock expiry.

`READY` is deliberately strict. A `FRAGILE` or `BLOCKED` result should be treated as a reason to collect/clean more data rather than a reason to loosen thresholds.
