# DirectVertex V35 — Temporal Consensus & Expectancy Gate

V35 menambahkan lapisan abstention setelah V32:

- temporal consensus untuk menolak spike satu-frame;
- minimum persistence sebelum signal menjadi CONFIRMED;
- minimum directional agreement;
- payout-adjusted break-even probability;
- safety edge di atas break-even;
- agregasi probability dan quality dari observasi terbaru;
- WAIT bila bukti tidak cukup.

V35 hanya menghasilkan indikator/rekaman analisis. Tidak ada login Quotex,
session extraction, browser automation, auto-click, order execution, atau bypass.

Default payout riset = 80%; pengguna dapat menganggap ini hanya parameter analisis.
Win-rate tidak dianggap bukti profitabilitas tanpa OOS yang memadai.

## Validation
The V35 engine was syntax-compiled with the project signal/model dependencies and exercised with a smoke test: one-frame spike is rejected; persistent consensus is admitted. Full Android APK compilation still requires the Android/Gradle environment.
