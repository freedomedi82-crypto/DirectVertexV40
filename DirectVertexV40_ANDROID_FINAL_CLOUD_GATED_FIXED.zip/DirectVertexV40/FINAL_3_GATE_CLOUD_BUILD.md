# Direct Vertex V40 — cloud path to the final 3 gates

This project includes `.github/workflows/v40-final-gate.yml`.

It is designed specifically to remove the local sandbox limitation:

1. **Gate 1 — APK binary:** builds `app-debug.apk`, verifies it is non-empty, validates the ZIP structure, and records SHA-256.
2. **Gate 2 — APK install test:** boots an Android emulator, installs the APK with ADB, verifies the package, launches `com.directvertex.v40`, verifies the process is running, and captures a screenshot.
3. **Gate 3 — APK Verified:** writes `V40_APK_VERIFIED.txt` containing the exact APK hash, size, toolchain, emulator API and timestamp, then uploads the APK and evidence as a workflow artifact.

## Run it

1. Create a GitHub repository.
2. Upload the complete `DirectVertexV40` folder contents to the repository root.
3. Open **Actions**.
4. Select **Direct Vertex V40 — Final 3-Gate Verification**.
5. Choose **Run workflow**.
6. Wait for the workflow to finish.
7. If the job is green, download `DirectVertexV40-APK-VERIFIED` from the workflow artifacts.

GitHub-hosted runners can execute workflows in a virtual machine, and workflow artifacts can persist the APK after the run. The Android build itself is performed by Gradle/AGP. See the official Android and GitHub documentation.

## Important distinction

A green Gate 2 verifies installation and launch on the **Android emulator used by CI**. It does not prove compatibility with every physical Android phone. A physical-device test remains an additional hardware validation step.

The workflow does not perform Quotex order execution. The app remains a signal/analysis assistant.
