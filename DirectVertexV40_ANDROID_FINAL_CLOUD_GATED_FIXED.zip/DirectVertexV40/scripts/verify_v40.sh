#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f settings.gradle.kts ]] || fail "settings.gradle.kts missing"
[[ -f app/build.gradle.kts ]] || fail "app/build.gradle.kts missing"
[[ -f gradlew && -x gradlew ]] || fail "gradlew missing or not executable"
grep -q 'com.directvertex.v40' app/build.gradle.kts || fail "namespace/applicationId mismatch"
grep -q 'applicationId = "com.directvertex.v40"' app/build.gradle.kts || fail "applicationId missing"
grep -q 'compileSdk = 36' app/build.gradle.kts || fail "compileSdk mismatch"
grep -q 'targetSdk = 36' app/build.gradle.kts || fail "targetSdk mismatch"
grep -q 'languageVersion = JavaLanguageVersion.of(17)' app/build.gradle.kts || fail "Java 17 toolchain missing"
grep -q 'id("com.android.application") version "8.13.2"' build.gradle.kts || fail "AGP mismatch"
grep -q 'id("org.jetbrains.kotlin.android") version "2.3.21"' build.gradle.kts || fail "Kotlin plugin mismatch"
grep -q 'distributionUrl=.*gradle-8.13-bin.zip' gradle/wrapper/gradle-wrapper.properties || fail 'Gradle 8.13 wrapper missing'
if grep -RInE 'com\.directvertex\.v(3[0-9]|[1-9])\b' app/src/main/java >/dev/null; then fail "legacy package reference found"; fi
if grep -RInE 'TODO|FIXME|NotImplemented' app/src/main/java >/dev/null; then fail "unfinished marker found"; fi
[[ -f app/src/main/AndroidManifest.xml ]] || fail "manifest missing"
[[ -f app/src/main/java/com/directvertex/v40/MainActivity.kt ]] || fail "MainActivity missing"
echo "V40 static build preflight: PASS"
