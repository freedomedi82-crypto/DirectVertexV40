#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
GRADLE_VERSION="8.13"
GRADLE_HOME="${GRADLE_HOME:-$ROOT/.gradle-dist/gradle-${GRADLE_VERSION}}"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  mkdir -p "$ROOT/.gradle-dist"
  tmp="$ROOT/.gradle-dist/gradle-${GRADLE_VERSION}.zip"
  echo "Gradle ${GRADLE_VERSION} not found; downloading from services.gradle.org..."
  curl -fL --retry 3 -o "$tmp" "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
  rm -rf "$GRADLE_HOME"
  unzip -q "$tmp" -d "$ROOT/.gradle-dist"
  rm -f "$tmp"
fi
"$GRADLE_HOME/bin/gradle" :app:assembleDebug --stacktrace
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
sha256sum "$APK"
echo "APK: $APK"
