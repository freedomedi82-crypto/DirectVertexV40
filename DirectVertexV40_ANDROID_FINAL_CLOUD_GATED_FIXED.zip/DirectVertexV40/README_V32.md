# Direct Vertex V32.0 — Entry Quality & Anti-Chase Gate

V32 focuses on **entry precision**, not increasing the number of signals. It adds a conservative Entry Quality Gate that evaluates momentum alignment, trend alignment, virtual-candle direction, acceleration, available room before the local boundary, volatility quality, and temporal sample stability.

The live pipeline is now:
Camera/Visual Sonar → Temporal → SignalEngine → Adaptive → V21 → V22 → V25 → V26 → V27 → **V32 Entry Gate** → final WAIT/CALL/PUT.

A candidate can only be admitted when its probability and entry-quality requirements pass. Weak or late entries are converted to WAIT. The gate never creates a new direction.

V32 also includes a chronological replay comparison between baseline SignalEngine decisions and the gated decisions. It reports baseline WR, gated WR, coverage, rejected entries, fold details and an OOS verdict. This is intended to test whether the gate actually improves entry precision rather than assuming it does.

Important: a higher win rate can come from taking fewer trades. Therefore V32 must be evaluated together with coverage and sample size. No profitability guarantee is implied.

Analysis/research only. No Quotex order execution, browser automation, session extraction, auto-clicking, or platform protection bypass.


V33 patch: explicit boundary handling and leakage-aware quality audit.
