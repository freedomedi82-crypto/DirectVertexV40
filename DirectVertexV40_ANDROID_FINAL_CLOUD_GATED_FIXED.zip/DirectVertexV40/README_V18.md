# Direct Vertex V18.0 — Market Replay & Calibration Studio

V18 adds a dataset-quality gate before model selection.

It checks:
- timestamp ordering and continuity
- duplicate observations
- valid positive prices
- coverage
- rolling market windows
- trend/volatility characterization
- deterministic index-to-price calibration diagnostics

Verdicts:
READY / USABLE / FRAGILE DATA / INCONCLUSIVE

This is a research and signal-analysis component only.
It does not automate Quotex, click buttons, place orders, or bypass controls.
