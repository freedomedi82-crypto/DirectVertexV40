#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if ! command -v java >/dev/null 2>&1; then echo "ERROR: JDK 17+ required"; exit 2; fi
JAVA_MAJOR="$(java -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -1)"
if [ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 17 ]; then echo "ERROR: JDK 17+ required"; exit 2; fi
if command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug --stacktrace
else
  echo "ERROR: Gradle is not installed in this environment."
  echo "Use Android Studio or install Gradle 8.13, then run: gradle :app:assembleDebug"
  exit 3
fi
APK="app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || { echo "ERROR: APK not found: $APK"; exit 4; }
sha256sum "$APK"
echo "BUILD PASS: $APK"
