# Direct Vertex V20.0 — Decision Intelligence Core

V20 is the conservative final decision gate for the Direct Vertex research stack.

Pipeline:
DATA QUALITY -> VISION -> REGIME -> EVIDENCE -> MODEL VALIDATION ->
STRESS RESILIENCE -> FINAL CONFIDENCE -> CALL / PUT / WAIT

Six independent validation gates are evaluated. Any critical blocker prevents
a directional signal and returns WAIT.

This is not a profitability guarantee and is intended for research/signal analysis.
It does not log into Quotex, automate clicks, place orders, extract session tokens,
or bypass platform controls.
