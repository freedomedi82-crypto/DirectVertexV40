# Direct Vertex V27.0

V27 adds a research-only risk/session guard. It can only block an admitted signal and return WAIT. It does not size trades or execute orders.

## Gate
- minimum settled samples
- consecutive-loss protection
- session-loss protection
- explicit BLOCK/PASS state

V27 is intended for replay/paper research and validation, not automated trading.
