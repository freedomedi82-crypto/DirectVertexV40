# Direct Vertex V21.0 — Real-Time Learning & Calibration

V21 adds an online learning/calibration layer and integrates the V20 decision gate into the live analysis loop.

## What changed
- V21LearningEngine learns only from **settled** WIN/LOSS/DRAW records.
- Pending observations are ignored.
- Observations newer than the current decision timestamp are ignored, preventing future-data leakage.
- Beta-style probability smoothing + approximate 95% interval.
- Regime-specific performance summaries.
- Page-Hinkley-style drift diagnostic.
- Drift and cooldown state make the final decision more conservative.
- Learning reliability combines sample size, interval width and drift stability.
- V20 Decision Intelligence is now used as a final conservative gate in the live loop.
- Learning audit CSV export.

## Important
V21 is an **analysis/signal assistant**, not an auto-trader. It does not log in to Quotex, click buttons, place orders, or bypass platform controls.

This is a research/calibration layer, not proof of profitability. Real-money performance can differ materially from replay/backtest results.

## Build
Use the existing Gradle project. The environment used to package this source did not contain a working Android SDK/Gradle toolchain, so this release is provided as source rather than a compiled APK.
