# Direct Vertex V31.0 — Decision-to-Outcome Audit

V31 adds a chronological audit trail over the actual ReplayEngine + SignalEngine. For every non-WAIT decision it records entry, expiry exit, direction, score, confidence, reason/evidence tokens, regime and outcome. It also reports direction-specific win rates, coverage and maximum losing streak.

The audit is diagnostic/research only. It does not execute trades, automate Quotex, extract sessions or bypass platform protections.

A score is not treated as a calibrated probability here; V25 remains the calibration layer.
