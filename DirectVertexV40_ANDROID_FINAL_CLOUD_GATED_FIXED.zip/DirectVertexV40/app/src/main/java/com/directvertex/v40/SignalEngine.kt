package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.roundToInt

class SignalEngine(
    private val minimumScore: Int = 74,
    private val minimumSpread: Int = 18
) {
    fun evaluate(s: SonarSnapshot, velocity: Double? = s.velocity): SignalState {
        var up = 50f; var down = 50f
        val upReasons = mutableListOf<String>(); val downReasons = mutableListOf<String>()
        val gap = s.greenRatio - s.redRatio
        if (gap > .018f) { up += (gap * 125f).coerceAtMost(20f); upReasons += "pressure+" }
        if (gap < -.018f) { down += (-gap * 125f).coerceAtMost(20f); downReasons += "pressure-" }
        when (s.virtualCandle.bias) {
            "BULLISH" -> { up += 16f; upReasons += "candle+" }
            "BEARISH" -> { down += 16f; downReasons += "candle-" }
        }
        velocity?.let { v ->
            if (abs(v) > 1e-9) if (v > 0) { up += 10f; upReasons += "momentum+" } else { down += 10f; downReasons += "momentum-" }
        }
        if (s.trendStrength > 0.35) {
            if ((velocity ?: 0.0) > 0) { up += 8f; upReasons += "trend+" }
            if ((velocity ?: 0.0) < 0) { down += 8f; downReasons += "trend-" }
        }
        if (s.acceleration > 0) { up += 4f; upReasons += "accel+" }
        if (s.acceleration < 0) { down += 4f; downReasons += "accel-" }
        s.distanceFromEntry?.let { d -> if (d > 0) up += 3f else if (d < 0) down += 3f }
        if (s.volatility > 0 && s.volatility > abs(velocity ?: 0.0) * 2.5) {
            return wait(s, maxOf(up, down).roundToInt(), "Volatility tinggi: tunggu konfirmasi")
        }
        if (s.sampleCount < 8) return wait(s, maxOf(up, down).roundToInt(), "Menunggu sampel temporal")
        val u = up.roundToInt().coerceIn(0, 100); val d = down.roundToInt().coerceIn(0, 100)
        val spread = abs(u-d)
        if (maxOf(u,d) < minimumScore || spread < minimumSpread) return wait(s,maxOf(u,d),"Noise filter: konfirmasi belum cukup")
        return if (u>d) SignalState("CALL",u,if(u>=86)"HIGH" else "MEDIUM",reason=upReasons.joinToString(" • "),snapshot=s)
        else SignalState("PUT",d,if(d>=86)"HIGH" else "MEDIUM",reason=downReasons.joinToString(" • "),snapshot=s)
    }
    private fun wait(s: SonarSnapshot, score: Int, reason: String) = SignalState("WAIT",score,"LOW",reason=reason,snapshot=s)
}
