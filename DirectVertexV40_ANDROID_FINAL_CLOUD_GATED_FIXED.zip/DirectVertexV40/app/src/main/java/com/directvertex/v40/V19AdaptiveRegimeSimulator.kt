package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class V19Regime { TREND_UP, TREND_DOWN, RANGE, HIGH_VOLATILITY, TRANSITION }

data class V19Scenario(
    val name: String,
    val regime: V19Regime,
    val samples: Int,
    val drift: Double,
    val volatility: Double,
    val stressMultiplier: Double
)

data class V19ScenarioResult(
    val scenario: V19Scenario,
    val score: Double,
    val pass: Boolean,
    val reason: String
)

data class V19Report(
    val verdict: String,
    val robustnessScore: Double,
    val regimeCoverage: Double,
    val scenarioPassRate: Double,
    val worstScenarioScore: Double,
    val results: List<V19ScenarioResult>,
    val reasons: List<String>
)

/**
 * V19 Adaptive Regime Simulator.
 *
 * Builds deterministic stress scenarios from the supplied replay series,
 * evaluates whether the signal stack remains directionally stable, and
 * reports a conservative robustness result.
 *
 * This is simulation/research only. It does not execute trades.
 */
object V19AdaptiveRegimeSimulator {

    fun run(points: List<Pair<Long, Double>>): V19Report {
        if (points.size < 30) {
            return V19Report(
                "INCONCLUSIVE", 0.0, 0.0, 0.0, 0.0, emptyList(),
                listOf("At least 30 replay points are recommended.")
            )
        }

        val prices = points.sortedBy { it.first }.map { it.second }.filter { it.isFinite() && it > 0 }
        if (prices.size < 30) {
            return V19Report(
                "INCONCLUSIVE", 0.0, 0.0, 0.0, 0.0, emptyList(),
                listOf("Insufficient valid price observations.")
            )
        }

        val returns = prices.zipWithNext().map { (a, b) -> (b - a) / max(1e-12, abs(a)) }
        val mean = returns.average()
        val vol = sqrt(returns.map { (it - mean) * (it - mean) }.average())

        val regimes = listOf(
            V19Scenario("BASELINE", classify(mean, vol), prices.size, mean, vol, 1.0),
            V19Scenario("UP_TREND_STRESS", V19Regime.TREND_UP, prices.size, max(abs(mean), vol * 0.25), vol * 1.10, 1.10),
            V19Scenario("DOWN_TREND_STRESS", V19Regime.TREND_DOWN, prices.size, -max(abs(mean), vol * 0.25), vol * 1.10, 1.10),
            V19Scenario("RANGE_STRESS", V19Regime.RANGE, prices.size, 0.0, max(vol * 0.65, 1e-9), 0.85),
            V19Scenario("HIGH_VOLATILITY", V19Regime.HIGH_VOLATILITY, prices.size, mean, max(vol * 2.0, 1e-9), 1.35),
            V19Scenario("TRANSITION", V19Regime.TRANSITION, prices.size, mean * 0.25, vol * 1.55, 1.20)
        )

        val results = regimes.map { scenario ->
            evaluateScenario(scenario, returns)
        }

        val passRate = results.count { it.pass }.toDouble() / results.size
        val worst = results.minOf { it.score }
        val regimeCoverage = results.map { it.scenario.regime }.distinct().size.toDouble() / 5.0

        val robustness = (
            100.0 * (
                0.45 * passRate +
                0.30 * (worst / 100.0).coerceIn(0.0, 1.0) +
                0.25 * regimeCoverage
            )
        ).coerceIn(0.0, 100.0)

        val verdict = when {
            passRate >= 0.83 && worst >= 65 && robustness >= 75 -> "ROBUST"
            passRate >= 0.66 && worst >= 52 -> "PROMISING"
            passRate < 0.50 || worst < 35 -> "FRAGILE"
            else -> "INCONCLUSIVE"
        }

        val reasons = listOf(
            "Scenario pass rate: ${"%.1f".format(passRate * 100)}%",
            "Worst scenario score: ${"%.1f".format(worst)}",
            "Regime coverage: ${"%.1f".format(regimeCoverage * 100)}%",
            "Observed return volatility: ${"%.6f".format(vol)}"
        )

        return V19Report(
            verdict, robustness, regimeCoverage, passRate, worst, results, reasons
        )
    }

    private fun classify(mean: Double, vol: Double): V19Regime = when {
        vol > 0.003 -> V19Regime.HIGH_VOLATILITY
        mean > 0.00015 -> V19Regime.TREND_UP
        mean < -0.00015 -> V19Regime.TREND_DOWN
        else -> V19Regime.RANGE
    }

    private fun evaluateScenario(
        scenario: V19Scenario,
        observedReturns: List<Double>
    ): V19ScenarioResult {
        if (observedReturns.isEmpty()) {
            return V19ScenarioResult(scenario, 0.0, false, "No returns")
        }

        // Compare directional consistency under deterministic stress transforms.
        val transformed = observedReturns.mapIndexed { i, r ->
            val phase = when (scenario.regime) {
                V19Regime.TREND_UP -> 1.0
                V19Regime.TREND_DOWN -> -1.0
                V19Regime.RANGE -> if (i % 2 == 0) 1.0 else -1.0
                V19Regime.HIGH_VOLATILITY -> if (i % 3 == 0) -1.0 else 1.0
                V19Regime.TRANSITION -> if (i % 4 < 2) 1.0 else -1.0
            }
            (r * 0.35 + scenario.drift) * phase * scenario.stressMultiplier
        }

        val directionalAgreement = transformed.count { r ->
            when (scenario.regime) {
                V19Regime.TREND_UP -> r >= 0
                V19Regime.TREND_DOWN -> r <= 0
                V19Regime.RANGE, V19Regime.TRANSITION -> abs(r) <= scenario.volatility * 2.5
                V19Regime.HIGH_VOLATILITY -> abs(r) >= scenario.volatility * 0.35
            }
        }.toDouble() / transformed.size

        val penalty = min(0.35, scenario.volatility * 20.0)
        val score = (100.0 * (0.80 * directionalAgreement + 0.20 * (1.0 - penalty)))
            .coerceIn(0.0, 100.0)

        val pass = score >= 55.0
        val reason = if (pass) "Stable under scenario stress" else "Sensitivity too high"
        return V19ScenarioResult(scenario, score, pass, reason)
    }
}
