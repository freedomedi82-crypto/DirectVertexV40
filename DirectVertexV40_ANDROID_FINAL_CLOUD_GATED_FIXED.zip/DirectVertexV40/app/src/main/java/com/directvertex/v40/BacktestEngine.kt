package com.directvertex.v40

import java.util.ArrayDeque

enum class Outcome { WIN, LOSS, DRAW, PENDING }

data class RecordedSignal(
    val id: Long,
    val timestamp: Long,
    val direction: String,
    val score: Int,
    val confidence: String,
    val probability: Double = 0.5,
    val entryPrice: Double?,
    val expirySeconds: Int,
    val regime: String? = null,
    var exitPrice: Double? = null,
    var outcome: Outcome = Outcome.PENDING
)

data class BacktestStats(
    val total: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val pending: Int,
    val winRate: Double,
    val callCount: Int,
    val putCount: Int,
    val maxLosingStreak: Int
)

class BacktestEngine {
    private val records = ArrayDeque<RecordedSignal>()
    private var nextId = 1L

    fun record(signal: SignalState, expirySeconds: Int = 60, now: Long = System.currentTimeMillis()): RecordedSignal? {
        if (signal.direction == "WAIT" || signal.snapshot.calibratedPrice == null) return null
        // Avoid duplicate recording of the same signal while the camera produces many frames.
        val latest = records.lastOrNull()
        if (latest != null && latest.outcome == Outcome.PENDING &&
            latest.direction == signal.direction && latest.entryPrice == signal.snapshot.calibratedPrice &&
            now - latest.timestamp < 3000L) return null

        val r = RecordedSignal(
            id = nextId++, timestamp = now, direction = signal.direction,
            score = signal.score, confidence = signal.confidence, probability = signal.decisionProbability.coerceIn(0.0, 1.0),
            entryPrice = signal.snapshot.calibratedPrice, expirySeconds = expirySeconds,
            regime = signal.regime
        )
        records.addLast(r)
        while (records.size > 500) records.removeFirst()
        return r
    }

    fun settle(id: Long, exitPrice: Double): RecordedSignal? {
        val r = records.firstOrNull { it.id == id && it.outcome == Outcome.PENDING } ?: return null
        r.exitPrice = exitPrice
        r.outcome = when {
            r.entryPrice == null -> Outcome.PENDING
            exitPrice == r.entryPrice -> Outcome.DRAW
            r.direction == "CALL" && exitPrice > r.entryPrice -> Outcome.WIN
            r.direction == "PUT" && exitPrice < r.entryPrice -> Outcome.WIN
            else -> Outcome.LOSS
        }
        return r
    }

    fun settleExpired(currentPrice: Double, now: Long = System.currentTimeMillis()) {
        records.filter { it.outcome == Outcome.PENDING && now - it.timestamp >= it.expirySeconds * 1000L }
            .forEach { settle(it.id, currentPrice) }
    }

    fun settleLatest(exitPrice: Double): RecordedSignal? =
        records.lastOrNull { it.outcome == Outcome.PENDING }?.let { settle(it.id, exitPrice) }

    fun stats(): BacktestStats {
        val list = records.toList()
        val resolved = list.filter { it.outcome != Outcome.PENDING }
        val wins = resolved.count { it.outcome == Outcome.WIN }
        val losses = resolved.count { it.outcome == Outcome.LOSS }
        val draws = resolved.count { it.outcome == Outcome.DRAW }
        var current = 0
        var maxStreak = 0
        resolved.forEach { r ->
            if (r.outcome == Outcome.LOSS) { current++; maxStreak = maxOf(maxStreak, current) }
            else current = 0
        }
        val winRate = if (wins + losses == 0) 0.0 else wins.toDouble() / (wins + losses) * 100.0
        return BacktestStats(list.size, wins, losses, draws, list.count { it.outcome == Outcome.PENDING },
            winRate, list.count { it.direction == "CALL" }, list.count { it.direction == "PUT" }, maxStreak)
    }

    fun all(): List<RecordedSignal> = records.toList()

    fun restore(items: List<RecordedSignal>) {
        records.clear(); items.takeLast(500).forEach { records.addLast(it) }
        nextId = (records.maxOfOrNull { it.id } ?: 0L) + 1L
    }

    fun clear() { records.clear(); nextId = 1L }

    fun exportCsv(): String = buildString {
        appendLine("id,timestamp,direction,score,confidence,entry,expiry_seconds,exit,outcome")
        records.forEach { r ->
            appendLine(listOf(r.id, r.timestamp, r.direction, r.score, r.confidence,
                r.entryPrice ?: "", r.expirySeconds, r.exitPrice ?: "", r.outcome.name).joinToString(","))
        }
    }
}
