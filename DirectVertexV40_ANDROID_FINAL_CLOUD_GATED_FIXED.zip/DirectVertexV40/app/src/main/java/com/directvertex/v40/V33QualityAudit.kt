package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * V33: leakage-aware threshold/quality audit.
 *
 * Uses the actual V32 EntryQualityEngine implementation, but does not pretend
 * that a close-only CSV is identical to the camera/vision stream. It creates a
 * market-only SonarSnapshot from chronological prices and explicitly labels the
 * result as a research proxy.
 */
object V33QualityAudit {
    data class Point(val timestamp: Long, val open: Double, val high: Double, val low: Double, val close: Double)
    data class ThresholdResult(
        val threshold: Double,
        val minProbability: Double,
        val testSignals: Int,
        val wins: Int,
        val losses: Int,
        val draws: Int,
        val winRate: Double,
        val coverage: Double,
        val lower95: Double,
        val upper95: Double
    )
    data class Report(
        val points: Int = 0,
        val trainPoints: Int = 0,
        val calibrationPoints: Int = 0,
        val testPoints: Int = 0,
        val baselineSignals: Int = 0,
        val baselineWinRate: Double = 0.0,
        val bestThreshold: Double = 0.72,
        val bestTestWinRate: Double = 0.0,
        val bestTestCoverage: Double = 0.0,
        val bestLower95: Double = 0.0,
        val bestUpper95: Double = 0.0,
        val verdict: String = "INCONCLUSIVE",
        val leakageFree: Boolean = true,
        val note: String = ""
    )

    private fun wilson(w: Int, n: Int): Pair<Double, Double> {
        if (n == 0) return 0.0 to 0.0
        val z = 1.96
        val p = w.toDouble() / n
        val den = 1.0 + z*z/n
        val center = (p + z*z/(2*n)) / den
        val margin = z * kotlin.math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
        return (center-margin).coerceIn(0.0,1.0) to (center+margin).coerceIn(0.0,1.0)
    }

    private fun snapshot(history: List<Point>): SonarSnapshot {
        val last = history.last()
        val closes = history.map { it.close }
        val steps = closes.zipWithNext().map { it.second-it.first }
        val velocity = if (closes.size >= 2) closes.last() - closes.first() else null
        val mean = steps.average().takeIf { steps.isNotEmpty() } ?: 0.0
        val vol = if (steps.isNotEmpty()) kotlin.math.sqrt(steps.map { (it-mean)*(it-mean) }.average()) else 0.0
        val trend = if (closes.size >= 3) {
            val span = (closes.maxOrNull()!! - closes.minOrNull()!!).coerceAtLeast(1e-12)
            abs(velocity ?: 0.0) / span
        } else 0.0
        val accel = if (steps.size >= 2) steps.last()-steps.first() else 0.0
        val green = history.count { it.close > it.open }.toDouble()/history.size.coerceAtLeast(1)
        val red = history.count { it.close < it.open }.toDouble()/history.size.coerceAtLeast(1)
        val high = history.maxOf { it.high }
        val low = history.minOf { it.low }
        val range = (high-low).coerceAtLeast(1e-12)
        val bias = when {
            last.close > last.open && abs(last.close-last.open)/range >= .20 -> "BULLISH"
            last.close < last.open && abs(last.close-last.open)/range >= .20 -> "BEARISH"
            else -> "NEUTRAL"
        }
        return SonarSnapshot(
            greenRatio = green.toFloat(), redRatio = red.toFloat(),
            calibratedPrice = last.close, distanceFromEntry = 0.0,
            virtualCandle = VirtualCandle(history.first().open, high, low, last.close, abs(last.close-history.first().open)/range, bias),
            velocity = velocity, sampleCount = history.size, trendStrength = trend,
            volatility = vol, acceleration = accel,
            supportDistance = last.close-low, resistanceDistance = high-last.close,
            chartY = 0.5f
        )
    }

    private data class Candidate(val index: Int, val direction: String, val quality: Double, val probability: Double)

    fun run(points: List<Point>, expirySteps: Int = 1, trainRatio: Double = .60, calibrationRatio: Double = .20): Report {
        val clean = points.filter { it.timestamp >= 0 && listOf(it.open,it.high,it.low,it.close).all(Double::isFinite) && it.close > 0 }
            .distinctBy { it.timestamp }.sortedBy { it.timestamp }
        if (clean.size < 300) return Report(points=clean.size, note="Minimal 300 M1 candles untuk V33 audit")
        val trainN = (clean.size*trainRatio).toInt().coerceAtLeast(100)
        val calN = (clean.size*calibrationRatio).toInt().coerceAtLeast(50)
        val testStart = (trainN+calN).coerceAtMost(clean.size-1)
        val testN = clean.size-testStart-expirySteps
        if (testN < 50) return Report(points=clean.size, trainPoints=trainN, calibrationPoints=calN, testPoints=testN, note="Test fold terlalu kecil")

        // Generate candidates chronologically. No future outcome enters feature generation.
        val candidates = mutableListOf<Candidate>()
        val engine = SignalEngine()
        for (i in 20 until clean.size-expirySteps) {
            val hist = clean.subList(0,i+1)
            val snap = snapshot(hist.takeLast(60))
            val base = engine.evaluate(snap, snap.velocity)
            if (base.direction != "CALL" && base.direction != "PUT") continue
            val q = V32EntryQualityEngine.evaluate(base, .70, V32EntryQualityEngine.Config(minimumProbability=0.0))
            if (!q.admitted && q.quality < .50) continue
            candidates += Candidate(i, base.direction, q.quality, .70)
        }

        // Calibration fold selects threshold only; test fold is untouched until final scoring.
        val cal = candidates.filter { it.index in trainN until testStart }
        val thresholds = listOf(.60,.64,.68,.72,.76,.80,.84,.88)
        val chosen = thresholds.maxByOrNull { t ->
            val rows = cal.filter { it.quality >= t }
            if (rows.size < 20) -1.0 else {
                var w=0; var d=0
                rows.forEach { c ->
                    val delta=clean[c.index+expirySteps].close-clean[c.index].close
                    if (abs(delta) <= clean[c.index].close*1e-5) return@forEach
                    d++; if ((c.direction=="CALL"&&delta>0)||(c.direction=="PUT"&&delta<0)) w++
                }
                if (d<20) -1.0 else w.toDouble()/d - 0.05*(1.0-rows.size.toDouble()/cal.size.coerceAtLeast(1))
            }
        } ?: .72

        fun score(rows: List<Candidate>): ThresholdResult {
            var w=0;var l=0;var d=0
            rows.forEach { c ->
                val delta=clean[c.index+expirySteps].close-clean[c.index].close
                if(abs(delta)<=clean[c.index].close*1e-5){d++;return@forEach}
                if((c.direction=="CALL"&&delta>0)||(c.direction=="PUT"&&delta<0))w++ else l++
            }
            val settled=w+l
            val (lo,hi)=wilson(w,settled)
            return ThresholdResult(chosen,.70,rows.size,w,l,d,if(settled>0)w*100.0/settled else 0.0,rows.size*100.0/testN.coerceAtLeast(1),lo*100,hi*100)
        }

        val testCandidates = candidates.filter { it.index >= testStart && it.quality >= chosen }
        val baseCandidates = candidates.filter { it.index >= testStart }
        val result = score(testCandidates)
        val base = score(baseCandidates)
        val verdict = when {
            result.testSignals < 30 -> "INCONCLUSIVE"
            result.lower95 >= 50.0 && result.winRate >= base.winRate + 2.0 -> "PROMISING"
            result.winRate >= base.winRate -> "STABLE"
            else -> "FRAGILE"
        }
        return Report(clean.size,trainN,calN,testN,base.testSignals,base.winRate,result.threshold,result.winRate,result.coverage,result.lower95,result.upper95,verdict,true,
            "Threshold dipilih di calibration fold; test fold tidak dipakai untuk tuning. Ini market-only proxy, bukan reproduksi penuh vision stream.")
    }
}
