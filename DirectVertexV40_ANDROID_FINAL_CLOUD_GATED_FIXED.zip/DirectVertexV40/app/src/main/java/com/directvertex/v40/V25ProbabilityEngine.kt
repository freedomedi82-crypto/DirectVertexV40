package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * V34 Native Probability Validation.
 *
 * Probability thresholds are selected only from an earlier calibration slice.
 * Reported calibration metrics and threshold performance are calculated on a
 * later untouched test slice. This replaces the old same-sample threshold
 * optimization that could make reliability look better than it generalizes.
 */
object V25ProbabilityEngine {
    data class Integrated(
        val probability: Double,
        val source: String,
        val reliabilityWeight: Double
    )

    data class ReliabilityBin(
        val low: Double,
        val high: Double,
        val samples: Int,
        val predicted: Double,
        val observed: Double,
        val gap: Double
    )

    data class Report(
        val samples: Int = 0,
        val brierScore: Double = 1.0,
        val logLoss: Double = 10.0,
        val ece: Double = 1.0,
        val reliability: Double = 0.0,
        val threshold: Double = 0.65,
        val coverage: Double = 0.0,
        val selectedWinRate: Double = 0.0,
        val verdict: String = "INCONCLUSIVE",
        val note: String = "Belum diuji",
        val bins: List<ReliabilityBin> = emptyList(),
        val calibrationSamples: Int = 0,
        val testSamples: Int = 0,
        val lower95: Double = 0.0,
        val upper95: Double = 0.0
    )

    fun integrate(v22Confidence: Double, learning: V21LearningEngine.V21State): Integrated {
        val confidence = v22Confidence.coerceIn(0.0, 1.0)
        val prior = learning.calibratedProbability.coerceIn(0.05, 0.95)
        val weight = (learning.reliability * 0.70).coerceIn(0.0, 0.70)
        val probability = (confidence * (1.0 - weight) + prior * weight).coerceIn(0.50, 0.995)
        return Integrated(probability, "V22 confidence + V21 settled posterior", weight)
    }

    private fun wilson(wins: Int, n: Int): Pair<Double, Double> {
        if (n <= 0) return 0.0 to 0.0
        val z=1.96; val p=wins.toDouble()/n; val den=1.0+z*z/n
        val center=(p+z*z/(2*n))/den
        val margin=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        return (center-margin).coerceIn(0.0,1.0) to (center+margin).coerceIn(0.0,1.0)
    }

    fun evaluate(records: List<RecordedSignal>, now: Long = System.currentTimeMillis(), binCount: Int = 10): Report {
        val samples = records.asSequence()
            .filter { it.timestamp < now && (it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS) && it.probability.isFinite() && it.probability in 0.0..1.0 }
            .sortedBy { it.timestamp }
            .map { it.probability to (it.outcome == Outcome.WIN) }
            .toList()
        if (samples.size < 60) return Report(samples=samples.size, note="Minimal 60 settled WIN/LOSS samples untuk true OOS reliability validation")

        val warmupN=(samples.size*0.60).toInt().coerceAtLeast(30)
        val calEnd=(samples.size*0.80).toInt().coerceAtLeast(warmupN+20).coerceAtMost(samples.size-20)
        val calibration=samples.subList(warmupN,calEnd)
        val test=samples.subList(calEnd,samples.size)
        if (calibration.size<20 || test.size<20) return Report(samples=samples.size,calibrationSamples=calibration.size,testSamples=test.size,note="Calibration/test fold terlalu kecil")

        val thresholds=listOf(0.55,0.60,0.65,0.70,0.75,0.80,0.85)
        val chosen=thresholds.maxByOrNull { t ->
            val s=calibration.filter{it.first>=t}
            if(s.size<10) -1.0 else s.count{it.second}.toDouble()/s.size + 0.01*sqrt(s.size.toDouble()/calibration.size)
        } ?: 0.65

        val brier=test.map{(p,win)->val y=if(win)1.0 else 0.0;(p-y)*(p-y)}.average()
        val logLoss=test.map{(p,win)->val q=p.coerceIn(1e-6,1.0-1e-6);if(win)-ln(q) else -ln(1.0-q)}.average()
        val bins=(0 until binCount).mapNotNull{i->
            val low=i.toDouble()/binCount; val high=(i+1).toDouble()/binCount
            val rows=test.filter{(p,_)->p>=low&&(p<high||i==binCount-1)}
            if(rows.isEmpty())null else {val pred=rows.map{it.first}.average();val obs=rows.count{it.second}*1.0/rows.size;ReliabilityBin(low,high,rows.size,pred,obs,abs(pred-obs))}
        }
        val ece=bins.sumOf{it.samples.toDouble()/test.size*it.gap}
        val selected=test.filter{it.first>=chosen}
        val wins=selected.count{it.second}
        val wr=if(selected.isEmpty())0.0 else wins*100.0/selected.size
        val coverage=selected.size*100.0/test.size
        val (lo,hi)=wilson(wins,selected.size)
        val reliability=(1.0-ece).coerceIn(0.0,1.0)
        val verdict=when{
            selected.size<20->"INCONCLUSIVE"
            lo>=0.50&&ece<=0.10&&brier<=0.25->"CALIBRATED"
            lo>=0.45&&ece<=0.15->"USABLE"
            else->"FRAGILE"
        }
        return Report(samples.size,brier,logLoss,ece,reliability,chosen,coverage,wr,verdict,
            "V34 OOS: threshold dipilih dari calibration slice kronologis; seluruh metrik dilaporkan dari test slice yang lebih baru.",bins,calibration.size,test.size,lo*100.0,hi*100.0)
    }
}
