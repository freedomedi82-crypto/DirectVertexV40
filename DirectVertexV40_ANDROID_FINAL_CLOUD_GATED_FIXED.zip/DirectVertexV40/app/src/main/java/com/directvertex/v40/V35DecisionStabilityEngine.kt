package com.directvertex.v40

import java.util.ArrayDeque
import kotlin.math.max

/**
 * V35: temporal consensus + expectancy gate.
 *
 * Purpose: reject one-frame spikes and signals whose probability does not clear
 * the payout-adjusted break-even level by a safety margin. This is a signal
 * quality/abstention layer only; it never executes an order.
 */
object V35DecisionStabilityEngine {
    data class Config(
        val historySize: Int = 12,
        val minimumObservations: Int = 6,
        val minimumPersistenceMs: Long = 700L,
        val minimumAgreement: Double = 0.75,
        val defaultPayout: Double = 0.80,
        val minimumEdge: Double = 0.05,
        val minimumQuality: Double = 0.74
    )

    data class Observation(
        val timestamp: Long,
        val direction: String,
        val probability: Double,
        val quality: Double
    )

    data class Decision(
        val direction: String = "WAIT",
        val admitted: Boolean = false,
        val stability: Double = 0.0,
        val requiredProbability: Double = 0.0,
        val probability: Double = 0.5,
        val quality: Double = 0.0,
        val reason: String = "Menunggu konsensus entry",
        val observations: Int = 0
    )

    private val observations = ArrayDeque<Observation>()

    fun clear() = observations.clear()

    fun observe(
        candidate: V32EntryQualityEngine.Decision,
        now: Long = System.currentTimeMillis(),
        payout: Double = Config().defaultPayout,
        config: Config = Config()
    ): Decision {
        val direction = candidate.direction
        val p = candidate.probability.coerceIn(0.0, 1.0)
        val q = candidate.quality.coerceIn(0.0, 1.0)

        if (direction == "CALL" || direction == "PUT") {
            observations.addLast(Observation(now, direction, p, q))
        } else if (observations.isNotEmpty()) {
            // Keep recent consensus through a short WAIT so a single noisy
            // camera frame does not immediately erase an otherwise stable edge.
            val last = observations.last()
            if (now - last.timestamp > config.minimumPersistenceMs * 2) {
                observations.clear()
            }
        }
        while (observations.size > config.historySize) observations.removeFirst()

        if (direction != "CALL" && direction != "PUT") return Decision()

        val recent = observations.toList().takeLast(config.historySize)
        val same = recent.count { it.direction == direction }
        val agreement = if (recent.isEmpty()) 0.0 else same.toDouble() / recent.size
        val firstSame = recent.indexOfFirst { it.direction == direction }
        val persistence = if (firstSame >= 0) now - recent[firstSame].timestamp else 0L
        val payoutSafe = payout.coerceIn(0.01, 0.99)
        val breakEven = 1.0 / (1.0 + payoutSafe)
        val required = (breakEven + config.minimumEdge).coerceIn(0.50, 0.95)
        val avgQuality = recent.filter { it.direction == direction }.map { it.quality }.averageOrZero()
        val avgProbability = recent.filter { it.direction == direction }.map { it.probability }.averageOrZero()
        val probabilityMargin = ((avgProbability - breakEven) / max(0.01, 1.0 - breakEven)).coerceIn(0.0, 1.0)
        val stabilityScore = (0.55 * agreement + 0.25 * (persistence.toDouble() / config.minimumPersistenceMs).coerceIn(0.0, 1.0) + 0.20 * probabilityMargin).coerceIn(0.0, 1.0)

        val reasons = mutableListOf<String>()
        if (recent.size < config.minimumObservations) reasons += "Konsensus belum cukup (${recent.size}/${config.minimumObservations})"
        if (agreement < config.minimumAgreement) reasons += "Agreement ${"%.0f".format(agreement * 100)}% < ${"%.0f".format(config.minimumAgreement * 100)}%"
        if (persistence < config.minimumPersistenceMs) reasons += "Sinyal belum persisten"
        if (avgProbability < required) reasons += "P ${"%.1f".format(avgProbability * 100)}% < required ${"%.1f".format(required * 100)}%"
        if (avgQuality < config.minimumQuality) reasons += "Quality ${"%.0f".format(avgQuality * 100)}% < ${"%.0f".format(config.minimumQuality * 100)}%"
        val admitted = reasons.isEmpty() && candidate.admitted
        return Decision(
            direction = if (admitted) direction else "WAIT",
            admitted = admitted,
            stability = stabilityScore,
            requiredProbability = required,
            probability = avgProbability.coerceIn(0.0, 1.0),
            quality = avgQuality.coerceIn(0.0, 1.0),
            reason = if (admitted) "V35 consensus PASS • ${"%.0f".format(agreement * 100)}% agreement • ${persistence}ms persistent" else reasons.joinToString(" • "),
            observations = recent.size
        )
    }

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
}
