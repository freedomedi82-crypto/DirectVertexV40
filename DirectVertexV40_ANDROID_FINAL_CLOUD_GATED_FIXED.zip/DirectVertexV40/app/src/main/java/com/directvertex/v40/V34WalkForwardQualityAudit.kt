package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * V34 multi-fold, leakage-aware quality audit.
 *
 * Uses the real SignalEngine + V32 EntryQualityEngine on OHLC-derived market
 * snapshots. Each fold has: historical warm-up -> calibration -> purge gap ->
 * untouched test. Thresholds are chosen only from calibration outcomes.
 *
 * This is deliberately labeled a market-only proxy: an OHLC file cannot prove
 * equivalence with the camera/ML-Kit visual stream or with Quotex OTC pricing.
 */
object V34WalkForwardQualityAudit {
    data class Point(val timestamp: Long, val open: Double, val high: Double, val low: Double, val close: Double)
    data class Fold(
        val id: Int,
        val calibrationSignals: Int,
        val testSignals: Int,
        val wins: Int,
        val losses: Int,
        val draws: Int,
        val winRate: Double,
        val coverage: Double,
        val lower95: Double,
        val upper95: Double,
        val baselineWinRate: Double,
        val threshold: Double
    )
    data class Report(
        val points: Int = 0,
        val folds: Int = 0,
        val testSignals: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val winRate: Double = 0.0,
        val coverage: Double = 0.0,
        val lower95: Double = 0.0,
        val upper95: Double = 0.0,
        val worstFoldLower95: Double = 0.0,
        val foldsPassing: Int = 0,
        val verdict: String = "INCONCLUSIVE",
        val leakageFree: Boolean = true,
        val note: String = "",
        val foldReports: List<Fold> = emptyList()
    )

    private data class Candidate(val index:Int,val direction:String,val quality:Double)

    private fun wilson(w:Int,n:Int):Pair<Double,Double>{
        if(n<=0)return 0.0 to 0.0
        val z=1.96;val p=w.toDouble()/n;val den=1.0+z*z/n
        val center=(p+z*z/(2*n))/den
        val margin=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        return (center-margin).coerceIn(0.0,1.0) to (center+margin).coerceIn(0.0,1.0)
    }

    private fun snapshot(history:List<Point>):SonarSnapshot{
        val last=history.last()
        // Match TemporalEngine's 12-sample temporal window while keeping a
        // 60-bar virtual-candle context. This is still an OHLC proxy for the
        // real camera pressure stream.
        val temporal=history.takeLast(12)
        val closes=temporal.map{it.close}
        val steps=closes.zipWithNext().map{it.second-it.first}
        val velocity=if(closes.size>=2)closes.last()-closes.first() else null
        val mean=steps.average().takeIf{steps.isNotEmpty()}?:0.0
        val vol=if(steps.isNotEmpty())sqrt(steps.map{(it-mean)*(it-mean)}.average()) else 0.0
        val trend=if(closes.size>=3){val span=(closes.maxOrNull()!!-closes.minOrNull()!!).coerceAtLeast(1e-12);abs(velocity?:0.0)/span}else 0.0
        val accel=if(steps.size>=2)steps.last()-steps.first() else 0.0
        // Proxy the visual pressure ratios from candle direction over the same
        // temporal window; the real app obtains these from chart pixels.
        val green=temporal.count{it.close>it.open}.toDouble()/temporal.size.coerceAtLeast(1)
        val red=temporal.count{it.close<it.open}.toDouble()/temporal.size.coerceAtLeast(1)
        val high=history.maxOf{it.high};val low=history.minOf{it.low};val range=(high-low).coerceAtLeast(1e-12)
        val body=abs(last.close-last.open)/range
        val bias=when{last.close>last.open&&body>=.20->"BULLISH";last.close<last.open&&body>=.20->"BEARISH";else->"NEUTRAL"}
        return SonarSnapshot(
            ocrPrice = last.close.toString(),
            candleBias = bias,
            brightness = 0f,
            redRatio = red.toFloat(),
            greenRatio = green.toFloat(),
            chartY = null,
            calibratedPrice = last.close,
            distanceFromEntry = 0.0,
            virtualCandle = VirtualCandle(
                history.first().open,
                high,
                low,
                last.close,
                abs(last.close-history.first().open)/range,
                bias
            ),
            velocity = velocity,
            sampleCount = history.size,
            trendStrength = trend,
            volatility = vol,
            acceleration = accel,
            supportDistance = last.close-low,
            resistanceDistance = high-last.close,
            updatedAt = last.timestamp
        )
    }

    private fun candidates(points:List<Point>, start:Int, end:Int):List<Candidate>{
        val out=mutableListOf<Candidate>();val engine=SignalEngine()
        for(i in maxOf(20,start)..minOf(end,points.size-2)){
            val snap=snapshot(points.subList(0,i+1).takeLast(60))
            val base=engine.evaluate(snap,snap.velocity)
            if(base.direction!="CALL"&&base.direction!="PUT")continue
            val q=V32EntryQualityEngine.evaluate(base,.70,V32EntryQualityEngine.Config(minimumProbability=0.0))
            if(q.quality>=.50)out+=Candidate(i,base.direction,q.quality)
        }
        return out
    }

    private data class Score(val signals:Int,val wins:Int,val losses:Int,val draws:Int,val wr:Double,val cov:Double,val lo:Double,val hi:Double)

    private fun score(rows:List<Candidate>,points:List<Point>,expiry:Int,testStart:Int,testEnd:Int):Score{
        var w=0;var l=0;var d=0
        rows.forEach{c->
            val exit=c.index+expiry
            if(exit>=points.size)return@forEach
            val delta=points[exit].close-points[c.index].close
            if(abs(delta)<=points[c.index].close*1e-5){d++;return@forEach}
            if((c.direction=="CALL"&&delta>0)||(c.direction=="PUT"&&delta<0))w++ else l++
        }
        val settled=w+l;val(lo,hi)=wilson(w,settled)
        val duration=(testEnd-testStart).coerceAtLeast(1)
        return Score(rows.size,w,l,d,if(settled>0)w*100.0/settled else 0.0,rows.size*100.0/duration,lo*100.0,hi*100.0)
    }

    fun run(points:List<Point>,expirySteps:Int=1,foldCount:Int=5):Report{
        val clean=points.filter{it.timestamp>=0&&listOf(it.open,it.high,it.low,it.close).all(Double::isFinite)&&it.close>0}.distinctBy{it.timestamp}.sortedBy{it.timestamp}
        if(clean.size<1000)return Report(points=clean.size,note="Minimal 1000 M1 candles untuk multi-fold V34 audit")
        val foldSize=(clean.size*0.12).toInt().coerceAtLeast(100)
        val gap=expirySteps+20
        val reports=mutableListOf<Fold>()
        for(f in 0 until foldCount){
            val testStart=clean.size-(foldCount-f)*foldSize
            val testEnd=minOf(clean.size,testStart+foldSize)
            val calEnd=testStart-gap
            val calStart=maxOf(60,calEnd-(foldSize/2).coerceAtLeast(100))
            if(calEnd<=calStart+20||testEnd<=testStart+20)continue
            val cal=candidates(clean,calStart,calEnd)
            val testAll=candidates(clean,testStart,testEnd)
            val thresholds=listOf(.60,.64,.68,.72,.76,.80,.84,.88)
            val chosen=thresholds.maxByOrNull{t->
                val rows=cal.filter{it.quality>=t};if(rows.size<10)-1.0 else{
                    val s=score(rows,clean,expirySteps,calStart,calEnd)
                    if(s.wins+s.losses<10)-1.0 else s.wr/100.0+0.01*sqrt(rows.size.toDouble()/cal.size)
                }
            }?:.72
            val selected=testAll.filter{it.quality>=chosen}
            val s=score(selected,clean,expirySteps,testStart,testEnd)
            val b=score(testAll,clean,expirySteps,testStart,testEnd)
            reports+=Fold(f+1,cal.size,s.signals,s.wins,s.losses,s.draws,s.wr,s.cov,s.lo,s.hi,b.wr,chosen)
        }
        if(reports.isEmpty())return Report(points=clean.size,note="Tidak ada fold yang cukup besar")
        val totalSignals=reports.sumOf{it.testSignals};val w=reports.sumOf{it.wins};val l=reports.sumOf{it.losses};val d=reports.sumOf{it.draws};val settled=w+l
        val(lo,hi)=wilson(w,settled);val wr=if(settled>0)w*100.0/settled else 0.0
        val cov=reports.map{it.coverage}.average();val worst=reports.minOf{it.lower95}
        val passing=reports.count{it.testSignals>=10&&it.lower95>=50.0}
        val verdict=when{
            reports.size<foldCount||totalSignals<50->"INCONCLUSIVE"
            passing==reports.size&&lo>=50.0->"ROBUST"
            passing>=reports.size*0.8&&lo>=48.0->"PROMISING"
            else->"FRAGILE"
        }
        return Report(clean.size,reports.size,totalSignals,w,l,d,wr,cov,lo,hi,worst,passing,verdict,true,
            "V34 multi-fold OOS: threshold hanya dipilih dari fold calibration; test dipisahkan oleh purge gap. Market-only proxy, bukan reproduksi penuh vision/Quotex.",reports)
    }
}
