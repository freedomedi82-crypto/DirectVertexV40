package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class V14CandleFeature(
    val bullish: Boolean,
    val body: Double,
    val range: Double,
    val upperWick: Double,
    val lowerWick: Double
)

data class V14Signal(
    val direction: String,
    val score: Double,
    val confidence: Double,
    val momentum: Double,
    val pattern: String,
    val supportDistance: Double,
    val resistanceDistance: Double,
    val note: String
)

/**
 * Live Signal Intelligence layer.
 * Analysis-only: it produces a signal/recording suggestion and never executes orders.
 */
object V14Engine {
    fun analyze(
        prices: List<Double>,
        baseScore: Double,
        baseDirection: String,
        lookback: Int = 24
    ): V14Signal {
        if (prices.size < 5) {
            return V14Signal("WAIT", 0.0, 0.0, 0.0, "INSUFFICIENT_DATA", 0.0, 0.0, "Collecting candles")
        }

        val p = prices.takeLast(lookback.coerceAtLeast(5))
        val last = p.last()
        val recent = p.takeLast(min(8, p.size))
        val earlier = p.dropLast(min(8, p.size)).takeLast(min(8, p.size))

        val momentum = if (earlier.isNotEmpty()) {
            (recent.average() - earlier.average()) / max(1e-9, abs(earlier.average()))
        } else 0.0

        val lo = p.minOrNull() ?: last
        val hi = p.maxOrNull() ?: last
        val range = max(1e-9, hi - lo)
        val supportDistance = (last - lo) / range
        val resistanceDistance = (hi - last) / range

        val c = candleFeatures(p)
        val pattern = when {
            c.size >= 3 && c.takeLast(3).all { it.bullish } -> "THREE_BULLISH"
            c.size >= 3 && c.takeLast(3).none { it.bullish } -> "THREE_BEARISH"
            c.isNotEmpty() && c.last().lowerWick > c.last().body * 1.5 -> "LOWER_REJECTION"
            c.isNotEmpty() && c.last().upperWick > c.last().body * 1.5 -> "UPPER_REJECTION"
            else -> "NEUTRAL"
        }

        var score = baseScore
        var dir = baseDirection

        if (momentum > 0.00015) score += 4.0
        if (momentum < -0.00015) score += 4.0

        if (pattern == "THREE_BULLISH" || pattern == "LOWER_REJECTION") {
            if (dir == "CALL") score += 5.0
        }
        if (pattern == "THREE_BEARISH" || pattern == "UPPER_REJECTION") {
            if (dir == "PUT") score += 5.0
        }

        // Avoid chasing the extreme of the observed range.
        if (dir == "CALL" && resistanceDistance < 0.12) score -= 7.0
        if (dir == "PUT" && supportDistance < 0.12) score -= 7.0

        score = score.coerceIn(0.0, 100.0)
        val agreement = when {
            (dir == "CALL" && momentum > 0) || (dir == "PUT" && momentum < 0) -> 1.0
            else -> 0.35
        }
        val confidence = (0.55 * score / 100.0 + 0.45 * agreement).coerceIn(0.0, 1.0)

        val finalDir = if (score >= 72.0 && confidence >= 0.62) dir else "WAIT"
        val note = when {
            finalDir == "WAIT" && score < 72 -> "Filtered: score below threshold"
            finalDir == "WAIT" -> "Filtered: weak multi-factor agreement"
            else -> "Multi-factor live confirmation"
        }

        return V14Signal(
            finalDir, score, confidence, momentum, pattern,
            supportDistance, resistanceDistance, note
        )
    }

    private fun candleFeatures(prices: List<Double>): List<V14CandleFeature> {
        if (prices.size < 4) return emptyList()
        val out = ArrayList<V14CandleFeature>()
        for (i in 1 until prices.size) {
            val o = prices[i - 1]
            val c = prices[i]
            val body = abs(c - o)
            val range = max(body, abs(c - o))
            val upper = if (c >= o) 0.0 else body
            val lower = if (c >= o) body else 0.0
            out += V14CandleFeature(c >= o, body, range, upper, lower)
        }
        return out
    }
}
