package com.directvertex.v40

import java.security.MessageDigest
import kotlin.math.sqrt

/**
 * V40: immutable chronological OOS audit harness.
 *
 * This class never tunes a parameter on the test window. It is intentionally
 * independent from the live signal path and only evaluates already-recorded
 * decisions/outcomes. It is therefore suitable for a final evidence package
 * without silently reusing the OOS set for optimization.
 */
object V40UntouchedOOSAudit {
    data class Config(
        val folds: Int = 5,
        val calibrationRatio: Double = 0.20,
        val purgeSeconds: Long = 90L,
        val minimumTestSamples: Int = 20,
        val minimumPrecision: Double = 0.60,
        val minimumLower95: Double = 0.52,
        val maximumLossStreak: Int = 5,
        val minimumCoverage: Double = 0.01,
        val minimumFoldPassRate: Double = 0.60
    )

    data class Fold(
        val index: Int,
        val trainCount: Int,
        val calibrationCount: Int,
        val testCount: Int,
        val decisiveTestCount: Int,
        val wins: Int,
        val losses: Int,
        val precision: Double,
        val lower95: Double,
        val coverage: Double,
        val maxLossStreak: Int,
        val passed: Boolean,
        val reason: String
    )

    data class Report(
        val verdict: String = "INCONCLUSIVE",
        val datasetHash: String = "",
        val totalRows: Int = 0,
        val chronological: Boolean = false,
        val duplicateTimestamps: Int = 0,
        val pendingRows: Int = 0,
        val folds: List<Fold> = emptyList(),
        val aggregateTestSamples: Int = 0,
        val aggregateWins: Int = 0,
        val aggregateLosses: Int = 0,
        val aggregatePrecision: Double = 0.0,
        val aggregateLower95: Double = 0.0,
        val aggregateCoverage: Double = 0.0,
        val aggregateMaxLossStreak: Int = 0,
        val reason: String = "Belum diuji"
    )

    /** SHA-256 of canonicalized signal rows. Hash before analysis and publish with the report. */
    fun sha256(rows: List<RecordedSignal>): String {
        val canonical = rows.sortedBy { it.timestamp }.joinToString("\n") {
            listOf(it.id, it.timestamp, it.direction, it.score, it.probability,
                it.entryPrice ?: Double.NaN, it.expirySeconds, it.regime ?: "",
                it.outcome.name, it.exitPrice ?: Double.NaN).joinToString("|")
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    fun audit(
        input: List<RecordedSignal>,
        sourceBytesHash: String? = null,
        config: Config = Config()
    ): Report {
        val rows = input.sortedBy { it.timestamp }
        if (rows.isEmpty()) return Report(reason = "Dataset kosong")

        val duplicates = rows.zipWithNext().count { it.first.timestamp == it.second.timestamp }
        val chronological = input.zipWithNext().all { it.first.timestamp <= it.second.timestamp }
        val pending = rows.count { it.outcome == Outcome.PENDING || it.outcome == Outcome.DRAW }
        val decisive = rows.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        if (!chronological) return Report(
            verdict = "INCONCLUSIVE", datasetHash = sourceBytesHash ?: sha256(rows),
            totalRows = rows.size, chronological = false, duplicateTimestamps = duplicates,
            pendingRows = pending, reason = "Input tidak kronologis; audit ditolak."
        )
        if (decisive.size < config.minimumTestSamples) return Report(
            verdict = "INCONCLUSIVE", datasetHash = sourceBytesHash ?: sha256(rows),
            totalRows = rows.size, chronological = true, duplicateTimestamps = duplicates,
            pendingRows = pending, reason = "Decisive samples belum cukup untuk OOS."
        )

        val folds = buildFolds(rows, config)
        val testRows = folds.flatMap { foldRows(rows, it.index, config).third }
        val aggregate = stats(testRows, rows.size)
        val passedFolds = folds.count { it.passed }
        val verdict = when {
            folds.size < config.folds -> "INCONCLUSIVE"
            folds.any { it.testCount == 0 } -> "INCONCLUSIVE"
            passedFolds.toDouble() / folds.size < config.minimumFoldPassRate -> "FAIL"
            aggregate.decisive < config.minimumTestSamples -> "INCONCLUSIVE"
            aggregate.precision < config.minimumPrecision -> "FAIL"
            aggregate.lower95 < config.minimumLower95 -> "FAIL"
            aggregate.coverage < config.minimumCoverage -> "FAIL"
            aggregate.maxLossStreak > config.maximumLossStreak -> "FAIL"
            else -> "PASS"
        }
        val reason = when (verdict) {
            "PASS" -> "Untouched chronological OOS PASS • fold stability met • no test tuning"
            "FAIL" -> "OOS FAIL • one or more strict production criteria not met"
            else -> "OOS INCONCLUSIVE • evidence or fold structure insufficient"
        }
        return Report(
            verdict = verdict,
            datasetHash = sourceBytesHash ?: sha256(rows),
            totalRows = rows.size,
            chronological = chronological,
            duplicateTimestamps = duplicates,
            pendingRows = pending,
            folds = folds,
            aggregateTestSamples = aggregate.decisive,
            aggregateWins = aggregate.wins,
            aggregateLosses = aggregate.losses,
            aggregatePrecision = aggregate.precision,
            aggregateLower95 = aggregate.lower95,
            aggregateCoverage = aggregate.coverage,
            aggregateMaxLossStreak = aggregate.maxLossStreak,
            reason = reason
        )
    }

    /** Strict CSV reader for RecordStore/ExportEngine-compatible signal outcome files. */
    fun parseCsv(csv: String): List<RecordedSignal> {
        val lines = csv.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size <= 1) return emptyList()
        val header = lines.first().split(',').map { it.trim().lowercase() }
        fun idx(vararg names: String): Int = names.firstNotNullOfOrNull { n -> header.indexOf(n).takeIf { it >= 0 } }
            ?: -1
        val idI = idx("id")
        val timeI = idx("timestamp", "time")
        val dirI = idx("direction")
        val scoreI = idx("score")
        val probI = idx("probability", "prob")
        val entryI = idx("entryprice", "entry_price", "entry")
        val expiryI = idx("expiryseconds", "expiry_seconds", "expiry")
        val regimeI = idx("regime")
        val outcomeI = idx("outcome")
        val exitI = idx("exitprice", "exit_price", "exit")
        require(timeI >= 0 && dirI >= 0 && outcomeI >= 0) { "CSV wajib memiliki timestamp, direction, outcome" }
        return lines.drop(1).mapIndexedNotNull { n, line ->
            val c = line.split(',')
            fun s(i: Int) = c.getOrNull(i)?.trim().orEmpty()
            val outcome = runCatching { Outcome.valueOf(s(outcomeI).uppercase()) }.getOrNull() ?: return@mapIndexedNotNull null
            RecordedSignal(
                id = s(idI).toLongOrNull() ?: n.toLong(),
                timestamp = s(timeI).toLongOrNull() ?: return@mapIndexedNotNull null,
                direction = s(dirI).uppercase(),
                score = s(scoreI).toIntOrNull() ?: 0,
                confidence = "",
                probability = s(probI).toDoubleOrNull() ?: 0.5,
                entryPrice = s(entryI).toDoubleOrNull(),
                expirySeconds = s(expiryI).toIntOrNull() ?: 60,
                regime = s(regimeI).ifBlank { null },
                exitPrice = s(exitI).toDoubleOrNull(),
                outcome = outcome
            )
        }
    }

    private fun buildFolds(rows: List<RecordedSignal>, config: Config): List<Fold> {
        val n = rows.size
        val chunk = (n / (config.folds + 1)).coerceAtLeast(1)
        val out = ArrayList<Fold>(config.folds)
        for (i in 1..config.folds) {
            val testStart = i * chunk
            if (testStart >= n) break
            val testEnd = (testStart + chunk).coerceAtMost(n)
            val purgeMs = config.purgeSeconds.coerceAtLeast(0) * 1000L
            val boundary = rows[testStart].timestamp - purgeMs
            val eligibleTrainEnd = rows.indexOfLast { it.timestamp < boundary }
            if (eligibleTrainEnd < 1) continue
            val trainEndExclusive = eligibleTrainEnd + 1
            val calibrationCount = (trainEndExclusive * config.calibrationRatio).toInt().coerceIn(1, trainEndExclusive - 1)
            val split = trainEndExclusive - calibrationCount
            val train = rows.subList(0, split)
            val calibration = rows.subList(split, trainEndExclusive)
            val test = rows.subList(testStart, testEnd)
            val s = stats(test, n)
            val passed = s.decisive >= config.minimumTestSamples &&
                s.precision >= config.minimumPrecision &&
                s.lower95 >= config.minimumLower95 &&
                s.coverage >= config.minimumCoverage &&
                s.maxLossStreak <= config.maximumLossStreak
            out += Fold(i, train.size, calibration.size, test.size, s.decisive, s.wins, s.losses,
                s.precision, s.lower95, s.coverage, s.maxLossStreak, passed,
                if (passed) "PASS" else "fold criteria not met")
        }
        return out
    }

    private fun foldRows(rows: List<RecordedSignal>, index: Int, config: Config): Triple<List<RecordedSignal>, List<RecordedSignal>, List<RecordedSignal>> {
        val n = rows.size
        val chunk = (n / (config.folds + 1)).coerceAtLeast(1)
        val testStart = index * chunk
        val testEnd = (testStart + chunk).coerceAtMost(n)
        if (testStart >= n) return Triple(emptyList(), emptyList(), emptyList())
        val purgeMs = config.purgeSeconds.coerceAtLeast(0) * 1000L
        val boundary = rows[testStart].timestamp - purgeMs
        val trainEndExclusive = rows.indexOfLast { it.timestamp < boundary } + 1
        if (trainEndExclusive < 2) return Triple(emptyList(), emptyList(), rows.subList(testStart, testEnd))
        val calibrationCount = (trainEndExclusive * config.calibrationRatio).toInt().coerceIn(1, trainEndExclusive - 1)
        val split = trainEndExclusive - calibrationCount
        return Triple(rows.subList(0, split), rows.subList(split, trainEndExclusive), rows.subList(testStart, testEnd))
    }

    private data class Stats(val decisive: Int, val wins: Int, val losses: Int, val precision: Double, val lower95: Double, val coverage: Double, val maxLossStreak: Int)

    private fun stats(rows: List<RecordedSignal>, universe: Int): Stats {
        val d = rows.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        val wins = d.count { it.outcome == Outcome.WIN }
        val losses = d.count { it.outcome == Outcome.LOSS }
        val precision = if (d.isEmpty()) 0.0 else wins.toDouble() / d.size
        val lower = wilsonLower(wins, d.size)
        val coverage = if (universe == 0) 0.0 else d.size.toDouble() / universe
        var streak = 0
        var max = 0
        d.forEach { if (it.outcome == Outcome.LOSS) { streak++; max = maxOf(max, streak) } else streak = 0 }
        return Stats(d.size, wins, losses, precision, lower, coverage, max)
    }

    private fun wilsonLower(wins: Int, n: Int): Double {
        if (n <= 0) return 0.0
        val z = 1.96
        val p = wins.toDouble() / n
        val den = 1.0 + z * z / n
        val center = (p + z * z / (2.0 * n)) / den
        val margin = z * sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / den
        return (center - margin).coerceIn(0.0, 1.0)
    }
}
