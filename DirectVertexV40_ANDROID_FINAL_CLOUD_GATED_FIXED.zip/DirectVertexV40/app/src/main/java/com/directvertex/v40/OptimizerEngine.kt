package com.directvertex.v40

/** Offline parameter search with train/validation/test separation. Never used for live execution. */
data class ParameterSet(val minScore:Int, val expirySeconds:Int)
data class OptimizationResult(
    val best: ParameterSet?, val trainScore:Double, val validationScore:Double,
    val testScore:Double, val testWinRate:Double, val testTrades:Int,
    val tested:Int, val verdict:String, val note:String
)

object OptimizerEngine {
    fun optimize(points:List<ReplayPoint>, minSamples:Int=40):OptimizationResult {
        if(points.size < minSamples*3) return OptimizationResult(null,0.0,0.0,0.0,0.0,0,0,"INCONCLUSIVE","Data belum cukup untuk train/validation/test.")
        val p=points.sortedBy{it.timestamp}; val n=p.size
        val a=p.subList(0,n*60/100); val b=p.subList(n*60/100,n*80/100); val c=p.subList(n*80/100,n)
        val grid=(70..90 step 2).flatMap{score->listOf(30,60,120).map{e->ParameterSet(score,e)}}
        fun eval(data:List<ReplayPoint>, ps:ParameterSet):Pair<Double,Int>{
            val (s,tr)=WalkForwardEngine(ps.expirySeconds).run(data,ps.minScore)
            if(s.trades==0) return 0.0 to 0
            val stability=if(s.trades<20) .5 else 1.0
            return ((s.winRate/100.0)*stability - 0.002*s.maxLosingStreak) to s.trades
        }
        var best:ParameterSet?=null; var bestTrain=Double.NEGATIVE_INFINITY; var bestVal=0.0
        for(ps in grid){ val (ts,_)=eval(a,ps); val (vs,_)=eval(b,ps); val objective=.55*ts+.45*vs
            if(objective>bestTrain){bestTrain=objective;best=ps;bestVal=vs}}
        val chosen=best ?: return OptimizationResult(null,0.0,0.0,0.0,0.0,0,grid.size,"INCONCLUSIVE","Tidak ada konfigurasi yang dapat dievaluasi.")
        val (train,_)=eval(a,chosen); val (valid,_)=eval(b,chosen); val (testScore,testTrades)=eval(c,chosen)
        val testStats=WalkForwardEngine(chosen.expirySeconds).run(c,chosen.minScore).first
        val gap=train-testScore
        val verdict=when{
            testTrades<20->"INCONCLUSIVE"
            testStats.winRate>=55.0 && gap<0.10->"ROBUST"
            testStats.winRate>=52.0 && gap<0.16->"PROMISING"
            gap>=0.16->"OVERFIT RISK"
            else->"FRAGILE"
        }
        val note=when(verdict){
            "ROBUST"->"Konfigurasi terbaik tetap stabil pada data test yang tidak dipakai saat optimasi."
            "PROMISING"->"Ada indikasi edge, tetapi bukti out-of-sample belum kuat."
            "OVERFIT RISK"->"Performa train jauh lebih tinggi daripada test; jangan memilih parameter ini berdasarkan backtest saja."
            "FRAGILE"->"Performa test belum cukup kuat."
            else->"Perlu dataset lebih panjang dan beberapa periode pengujian."
        }
        return OptimizationResult(chosen,train,valid,testScore,testStats.winRate,testTrades,grid.size,verdict,note)
    }
}
