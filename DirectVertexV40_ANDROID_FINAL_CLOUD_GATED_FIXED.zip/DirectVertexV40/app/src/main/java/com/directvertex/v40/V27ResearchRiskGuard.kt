package com.directvertex.v40

/**
 * V34 Research Risk Guard.
 *
 * Session-level statistical guard for analysis/replay only. A session loss
 * limit is intentionally terminal for the current research session; the old
 * cooldownRemaining field was misleading because it was never enforced by
 * apply(). No order sizing or execution is performed here.
 */
object V27ResearchRiskGuard {
    data class Config(
        val maxConsecutiveLosses: Int = 3,
        val maxSessionLosses: Int = 5,
        val minSettledSamples: Int = 10
    )

    data class State(
        val settled: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val consecutiveLosses: Int = 0,
        val cooldownRemaining: Int = 0,
        val blocked: Boolean = true,
        val reason: String = "Belum ada data settled"
    )

    fun evaluate(records: List<RecordedSignal>, config: Config = Config()): State {
        val settled = records.filter { it.outcome != Outcome.PENDING }
        var wins=0; var losses=0; var draws=0; var streak=0; var maxStreak=0
        settled.sortedBy { it.timestamp }.forEach { r ->
            when(r.outcome){
                Outcome.WIN->{wins++;streak=0}
                Outcome.LOSS->{losses++;streak++;maxStreak=maxOf(maxStreak,streak)}
                Outcome.DRAW->{draws++;streak=0}
                Outcome.PENDING->Unit
            }
        }
        val limit=losses>=config.maxSessionLosses||maxStreak>=config.maxConsecutiveLosses
        val blocked=settled.size<config.minSettledSamples||limit
        val reason=when{
            settled.size<config.minSettledSamples->"Sample settled ${settled.size}/${config.minSettledSamples}"
            maxStreak>=config.maxConsecutiveLosses->"Max losing streak tercapai: $maxStreak (session block)"
            losses>=config.maxSessionLosses->"Batas loss sesi tercapai: $losses (session block)"
            else->"Session research stabil"
        }
        return State(settled.size,wins,losses,draws,streak,0,blocked,reason)
    }

    fun apply(candidate: V26SignalGovernor.Decision, state: State): V26SignalGovernor.Decision {
        if(!candidate.admitted||state.blocked){
            val reason=if(state.blocked)"V27 BLOCK • ${state.reason}" else "V27 PASSIVE"
            return candidate.copy(direction="WAIT",admitted=false,status="V27_BLOCKED",reasons=(candidate.reasons+reason).distinct())
        }
        return candidate.copy(reasons=(candidate.reasons+"V27 research guard PASS").distinct())
    }
}
