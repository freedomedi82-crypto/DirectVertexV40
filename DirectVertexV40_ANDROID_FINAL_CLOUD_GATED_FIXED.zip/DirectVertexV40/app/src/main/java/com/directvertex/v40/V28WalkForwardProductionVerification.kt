package com.directvertex.v40

/**
 * V28: strict walk-forward production verification for replay/research only.
 * Every OOS decision is generated from data strictly before the decision time.
 * No order execution, sizing, or broker automation is performed.
 */
object V28WalkForwardProductionVerification {
    enum class Verdict { READY, USABLE, FRAGILE, INCONCLUSIVE }
    data class Fold(val number:Int, val trainN:Int, val testN:Int, val wins:Int, val losses:Int, val draws:Int, val winRate:Double, val coverage:Double, val maxLoss:Int)
    data class Report(
        val points:Int=0, val folds:Int=0, val oosTrades:Int=0, val wins:Int=0, val losses:Int=0, val draws:Int=0,
        val winRate:Double=0.0, val coverage:Double=0.0, val maxLosingStreak:Int=0,
        val leakageFree:Boolean=true, val verdict:Verdict=Verdict.INCONCLUSIVE,
        val note:String="Belum diuji", val foldsDetail:List<Fold> = emptyList()
    )

    fun run(points: List<ReplayPoint>, expirySteps:Int=3, foldsCount:Int=5, minTrain:Int=40):Report {
        val s=points.sortedBy { it.timestamp }
        if(s.size < minTrain + foldsCount*8 + expirySteps + 1) return Report(points=s.size,note="Data replay belum cukup untuk walk-forward")
        if(s.zipWithNext().any { it.second.timestamp<=it.first.timestamp || !it.first.price.isFinite() || it.first.price<=0.0 })
            return Report(points=s.size,verdict=Verdict.FRAGILE,note="Timestamp duplikat/tidak urut atau harga invalid")

        val usable=s.size-expirySteps
        val testBlock=((usable-minTrain)/foldsCount).coerceAtLeast(5)
        val folds=mutableListOf<Fold>(); var allW=0; var allL=0; var allD=0; var allDec=0; var maxLoss=0
        for(f in 0 until foldsCount){
            val trainEnd=minTrain+f*testBlock
            val testEnd=if(f==foldsCount-1) usable else (trainEnd+testBlock).coerceAtMost(usable)
            if(testEnd<=trainEnd) continue
            // Model is fit only on train history; test observations are never used to create decisions.
            val train=s.subList(0,trainEnd).map { it.price }
            val threshold=fitThreshold(train)
            var w=0; var l=0; var d=0; var dec=0; var streak=0; var foldMax=0
            for(i in trainEnd until testEnd){
                val history=s.subList(0,i+1).map { it.price }
                val dir=decision(history,threshold) ?: continue
                dec++
                val entry=s[i].price; val exit=s[i+expirySteps].price; val delta=exit-entry
                when { kotlin.math.abs(delta)<entry*1e-5 -> {d++; streak=0}
                    (dir=="CALL"&&delta>0)||(dir=="PUT"&&delta<0) -> {w++; streak=0}
                    else -> {l++; streak++; foldMax=maxOf(foldMax,streak)} }
            }
            allW+=w; allL+=l; allD+=d; allDec+=dec; maxLoss=maxOf(maxLoss,foldMax)
            val settled=w+l
            folds += Fold(f+1,trainEnd,testEnd-trainEnd,w,l,d,if(settled>0)w*100.0/settled else 0.0,dec*100.0/(testEnd-trainEnd).coerceAtLeast(1),foldMax)
        }
        val settled=allW+allL
        val wr=if(settled>0)allW*100.0/settled else 0.0
        val coverage=allDec*100.0/((usable-minTrain).coerceAtLeast(1))
        val rates=folds.map { it.winRate }.filter { it>0 }
        val consistency=if(rates.isEmpty())0.0 else rates.count{it>=50.0}*100.0/rates.size
        val verdict=when{
            allDec<30||folds.size<3->Verdict.INCONCLUSIVE
            wr>=58&&consistency>=80&&maxLoss<=7->Verdict.READY
            wr>=52&&consistency>=60&&maxLoss<=10->Verdict.USABLE
            else->Verdict.FRAGILE
        }
        return Report(s.size,folds.size,allDec,allW,allL,allD,wr,coverage,maxLoss,true,verdict,
            "Strict OOS: setiap fold hanya memakai history sebelum titik keputusan; consistency ${"%.0f".format(consistency)}%",folds)
    }

    private fun fitThreshold(train:List<Double>):Double{
        if(train.size<12)return 0.00015
        val moves=train.zipWithNext().map{(b,a)->(a-b)/b}.takeLast(48)
        val scale=moves.map{kotlin.math.abs(it)}.average().coerceIn(0.00003,0.0008)
        return (scale*0.75).coerceIn(0.00008,0.00035)
    }
    private fun decision(h:List<Double>,threshold:Double):String?{
        if(h.size<8)return null
        val s=h.takeLast(4).average(); val l=h.takeLast(8).average(); val last=h.last(); val spread=(s-l)/l
        return when { last>s&&spread>threshold->"CALL"; last<s&&spread< -threshold->"PUT"; else->null }
    }
}
