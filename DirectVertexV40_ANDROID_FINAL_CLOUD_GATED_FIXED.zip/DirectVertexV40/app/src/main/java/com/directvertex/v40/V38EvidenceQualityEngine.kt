package com.directvertex.v40

import kotlin.math.sqrt

/**
 * V38: Precision Profile / Evidence Gate.
 *
 * Purpose: reduce false confidence caused by clustered/overlapping observations.
 * This is an analysis-only gate. It never places or executes an order.
 */
object V38EvidenceQualityEngine {
    data class Config(
        val minimumIndependentSamples: Int = 20,
        val minimumRecentIndependentSamples: Int = 8,
        val recentWindowIndependent: Int = 12,
        val clusterGapSeconds: Long = 30L,
        val minimumLower95: Double = 0.52,
        val minimumPosterior: Double = 0.60,
        val minimumRecentWinRate: Double = 0.55,
        val maximumRegimeWeight: Double = 0.25,
        val payout: Double = 0.80,
        val edge: Double = 0.05
    )

    data class Decision(
        val direction: String = "WAIT",
        val admitted: Boolean = false,
        val effectiveSamples: Int = 0,
        val recentSamples: Int = 0,
        val posterior: Double = 0.5,
        val lower95: Double = 0.0,
        val recentWinRate: Double = 0.0,
        val requiredProbability: Double = 0.0,
        val independenceRatio: Double = 0.0,
        val reason: String = "V37 menunggu evidence"
    )

    private data class Stats(val wins: Int, val losses: Int) {
        val n: Int get() = wins + losses
        val posterior: Double get() = (wins + 0.5) / (n + 1.0)
    }

    fun evaluate(
        candidate: V36DecisionIntegrityEngine.Decision,
        records: List<RecordedSignal>,
        regime: String? = null,
        now: Long = System.currentTimeMillis(),
        config: Config = Config()
    ): Decision {
        if (!candidate.admitted || (candidate.direction != "CALL" && candidate.direction != "PUT")) {
            return Decision(reason = "V36 belum PASS")
        }

        val settled = records.asSequence()
            .filter { it.timestamp < now && (it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS) }
            .sortedBy { it.timestamp }
            .toList()
        val directional = settled.filter { it.direction == candidate.direction }
        val independent = clusterIndependent(directional, config.clusterGapSeconds)
        val recent = independent.takeLast(config.recentWindowIndependent)
        val globalIndependent = clusterIndependent(settled, config.clusterGapSeconds)

        val d = stats(independent)
        val g = stats(globalIndependent)
        val r = stats(recent)
        val regimeRows = if (!regime.isNullOrBlank()) independent.filter { (it.regime ?: "UNKNOWN") == regime } else emptyList()
        val rs = stats(regimeRows)

        // Empirical-Bayes shrinkage: small direction samples borrow strength from global evidence.
        val priorN = 12.0
        val dw = d.n / (d.n + priorN).coerceAtLeast(1.0)
        var posterior = d.posterior * dw + g.posterior * (1.0 - dw)

        // Regime evidence can help, but is explicitly capped to avoid overfitting a tiny regime.
        if (rs.n >= 8) {
            val rw = (rs.n / (rs.n + priorN)).coerceIn(0.0, 1.0) * config.maximumRegimeWeight
            posterior = posterior * (1.0 - rw) + rs.posterior * rw
        }
        posterior = posterior.coerceIn(0.05, 0.95)

        val (lower, _) = wilson(d.wins, d.n)
        val recentWr = if (r.n == 0) 0.0 else r.wins.toDouble() / r.n
        val originalN = directional.size
        val independenceRatio = if (originalN == 0) 0.0 else d.n.toDouble() / originalN
        val payout = config.payout.coerceIn(0.01, 0.99)
        val breakEven = 1.0 / (1.0 + payout)
        val required = (breakEven + config.edge).coerceIn(0.50, 0.95)

        val reasons = mutableListOf<String>()
        if (d.n < config.minimumIndependentSamples) reasons += "Independent evidence ${d.n}/${config.minimumIndependentSamples}"
        if (r.n < config.minimumRecentIndependentSamples) reasons += "Recent independent evidence ${r.n}/${config.minimumRecentIndependentSamples}"
        if (r.n >= config.minimumRecentIndependentSamples && recentWr < config.minimumRecentWinRate) reasons += "Recent WR ${"%.0f".format(recentWr * 100)}% < ${"%.0f".format(config.minimumRecentWinRate * 100)}%"
        if (posterior < config.minimumPosterior) reasons += "Posterior ${"%.1f".format(posterior * 100)}% < ${"%.1f".format(config.minimumPosterior * 100)}%"
        if (d.n >= config.minimumIndependentSamples && lower < config.minimumLower95) reasons += "Lower95 ${"%.1f".format(lower * 100)}% < ${"%.1f".format(config.minimumLower95 * 100)}%"
        if (candidate.probability < required) reasons += "P ${"%.1f".format(candidate.probability * 100)}% < required ${"%.1f".format(required * 100)}%"

        val admitted = reasons.isEmpty()
        return Decision(
            direction = if (admitted) candidate.direction else "WAIT",
            admitted = admitted,
            effectiveSamples = d.n,
            recentSamples = r.n,
            posterior = posterior,
            lower95 = lower,
            recentWinRate = recentWr,
            requiredProbability = required,
            independenceRatio = independenceRatio,
            reason = if (admitted) {
                "V37 EVIDENCE PASS • ${candidate.direction} • N=${d.n} • lower95=${"%.1f".format(lower * 100)}% • independence=${"%.0f".format(independenceRatio * 100)}%"
            } else reasons.joinToString(" • ")
        )
    }

    private fun clusterIndependent(rows: List<RecordedSignal>, gapSeconds: Long): List<RecordedSignal> {
        if (rows.isEmpty()) return emptyList()
        val sorted = rows.sortedBy { it.timestamp }
        val out = ArrayList<RecordedSignal>()
        var lastAccepted = Long.MIN_VALUE
        val gapMs = gapSeconds.coerceAtLeast(1L) * 1000L
        for (r in sorted) {
            if (lastAccepted == Long.MIN_VALUE || r.timestamp - lastAccepted >= gapMs) {
                out += r
                lastAccepted = r.timestamp
            }
        }
        return out
    }

    private fun stats(rows: List<RecordedSignal>) = Stats(
        rows.count { it.outcome == Outcome.WIN },
        rows.count { it.outcome == Outcome.LOSS }
    )

    private fun wilson(wins: Int, n: Int): Pair<Double, Double> {
        if (n <= 0) return 0.0 to 0.0
        val z = 1.96
        val p = wins.toDouble() / n
        val den = 1.0 + z * z / n
        val center = (p + z * z / (2.0 * n)) / den
        val margin = z * sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / den
        return (center - margin).coerceIn(0.0, 1.0) to (center + margin).coerceIn(0.0, 1.0)
    }
}
