package com.directvertex.v40

/**
 * V23 End-to-End Replay Verification.
 *
 * Replays the same observable price stream without peeking ahead. Each decision
 * uses only prices already seen at that point. This is a verification harness,
 * not a claim of future performance and never executes platform orders.
 */
object V23EndToEndVerification {
    enum class Verdict { READY, USABLE, FRAGILE, INCONCLUSIVE }

    data class Trade(val index: Int, val direction: String, val entry: Double, val exit: Double, val outcome: String)
    data class Report(
        val points: Int = 0,
        val decisions: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val winRate: Double = 0.0,
        val maxLosingStreak: Int = 0,
        val coverage: Double = 0.0,
        val leakageFree: Boolean = true,
        val verdict: Verdict = Verdict.INCONCLUSIVE,
        val note: String = "Belum diuji",
        val trades: List<Trade> = emptyList()
    )

    fun run(points: List<ReplayPoint>, expirySteps: Int = 3, minWarmup: Int = 24): Report {
        if (points.size < minWarmup + expirySteps + 1) {
            return Report(points = points.size, leakageFree = true, note = "Data replay belum cukup")
        }
        val sorted = points.sortedBy { it.timestamp }
        if (sorted.zipWithNext().any { it.second.timestamp <= it.first.timestamp || !it.first.price.isFinite() || it.first.price <= 0.0 }) {
            return Report(points = sorted.size, leakageFree = true, verdict = Verdict.FRAGILE, note = "Timestamp tidak valid/duplikat atau harga invalid")
        }

        val trades = mutableListOf<Trade>()
        var losingStreak = 0
        var maxLoss = 0
        var decisions = 0
        for (i in minWarmup until sorted.size - expirySteps) {
            val history = sorted.subList(0, i + 1).map { it.price }
            val direction = directionalDecision(history) ?: continue
            decisions++
            val entry = sorted[i].price
            val exit = sorted[i + expirySteps].price
            val delta = exit - entry
            val outcome = when {
                kotlin.math.abs(delta) < entry * 0.00001 -> "DRAW"
                direction == "CALL" && delta > 0 -> "WIN"
                direction == "PUT" && delta < 0 -> "WIN"
                else -> "LOSS"
            }
            if (outcome == "LOSS") { losingStreak++; maxLoss = maxOf(maxLoss, losingStreak) } else if (outcome == "WIN") losingStreak = 0
            trades += Trade(i, direction, entry, exit, outcome)
        }
        val wins = trades.count { it.outcome == "WIN" }
        val losses = trades.count { it.outcome == "LOSS" }
        val draws = trades.count { it.outcome == "DRAW" }
        val settled = wins + losses
        val wr = if (settled == 0) 0.0 else wins * 100.0 / settled
        val coverage = decisions * 100.0 / (sorted.size - minWarmup - expirySteps).coerceAtLeast(1)
        val verdict = when {
            trades.size < 30 -> Verdict.INCONCLUSIVE
            coverage < 15.0 -> Verdict.FRAGILE
            wr >= 58.0 && maxLoss <= 7 -> Verdict.READY
            wr >= 52.0 && maxLoss <= 10 -> Verdict.USABLE
            else -> Verdict.FRAGILE
        }
        return Report(sorted.size, decisions, wins, losses, draws, wr, maxLoss, coverage, true, verdict,
            "Replay end-to-end: hanya history hingga titik keputusan yang digunakan", trades.takeLast(100))
    }

    private fun directionalDecision(history: List<Double>): String? {
        if (history.size < 8) return null
        val short = history.takeLast(4).average()
        val long = history.takeLast(8).average()
        val last = history.last()
        val spread = (short - long) / long
        val threshold = 0.00015
        return when {
            last > short && spread > threshold -> "CALL"
            last < short && spread < -threshold -> "PUT"
            else -> null
        }
    }
}
