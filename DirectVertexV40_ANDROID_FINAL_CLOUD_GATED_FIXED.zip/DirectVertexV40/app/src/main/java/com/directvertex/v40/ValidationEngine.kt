package com.directvertex.v40

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

/** Statistical validation for offline replay results. No live trading/execution. */
data class ValidationStats(
    val sampleSize: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val winRate: Double,
    val wilsonLow: Double,
    val wilsonHigh: Double,
    val edge: Double,
    val profitFactor: Double,
    val avgScore: Double,
    val monteCarloMedianMaxLoss: Double,
    val monteCarloP95MaxLoss: Double,
    val verdict: String,
    val note: String
)

object ValidationEngine {
    fun evaluate(trades: List<WalkForwardTrade>, simulations: Int = 2000, seed: Int = 73): ValidationStats {
        val r = trades.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        val w = r.count { it.outcome == Outcome.WIN }
        val l = r.count { it.outcome == Outcome.LOSS }
        val n = w + l
        if (n == 0) return ValidationStats(0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,"INCONCLUSIVE","Belum ada trade WIN/LOSS yang selesai.")
        val p = w.toDouble()/n
        val (lo, hi) = wilson(w,n)
        val edge = (w-l).toDouble()/n
        val pf = if (l == 0) Double.POSITIVE_INFINITY else w.toDouble()/l
        val avg = r.map { it.score }.average()
        val maxLosses = monteCarloMaxLoss(w,l,simulations,seed).sorted()
        val median = percentile(maxLosses,0.50)
        val p95 = percentile(maxLosses,0.95)
        val verdict = when {
            n < 50 -> "INCONCLUSIVE"
            hi < 0.50 -> "FRAGILE"
            lo >= 0.50 && n >= 100 -> "ROBUST"
            lo >= 0.50 -> "PROMISING"
            else -> "INCONCLUSIVE"
        }
        val note = when(verdict) {
            "ROBUST" -> "Interval Wilson 95% tetap di atas 50%; masih perlu validasi lintas periode."
            "PROMISING" -> "Ada edge statistik, tetapi ukuran sampel masih terbatas."
            "FRAGILE" -> "Batas atas interval berada di bawah 50%; jangan anggap sinyal memiliki edge."
            else -> "Sampel belum cukup atau bukti statistik belum meyakinkan."
        }
        return ValidationStats(n,w,l,r.count{it.outcome==Outcome.DRAW},p*100,lo*100,hi*100,edge*100,pf,avg,median,p95,verdict,note)
    }

    private fun wilson(w:Int,n:Int):Pair<Double,Double>{
        val z=1.959963984540054
        val p=w.toDouble()/n; val d=1+z*z/n
        val c=(p+z*z/(2*n))/d
        val h=z*sqrt((p*(1-p)+z*z/(4*n))/n)/d
        return (c-h).coerceIn(0.0,1.0) to (c+h).coerceIn(0.0,1.0)
    }

    private fun monteCarloMaxLoss(w:Int,l:Int,simulations:Int,seed:Int):List<Int>{
        val out=ArrayList<Int>(simulations); val base=MutableList(w+l){it>=w}; val rng=Random(seed)
        repeat(simulations){
            val a=base.shuffled(rng); var cur=0; var mx=0
            for(loss in a){if(loss){cur++;mx=maxOf(mx,cur)}else cur=0}; out.add(mx)
        }; return out
    }
    private fun percentile(sorted:List<Int>,q:Double):Double{if(sorted.isEmpty())return 0.0; val x=(sorted.size-1)*q; val i=x.toInt(); val f=x-i; return if(i+1<sorted.size)sorted[i]+(sorted[i+1]-sorted[i])*f else sorted[i].toDouble()}
}
