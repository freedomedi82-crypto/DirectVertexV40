package com.directvertex.v40

/**
 * V39 Champion: final precision-first production gate.
 * It is deliberately abstention-biased: it may only keep a previously admitted
 * CALL/PUT or turn it into WAIT; it can never create a new direction.
 */
object V39ChampionEngine {
    data class Config(
        val minProbability: Double = 0.72,
        val minQuality: Double = 0.78,
        val minEffectiveSamples: Int = 24,
        val minRecentSamples: Int = 10,
        val minPosterior: Double = 0.62,
        val minLower95: Double = 0.54,
        val minRecentWinRate: Double = 0.58,
        val minIndependenceRatio: Double = 0.35,
        val minConsensus: Double = 0.80
    )
    data class Decision(
        val direction: String = "WAIT",
        val admitted: Boolean = false,
        val reason: String = "V39 menunggu evidence",
        val score: Double = 0.0
    )

    fun evaluate(
        candidate: V35DecisionStabilityEngine.Decision,
        integrity: V36DecisionIntegrityEngine.Decision,
        evidence: V38EvidenceQualityEngine.Decision,
        config: Config = Config()
    ): Decision {
        if (!candidate.admitted || !integrity.admitted || !evidence.admitted) {
            return Decision(reason = "V39: previous gate belum PASS")
        }
        val reasons = mutableListOf<String>()
        if (candidate.direction != evidence.direction) reasons += "direction conflict"
        if (candidate.probability < config.minProbability) reasons += "probability below 72%"
        if (candidate.quality < config.minQuality) reasons += "quality below 78%"
        if (evidence.effectiveSamples < config.minEffectiveSamples) reasons += "independent evidence below 24"
        if (evidence.recentSamples < config.minRecentSamples) reasons += "recent evidence below 10"
        if (evidence.posterior < config.minPosterior) reasons += "posterior below 62%"
        if (evidence.lower95 < config.minLower95) reasons += "Wilson lower95 below 54%"
        if (evidence.recentWinRate < config.minRecentWinRate) reasons += "recent WR below 58%"
        if (evidence.independenceRatio < config.minIndependenceRatio) reasons += "independence ratio too low"

        // Candidate quality is 0..1; V35 does not expose a model-consensus field,
        // so V39 treats stability admission itself as the consensus gate.
        val score = listOf(
            candidate.probability,
            candidate.quality,
            evidence.posterior,
            evidence.lower95,
            evidence.recentWinRate,
            evidence.independenceRatio.coerceIn(0.0, 1.0)
        ).average()

        return if (reasons.isEmpty()) {
            Decision(evidence.direction, true,
                "V39 CHAMPION PASS • precision-first • P=${"%.1f".format(candidate.probability * 100)}% • evidence=${evidence.effectiveSamples} • lower95=${"%.1f".format(evidence.lower95 * 100)}%",
                score)
        } else {
            Decision("WAIT", false, reasons.joinToString(" • "), score)
        }
    }
}
