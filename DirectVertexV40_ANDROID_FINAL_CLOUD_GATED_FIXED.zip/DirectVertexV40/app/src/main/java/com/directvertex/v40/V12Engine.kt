package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * V12: regime-aware rolling out-of-sample validation with a purge gap.
 * Offline only. No live execution and no future information is used for a decision.
 */
data class V12WindowResult(
    val window: Int,
    val trainTrades: Int,
    val validationTrades: Int,
    val testTrades: Int,
    val testWinRate: Double,
    val stability: Double,
    val regime: MarketRegime,
    val params: ParameterSet
)

data class V12Stats(
    val windows: Int,
    val validWindows: Int,
    val testTrades: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val winRate: Double,
    val calibratedProbability: Double,
    val consistency: Double,
    val maxLosingStreak: Int,
    val verdict: String,
    val note: String,
    val rows: List<V12WindowResult>
)

object V12Engine {
    private val grid = (74..90 step 2).flatMap { s -> listOf(30, 60, 120).map { e -> ParameterSet(s, e) } }

    fun evaluate(points: List<ReplayPoint>, folds: Int = 5): V12Stats {
        val p = points.sortedBy { it.timestamp }
        if (p.size < 240) return empty("Dataset minimal 240 titik untuk rolling out-of-sample.")
        val n = p.size
        val testSize = (n * 0.12).toInt().coerceAtLeast(20)
        val validationSize = (n * 0.12).toInt().coerceAtLeast(20)
        val rows = mutableListOf<V12WindowResult>()
        val allTest = mutableListOf<WalkForwardTrade>()
        val foldCount = folds.coerceIn(3, 8)

        for (f in 0 until foldCount) {
            val testEnd = n - f * testSize
            val testStart = testEnd - testSize
            val validEnd = testStart
            val validStart = validEnd - validationSize
            val trainEnd = validStart
            val trainStart = (trainEnd - (n * 0.40).toInt()).coerceAtLeast(0)
            if (trainStart >= trainEnd || validStart >= validEnd || testStart >= testEnd) continue

            // Purge a full maximum expiry around boundaries so overlapping outcomes
            // cannot cross from one information set into the next.
            val gapMs = 120_000L
            val train = p.subList(trainStart, trainEnd).filter { it.timestamp < p[validStart].timestamp - gapMs }
            val valid = p.subList(validStart, validEnd).filter { it.timestamp >= p[validStart].timestamp + gapMs && it.timestamp < p[testStart].timestamp - gapMs }
            val test = p.subList(testStart, testEnd).filter { it.timestamp >= p[testStart].timestamp + gapMs }
            if (train.size < 40 || valid.size < 20 || test.size < 15) continue

            val candidates = grid.mapNotNull { ps ->
                val tr = WalkForwardEngine(ps.expirySeconds).run(train, ps.minScore).first
                val va = WalkForwardEngine(ps.expirySeconds).run(valid, ps.minScore).first
                if (tr.trades < 5 || va.trades < 5) null else {
                    val stability = (1.0 - abs(tr.winRate - va.winRate) / 100.0).coerceIn(0.0, 1.0)
                    val objective = 0.50 * va.winRate / 100.0 + 0.25 * tr.winRate / 100.0 + 0.25 * stability
                    Triple(ps, objective, va.winRate)
                }
            }.sortedByDescending { it.second }
            val best = candidates.firstOrNull() ?: continue
            val testRun = WalkForwardEngine(best.first.expirySeconds).run(test, best.first.minScore)
            val ts = testRun.first
            if (ts.trades < 5) continue
            val regime = dominantRegime(testRun.second)
            val stability = candidates.take(3).map { it.third }.let { list ->
                if (list.isEmpty()) 0.0 else (1.0 - (list.maxOrNull()!! - list.minOrNull()!!) / 100.0).coerceIn(0.0, 1.0)
            }
            rows += V12WindowResult(f + 1, candidates.sumOf { 0 } + WalkForwardEngine(best.first.expirySeconds).run(train, best.first.minScore).first.trades, WalkForwardEngine(best.first.expirySeconds).run(valid, best.first.minScore).first.trades, ts.trades, ts.winRate, stability, regime, best.first)
            allTest += testRun.second
        }

        if (rows.size < 3 || allTest.isEmpty()) return empty("Belum cukup window out-of-sample yang valid setelah purge gap.")
        val resolved = allTest.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        val wins = resolved.count { it.outcome == Outcome.WIN }
        val losses = resolved.count { it.outcome == Outcome.LOSS }
        val draws = allTest.count { it.outcome == Outcome.DRAW }
        val total = wins + losses
        val wr = if (total == 0) 0.0 else wins.toDouble() / total * 100.0
        val calibrated = if (total == 0) 50.0 else (wins + 1.0) / (total + 2.0) * 100.0
        val mean = rows.map { it.testWinRate }.average()
        val sd = sqrt(rows.map { (it.testWinRate - mean) * (it.testWinRate - mean) }.average())
        val consistency = (100.0 - sd * 2.0).coerceIn(0.0, 100.0)
        var cur = 0; var max = 0
        allTest.forEach { if (it.outcome == Outcome.LOSS) { cur++; max = maxOf(max, cur) } else if (it.outcome == Outcome.WIN) cur = 0 }
        val verdict = when {
            total < 100 -> "INCONCLUSIVE"
            consistency >= 85 && wr >= 55 && rows.all { it.testTrades >= 10 } -> "ROBUST"
            consistency >= 72 && wr >= 52 -> "PROMISING"
            consistency < 55 -> "FRAGILE"
            else -> "INCONCLUSIVE"
        }
        val note = when (verdict) {
            "ROBUST" -> "Rolling test konsisten setelah purge; probabilitas dikalibrasi konservatif dengan smoothing Beta(1,1)."
            "PROMISING" -> "Ada indikasi edge, tetapi performa lintas window belum cukup kuat untuk disebut robust."
            "FRAGILE" -> "Performa berubah besar antar-window; kemungkinan regime dependence atau overfitting."
            else -> "Bukti belum cukup. Tambahkan data lintas periode sebelum menarik kesimpulan."
        }
        return V12Stats(foldCount, rows.size, allTest.size, wins, losses, draws, wr, calibrated, consistency, max, verdict, note, rows)
    }

    private fun dominantRegime(trades: List<WalkForwardTrade>): MarketRegime = trades.groupingBy { it.regime }.eachCount().maxByOrNull { it.value }?.key ?: MarketRegime.UNKNOWN
    private fun empty(note: String) = V12Stats(0,0,0,0,0,0,0.0,50.0,0.0,0,"INCONCLUSIVE",note,emptyList())
}
