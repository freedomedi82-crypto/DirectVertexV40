package com.directvertex.v40

import kotlin.math.abs

data class ReplayPoint(val timestamp: Long, val price: Double)

data class ReplayState(val index: Int = -1, val point: ReplayPoint? = null, val signal: SignalState = SignalState())

class ReplayEngine(private val signalEngine: SignalEngine = SignalEngine()) {
    private var points: List<ReplayPoint> = emptyList()
    private var index = -1
    private val temporal = TemporalEngine(12)
    private val candles = VirtualCandleBuilder()
    private var lastSignal: SignalState = SignalState()

    fun load(points: List<ReplayPoint>) { this.points = points.sortedBy { it.timestamp }; reset() }
    fun reset() { index = -1; temporal.clear(); candles.clear(); lastSignal = SignalState() }
    fun hasData() = points.isNotEmpty()
    fun size() = points.size
    fun state(): ReplayState = ReplayState(index, points.getOrNull(index), lastSignal)

    fun step(): ReplayState {
        if (index + 1 >= points.size) return state()
        index++
        val p = points[index]
        candles.add(p.price)
        val raw = SonarSnapshot(calibratedPrice = p.price, chartY = null)
        val smoothed = temporal.push(raw).copy(virtualCandle = candles.build())
        lastSignal = signalEngine.evaluate(smoothed, temporal.velocity())
        return ReplayState(index, p, lastSignal)
    }

    fun runToEnd(): ReplayState { while (index + 1 < points.size) step(); return state() }
}

object ReplayParser {
    fun parseCsv(text: String): List<ReplayPoint> {
        val rows = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toList()
        if (rows.isEmpty()) return emptyList()
        val out = mutableListOf<ReplayPoint>()
        rows.drop(if (rows.first().contains("price", true)) 1 else 0).forEachIndexed { i, row ->
            val c = row.split(',',';','\t').map { it.trim() }
            if (c.size >= 2) {
                val t = c[0].toLongOrNull() ?: (i * 1000L)
                val price = c[1].replace(',', '.').toDoubleOrNull()
                if (price != null) out += ReplayPoint(t, price)
            }
        }
        return out
    }
}
