package com.directvertex.v40

import kotlin.math.sqrt

/** V36: uncertainty-aware directional integrity gate. Analysis-only. */
object V36DecisionIntegrityEngine {
    data class Config(
        val minimumDirectionalSamples: Int = 20,
        val minimumRecentSamples: Int = 12,
        val recentWindow: Int = 20,
        val shrinkagePriorSamples: Double = 20.0,
        val minimumRecentWinRate: Double = 0.45,
        val defaultPayout: Double = 0.80,
        val minimumEdge: Double = 0.05,
        val maximumRequiredProbability: Double = 0.90
    )
    data class Decision(
        val direction: String = "WAIT",
        val admitted: Boolean = false,
        val probability: Double = 0.5,
        val requiredProbability: Double = 0.0,
        val posterior: Double = 0.5,
        val lower95: Double = 0.0,
        val recentWinRate: Double = 0.0,
        val directionalSamples: Int = 0,
        val regimeSamples: Int = 0,
        val reason: String = "V36 menunggu evidence settled"
    )
    private data class Stats(val wins: Int, val losses: Int) { val n get() = wins + losses; val posterior get() = (wins + 0.5) / (n + 1.0) }

    fun evaluate(candidate: V35DecisionStabilityEngine.Decision, records: List<RecordedSignal>, regime: String? = null, now: Long = System.currentTimeMillis(), payout: Double = Config().defaultPayout, config: Config = Config()): Decision {
        if (!candidate.admitted || (candidate.direction != "CALL" && candidate.direction != "PUT")) return Decision(reason = "V35 belum PASS")
        val direction = candidate.direction
        val settled = records.asSequence().filter { it.timestamp < now && (it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS) }.sortedBy { it.timestamp }.toList()
        val global = stats(settled)
        val directionalRows = settled.filter { it.direction == direction }
        val directional = stats(directionalRows)
        val recentStats = stats(directionalRows.takeLast(config.recentWindow))
        val regimeRows = if (!regime.isNullOrBlank()) directionalRows.filter { (it.regime ?: "UNKNOWN") == regime } else emptyList()
        val regimeStats = stats(regimeRows)
        val shrinkWeight = directional.n / (directional.n + config.shrinkagePriorSamples).coerceAtLeast(1.0)
        var posterior = directional.posterior * shrinkWeight + global.posterior * (1.0 - shrinkWeight)
        if (regimeStats.n >= config.minimumDirectionalSamples) {
            val rw = regimeStats.n / (regimeStats.n + config.shrinkagePriorSamples).coerceAtLeast(1.0)
            posterior = posterior * (1.0 - 0.20 * rw) + regimeStats.posterior * (0.20 * rw)
        }
        posterior = posterior.coerceIn(0.05, 0.95)
        val lower = wilsonLower(directional.wins, directional.n)
        val recentWr = if (recentStats.n == 0) 0.0 else recentStats.wins.toDouble() / recentStats.n
        val payoutSafe = payout.coerceIn(0.01, 0.99)
        val breakEven = 1.0 / (1.0 + payoutSafe)
        val uncertaintyPenalty = if (directional.n >= config.minimumDirectionalSamples) ((0.50 - lower).coerceAtLeast(0.0) * 0.10).coerceAtMost(0.08) else 0.04
        val required = (breakEven + config.minimumEdge + uncertaintyPenalty).coerceIn(0.50, config.maximumRequiredProbability)
        val reasons = mutableListOf<String>()
        if (directional.n < config.minimumDirectionalSamples) reasons += "Evidence $directional.n/${config.minimumDirectionalSamples} untuk $direction"
        if (recentStats.n >= config.minimumRecentSamples && recentWr < config.minimumRecentWinRate) reasons += "Recent WR ${"%.0f".format(recentWr * 100)}% < ${"%.0f".format(config.minimumRecentWinRate * 100)}%"
        if (candidate.probability < required) reasons += "P kandidat ${"%.1f".format(candidate.probability * 100)}% < required ${"%.1f".format(required * 100)}%"
        if (directional.n >= config.minimumDirectionalSamples && lower < breakEven) reasons += "Lower 95% ${"%.1f".format(lower * 100)}% < break-even ${"%.1f".format(breakEven * 100)}%"
        val admitted = reasons.isEmpty()
        return Decision(if (admitted) direction else "WAIT", admitted, candidate.probability, required, posterior, lower, recentWr, directional.n, regimeStats.n,
            if (admitted) "V36 INTEGRITY PASS • $direction • posterior ${"%.1f".format(posterior * 100)}% • lower95 ${"%.1f".format(lower * 100)}%" else reasons.joinToString(" • "))
    }
    private fun stats(rows: List<RecordedSignal>) = Stats(rows.count { it.outcome == Outcome.WIN }, rows.count { it.outcome == Outcome.LOSS })
    private fun wilsonLower(wins: Int, n: Int): Double {
        if (n <= 0) return 0.0
        val z = 1.96; val p = wins.toDouble() / n; val den = 1.0 + z*z/n
        val center = (p + z*z/(2.0*n))/den
        val margin = z*sqrt(p*(1.0-p)/n + z*z/(4.0*n*n))/den
        return (center-margin).coerceIn(0.0,1.0)
    }
}
