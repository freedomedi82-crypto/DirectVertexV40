package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Multi-window out-of-sample robustness evaluation.
 * Each test window is evaluated independently so no future window is used by a
 * previous window. This is a validation harness, not a live trading executor.
 */
data class RobustWindow(
    val index: Int,
    val start: Long,
    val end: Long,
    val trades: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val winRate: Double,
    val maxLosingStreak: Int,
    val verdict: String
)

data class RobustnessStats(
    val windows: Int,
    val validWindows: Int,
    val avgWinRate: Double,
    val medianWinRate: Double,
    val minWinRate: Double,
    val maxWinRate: Double,
    val winRateStdDev: Double,
    val positiveWindows: Int,
    val totalTrades: Int,
    val totalWins: Int,
    val totalLosses: Int,
    val consistency: Double,
    val verdict: String,
    val note: String,
    val details: List<RobustWindow>
)

object RobustnessEngine {
    fun evaluate(points: List<ReplayPoint>, expirySeconds: Int = 60, windows: Int = 5, minScore: Int = 76): RobustnessStats {
        val sorted = points.sortedBy { it.timestamp }
        if (sorted.size < 60 || windows < 2) return empty("Data belum cukup untuk multi-window OOS.")
        val w = windows.coerceIn(2, 10)
        val size = sorted.size / w
        val details = mutableListOf<RobustWindow>()
        for (i in 0 until w) {
            val from = i * size
            val to = if (i == w - 1) sorted.size else (i + 1) * size
            val slice = sorted.subList(from, to)
            val result = WalkForwardEngine(expirySeconds).run(slice, minScore)
            val s = result.first
            val verdict = when {
                s.trades < 10 -> "SMALL"
                s.winRate >= 55.0 -> "POSITIVE"
                s.winRate < 45.0 -> "NEGATIVE"
                else -> "NEUTRAL"
            }
            details += RobustWindow(i + 1, slice.first().timestamp, slice.last().timestamp, s.trades, s.wins, s.losses, s.draws, s.winRate, s.maxLosingStreak, verdict)
        }
        val valid = details.filter { it.trades >= 10 }
        if (valid.isEmpty()) return empty("Tidak ada window dengan minimal 10 trade terselesaikan.", details)
        val rates = valid.map { it.winRate }.sorted()
        val avg = rates.average()
        val median = if (rates.size % 2 == 1) rates[rates.size / 2] else (rates[rates.size / 2 - 1] + rates[rates.size / 2]) / 2.0
        val min = rates.first(); val max = rates.last()
        val sd = sqrt(rates.map { (it - avg) * (it - avg) }.average())
        val positive = valid.count { it.winRate >= 50.0 }
        val consistency = positive.toDouble() / valid.size * 100.0
        val verdict = when {
            valid.size < 3 -> "INCONCLUSIVE"
            consistency >= 80.0 && avg >= 52.0 && sd <= 8.0 -> "ROBUST"
            consistency >= 60.0 && avg >= 50.0 -> "PROMISING"
            positive <= valid.size / 2 -> "FRAGILE"
            else -> "INCONCLUSIVE"
        }
        val note = when (verdict) {
            "ROBUST" -> "Performa relatif konsisten di mayoritas window OOS; tetap uji dataset lain."
            "PROMISING" -> "Ada konsistensi, tetapi variasi antar-window masih perlu diperiksa."
            "FRAGILE" -> "Performa tidak konsisten lintas window; kemungkinan sensitif terhadap regime/periode."
            else -> "Bukti belum cukup untuk menyimpulkan robustness."
        }
        return RobustnessStats(w, valid.size, avg, median, min, max, sd, positive, valid.sumOf { it.trades }, valid.sumOf { it.wins }, valid.sumOf { it.losses }, consistency, verdict, note, details)
    }

    private fun empty(note: String, details: List<RobustWindow> = emptyList()) = RobustnessStats(0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 0, 0, 0.0, "INCONCLUSIVE", note, details)
}
