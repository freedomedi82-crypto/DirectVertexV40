package com.directvertex.v40

import java.util.ArrayDeque

import kotlin.math.abs

class TemporalEngine(private val capacity: Int = 12) {
    private val samples = ArrayDeque<SonarSnapshot>()
    fun push(s: SonarSnapshot): SonarSnapshot {
        samples.addLast(s); while (samples.size > capacity) samples.removeFirst()
        val list = samples.toList()
        fun avg(f: (SonarSnapshot) -> Float) = list.map(f).average().toFloat()
        val priceList = list.mapNotNull { it.calibratedPrice }
        val chartY = list.mapNotNull { it.chartY }.takeIf { it.isNotEmpty() }?.average()?.toFloat()
        val price = priceList.takeIf { it.isNotEmpty() }?.average()
        val velocity = if (priceList.size >= 2) priceList.last() - priceList.first() else null
        val stepDiffs = priceList.zipWithNext { a,b -> b-a }
        val meanStep = stepDiffs.averageOrNull() ?: 0.0
        val volatility = if (stepDiffs.isNotEmpty()) {
            val m = meanStep; kotlin.math.sqrt(stepDiffs.map { (it-m)*(it-m) }.average())
        } else 0.0
        val trendStrength = if (priceList.size >= 3) {
            val span = (priceList.maxOrNull()!! - priceList.minOrNull()!!).coerceAtLeast(1e-12)
            abs(velocity ?: 0.0) / span
        } else 0.0
        val acceleration = if (stepDiffs.size >= 2) stepDiffs.last() - stepDiffs.first() else 0.0
        val support = priceList.minOrNull()
        val resistance = priceList.maxOrNull()
        val last = priceList.lastOrNull()
        return s.copy(
            greenRatio = avg { it.greenRatio }, redRatio = avg { it.redRatio }, chartY = chartY,
            calibratedPrice = price, distanceFromEntry = price?.let { it - (samples.firstOrNull()?.calibratedPrice ?: it) },
            velocity = velocity, sampleCount = samples.size, trendStrength = trendStrength,
            volatility = volatility, acceleration = acceleration,
            supportDistance = if (last != null && support != null) last-support else null,
            resistanceDistance = if (last != null && resistance != null) resistance-last else null
        )
    }
    fun velocity(): Double? = samples.mapNotNull { it.calibratedPrice }.let { p -> if (p.size >= 2) p.last() - p.first() else null }
    fun size() = samples.size
    fun clear() = samples.clear()
}

private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()
