package com.directvertex.v40

import kotlin.math.abs

/**
 * V30: true chronological replay of the actual visual/replay SignalEngine.
 * Research/analysis only. No order execution, broker automation, or sizing.
 *
 * At decision index i, ReplayEngine has seen only points [0..i].
 * The outcome at i+h is evaluated only after the decision is made.
 */
object V30TrueEndToEndWalkForward {
    enum class Verdict { READY, USABLE, FRAGILE, INCONCLUSIVE, BLOCKED_DATA }

    data class Fold(
        val number: Int,
        val trainN: Int,
        val testN: Int,
        val decisions: Int,
        val wins: Int,
        val losses: Int,
        val draws: Int,
        val winRate: Double,
        val coverage: Double,
        val maxLoss: Int
    )

    data class Report(
        val points: Int = 0,
        val folds: Int = 0,
        val decisions: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val winRate: Double = 0.0,
        val coverage: Double = 0.0,
        val maxLosingStreak: Int = 0,
        val leakageFree: Boolean = true,
        val dataGate: V29MarketDataIntegrity.Verdict = V29MarketDataIntegrity.Verdict.BLOCKED,
        val verdict: Verdict = Verdict.INCONCLUSIVE,
        val note: String = "Belum diuji",
        val foldsDetail: List<Fold> = emptyList()
    )

    fun run(
        points: List<ReplayPoint>,
        expirySteps: Int = 3,
        foldsCount: Int = 5,
        minTrain: Int = 40
    ): Report {
        val clean = points.sortedBy { it.timestamp }
        val gate = V29MarketDataIntegrity.evaluate(clean, expirySteps.coerceAtLeast(1))
        if (gate.verdict == V29MarketDataIntegrity.Verdict.BLOCKED) {
            return Report(points = clean.size, dataGate = gate.verdict, verdict = Verdict.BLOCKED_DATA,
                note = "V29 memblokir replay: ${gate.issues.joinToString(" • ").ifBlank { gate.note }}")
        }
        if (clean.size < minTrain + foldsCount * 8 + expirySteps + 1) {
            return Report(points = clean.size, dataGate = gate.verdict,
                note = "Data belum cukup untuk V30 true end-to-end walk-forward")
        }
        if (clean.zipWithNext().any { it.second.timestamp <= it.first.timestamp }) {
            return Report(points = clean.size, dataGate = gate.verdict, verdict = Verdict.BLOCKED_DATA,
                note = "Timestamp tidak strictly increasing")
        }

        val usable = clean.size - expirySteps
        val testBlock = ((usable - minTrain) / foldsCount).coerceAtLeast(8)
        val folds = mutableListOf<Fold>()
        var allD = 0
        var allW = 0
        var allL = 0
        var allDraw = 0
        var globalStreak = 0
        var globalMax = 0

        for (f in 0 until foldsCount) {
            val trainEnd = minTrain + f * testBlock
            val testEnd = if (f == foldsCount - 1) usable else (trainEnd + testBlock).coerceAtMost(usable)
            if (testEnd <= trainEnd) continue

            // Fresh engine per fold prevents state from later observations leaking backward.
            val engine = ReplayEngine()
            engine.load(clean.subList(0, testEnd))
            var w = 0; var l = 0; var d = 0; var dec = 0
            var foldStreak = 0; var foldMax = 0

            for (i in 0 until testEnd) {
                val state = engine.step()
                if (i < trainEnd) continue
                if (i + expirySteps >= clean.size) break

                val direction = state.signal.direction
                if (direction != "CALL" && direction != "PUT") continue
                dec++
                val entry = clean[i].price
                val exit = clean[i + expirySteps].price
                val delta = exit - entry
                val draw = abs(delta) <= entry * 1e-5
                when {
                    draw -> { d++; allDraw++; foldStreak = 0; globalStreak = 0 }
                    (direction == "CALL" && delta > 0) || (direction == "PUT" && delta < 0) -> {
                        w++; allW++; foldStreak = 0; globalStreak = 0
                    }
                    else -> {
                        l++; allL++; foldStreak++; globalStreak++
                        foldMax = maxOf(foldMax, foldStreak)
                        globalMax = maxOf(globalMax, globalStreak)
                    }
                }
            }

            val settled = w + l
            folds += Fold(
                f + 1, trainEnd, testEnd - trainEnd, dec, w, l, d,
                if (settled > 0) w * 100.0 / settled else 0.0,
                dec * 100.0 / (testEnd - trainEnd).coerceAtLeast(1), foldMax
            )
            allD += dec
        }

        val settled = allW + allL
        val wr = if (settled > 0) allW * 100.0 / settled else 0.0
        val coverage = allD * 100.0 / ((usable - minTrain).coerceAtLeast(1))
        val foldRates = folds.mapNotNull { if (it.wins + it.losses > 0) it.winRate else null }
        val consistency = if (foldRates.isEmpty()) 0.0 else foldRates.count { it >= 50.0 } * 100.0 / foldRates.size
        val verdict = when {
            allD < 30 || folds.size < 3 -> Verdict.INCONCLUSIVE
            wr >= 58.0 && consistency >= 80.0 && globalMax <= 7 -> Verdict.READY
            wr >= 52.0 && consistency >= 60.0 && globalMax <= 10 -> Verdict.USABLE
            else -> Verdict.FRAGILE
        }
        return Report(
            points = clean.size, folds = folds.size, decisions = allD, wins = allW, losses = allL,
            draws = allDraw, winRate = wr, coverage = coverage, maxLosingStreak = globalMax,
            leakageFree = true, dataGate = gate.verdict, verdict = verdict,
            note = "True replay: ReplayEngine/SignalEngine berjalan kronologis; keputusan di i hanya melihat [0..i]. Consistency ${"%.0f".format(consistency)}%",
            foldsDetail = folds
        )
    }
}
