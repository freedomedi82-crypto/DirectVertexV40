package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class V17Config(
    val threshold: Double,
    val expirySeconds: Int
)

data class V17Fold(
    val fold: Int,
    val config: V17Config,
    val trainN: Int,
    val validationN: Int,
    val testN: Int,
    val testWinRate: Double,
    val drawRate: Double,
    val maxLossStreak: Int,
    val stability: Double
)

data class V17Report(
    val verdict: String,
    val robustnessScore: Double,
    val selected: V17Config?,
    val folds: List<V17Fold>,
    val overfitGap: Double,
    val stressPassRate: Double,
    val reasons: List<String>
)

/**
 * V17 Autonomous Backtest & Model Selection Lab.
 *
 * Purpose: automatically select conservative configurations and reject
 * unstable/overfit candidates using rolling train/validation/test folds.
 *
 * Analysis-only. It never places or executes trades.
 */
object V17ModelSelectionLab {

    fun run(
        points: List<Pair<Long, Double>>,
        scoreBase: Double = 74.0,
        expiryOptions: List<Int> = listOf(30, 60, 120)
    ): V17Report {
        if (points.size < 30) {
            return V17Report(
                "INCONCLUSIVE", 0.0, null, emptyList(), 0.0, 0.0,
                listOf("Not enough replay samples; collect a larger dataset.")
            )
        }

        val sorted = points.sortedBy { it.first }
        val thresholds = listOf(-4.0, -2.0, 0.0, 2.0, 4.0).map { scoreBase + it }
        val configs = thresholds.flatMap { t ->
            expiryOptions.map { e -> V17Config(t.coerceIn(50.0, 95.0), e) }
        }

        val folds = mutableListOf<V17Fold>()
        val n = sorted.size
        val foldCount = 5

        for (i in 0 until foldCount) {
            val trainEnd = ((i + 1) * n * 0.45 / foldCount).toInt().coerceAtLeast(10)
            val validEnd = (trainEnd + n * 0.10).toInt().coerceAtMost(n - 5)
            val testEnd = (validEnd + n * 0.09).toInt().coerceAtMost(n)
            if (testEnd <= validEnd || validEnd <= trainEnd) continue

            val train = sorted.subList(0, trainEnd)
            val valid = sorted.subList(trainEnd, validEnd)
            val test = sorted.subList(validEnd, testEnd)

            var best: V17Config? = null
            var bestObjective = Double.NEGATIVE_INFINITY

            for (cfg in configs) {
                val tr = evaluate(train, cfg)
                val va = evaluate(valid, cfg)
                if (va.n < 3) continue

                val objective =
                    0.65 * va.winRate +
                    0.20 * tr.winRate -
                    0.10 * min(1.0, va.lossStreak / 6.0) -
                    0.05 * abs(va.winRate - tr.winRate)

                if (objective > bestObjective) {
                    bestObjective = objective
                    best = cfg
                }
            }

            if (best != null) {
                val tr = evaluate(train, best)
                val va = evaluate(valid, best)
                val te = evaluate(test, best)
                val gap = abs(va.winRate - tr.winRate)
                val stability = (1.0 - min(1.0, gap * 2.5)).coerceIn(0.0, 1.0)

                folds += V17Fold(
                    i + 1, best, tr.n, va.n, te.n,
                    te.winRate, te.drawRate, te.lossStreak, stability
                )
            }
        }

        if (folds.isEmpty()) {
            return V17Report(
                "INCONCLUSIVE", 0.0, null, emptyList(), 0.0, 0.0,
                listOf("No valid rolling folds could be evaluated.")
            )
        }

        val avgWin = folds.map { it.testWinRate }.average()
        val avgStability = folds.map { it.stability }.average()
        val worstWin = folds.minOf { it.testWinRate }
        val overfitGap = folds.map { abs(it.testWinRate - 0.5) }.average()
        val stressPass = folds.count {
            it.testWinRate >= 0.50 && it.stability >= 0.55 && it.maxLossStreak <= 6
        }.toDouble() / folds.size

        val robustness =
            (100.0 * (
                0.45 * avgWin +
                0.25 * avgStability +
                0.20 * stressPass +
                0.10 * worstWin
            )).coerceIn(0.0, 100.0)

        val selected = folds.groupingBy { it.config }
            .eachCount()
            .maxByOrNull { it.value }?.key

        val reasons = mutableListOf<String>()
        reasons += "Average out-of-sample win rate: ${"%.1f".format(avgWin * 100)}%"
        reasons += "Worst fold win rate: ${"%.1f".format(worstWin * 100)}%"
        reasons += "Stress/quality pass rate: ${"%.1f".format(stressPass * 100)}%"
        reasons += "Average train-validation stability: ${"%.1f".format(avgStability * 100)}%"

        val verdict = when {
            folds.size < 4 -> "INCONCLUSIVE"
            stressPass >= 0.80 && avgWin >= 0.58 && worstWin >= 0.50 && avgStability >= 0.70 -> "ROBUST"
            stressPass >= 0.60 && avgWin >= 0.54 && avgStability >= 0.55 -> "PROMISING"
            avgStability < 0.40 || stressPass < 0.40 -> "OVERFIT RISK"
            else -> "FRAGILE"
        }

        return V17Report(
            verdict, robustness, selected, folds, overfitGap, stressPass, reasons
        )
    }

    private data class Eval(
        val n: Int,
        val wins: Int,
        val draws: Int,
        val lossStreak: Int
    ) {
        val winRate: Double get() = if (n == 0) 0.0 else wins.toDouble() / n
        val drawRate: Double get() = if (n == 0) 0.0 else draws.toDouble() / n
    }

    private fun evaluate(data: List<Pair<Long, Double>>, cfg: V17Config): Eval {
        if (data.size < 3) return Eval(0, 0, 0, 0)

        var wins = 0
        var draws = 0
        var losses = 0
        var currentLoss = 0
        var maxLoss = 0

        // Deterministic, leak-free directional replay approximation.
        for (i in 1 until data.size) {
            val prev = data[i - 1].second
            val cur = data[i].second
            val delta = cur - prev
            if (abs(delta) < 1e-9) {
                draws++
                currentLoss = 0
                continue
            }

            val direction = if (delta > 0) 1 else -1
            val confidence = min(100.0, cfg.threshold + abs(delta) * 10.0)
            if (confidence < cfg.threshold) continue

            // Evaluate next observed move when available; this avoids using
            // a future value to construct the current signal.
            if (i + 1 < data.size) {
                val nextDelta = data[i + 1].second - cur
                val nextDirection = if (nextDelta > 0) 1 else if (nextDelta < 0) -1 else 0
                when {
                    nextDirection == 0 -> draws++
                    nextDirection == direction -> {
                        wins++
                        currentLoss = 0
                    }
                    else -> {
                        losses++
                        currentLoss++
                        maxLoss = max(maxLoss, currentLoss)
                    }
                }
            }
        }

        return Eval(wins + losses + draws, wins, draws, maxLoss)
    }
}
