package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.min

enum class V20Gate {
    DATA_QUALITY, VISION_QUALITY, REGIME_ALIGNMENT,
    EVIDENCE_AGREEMENT, MODEL_VALIDATION, STRESS_RESILIENCE
}

data class V20GateResult(
    val gate: V20Gate,
    val passed: Boolean,
    val score: Double,
    val reason: String
)

data class V20Decision(
    val direction: String,
    val confidence: Double,
    val status: String,
    val gates: List<V20GateResult>,
    val reasons: List<String>,
    val blockers: List<String>
)

/**
 * V20 Decision Intelligence Core.
 *
 * A conservative final gate over the existing Direct Vertex research stack.
 * A directional signal is emitted only when minimum independent evidence
 * passes. Otherwise the result is WAIT.
 *
 * Analysis-only: no platform login, clicking, order placement, or automation.
 */
object V20DecisionIntelligenceCore {

    fun decide(
        candidateDirection: String,
        dataQuality: Double,
        visionQuality: Double,
        regimeAlignment: Double,
        evidenceAgreement: Double,
        modelValidation: Double,
        stressResilience: Double,
        rawConfidence: Double
    ): V20Decision {
        val values = listOf(
            dataQuality, visionQuality, regimeAlignment,
            evidenceAgreement, modelValidation, stressResilience
        ).map { it.coerceIn(0.0, 1.0) }

        val gates = listOf(
            V20Gate.DATA_QUALITY to values[0],
            V20Gate.VISION_QUALITY to values[1],
            V20Gate.REGIME_ALIGNMENT to values[2],
            V20Gate.EVIDENCE_AGREEMENT to values[3],
            V20Gate.MODEL_VALIDATION to values[4],
            V20Gate.STRESS_RESILIENCE to values[5]
        ).map { (gate, score) ->
            val threshold = when (gate) {
                V20Gate.DATA_QUALITY -> 0.70
                V20Gate.VISION_QUALITY -> 0.65
                V20Gate.REGIME_ALIGNMENT -> 0.55
                V20Gate.EVIDENCE_AGREEMENT -> 0.60
                V20Gate.MODEL_VALIDATION -> 0.60
                V20Gate.STRESS_RESILIENCE -> 0.55
            }
            V20GateResult(
                gate, score >= threshold, score,
                if (score >= threshold) "PASS" else "BLOCK"
            )
        }

        val passed = gates.count { it.passed }
        val blockers = gates.filterNot { it.passed }.map { it.gate.name }
        val mean = values.average()
        val weakest = values.minOrNull() ?: 0.0

        val confidence = (
            0.45 * rawConfidence.coerceIn(0.0, 1.0) +
            0.35 * mean +
            0.20 * weakest
        ).coerceIn(0.0, 1.0)

        val direction = candidateDirection.uppercase()
        val directional = direction == "CALL" || direction == "PUT"
        val finalDirection = if (directional && blockers.isEmpty() && confidence >= 0.64) {
            direction
        } else {
            "WAIT"
        }

        val status = when {
            finalDirection == "WAIT" && blockers.isNotEmpty() -> "BLOCKED"
            finalDirection == "WAIT" -> "LOW_CONFIDENCE"
            confidence >= 0.82 -> "HIGH_CONVICTION"
            confidence >= 0.70 -> "CONFIRMED"
            else -> "CAUTIOUS"
        }

        val reasons = mutableListOf<String>()
        if (gates.all { it.passed }) reasons += "All validation gates passed"
        if (mean >= 0.70) reasons += "Cross-layer evidence is strong"
        if (weakest >= 0.60) reasons += "No critical layer is weak"
        if (confidence >= 0.80) reasons += "High composite confidence"
        if (finalDirection == "WAIT") reasons += "Conservative WAIT filter activated"

        return V20Decision(
            finalDirection,
            confidence,
            status,
            gates,
            reasons.take(6),
            blockers
        )
    }
}
