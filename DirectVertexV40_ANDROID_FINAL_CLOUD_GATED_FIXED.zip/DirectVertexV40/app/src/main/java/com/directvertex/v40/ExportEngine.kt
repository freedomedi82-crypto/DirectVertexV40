package com.directvertex.v40

class ExportEngine {
    fun toJsonLines(records: List<RecordedSignal>): String {
        return records.joinToString("\n") { r ->
            buildString {
                append("{")
                append("\"id\":${r.id},")
                append("\"timestamp\":${r.timestamp},")
                append("\"direction\":\"${r.direction}\",")
                append("\"score\":${r.score},")
                append("\"confidence\":\"${r.confidence}\",")
                append("\"entryPrice\":${r.entryPrice ?: "null"},")
                append("\"expirySeconds\":${r.expirySeconds},")
                append("\"exitPrice\":${r.exitPrice ?: "null"},")
                append("\"outcome\":\"${r.outcome}\"")
                append("}")
            }
        }
    }
}
