package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * V34 leakage-safe probability calibration diagnostics.
 *
 * The input list is assumed to be chronological. Threshold selection is done
 * only on the calibration slice; all reported Brier/log-loss/ECE and threshold
 * performance are measured on a later untouched test slice.
 * Analysis/research only. No order execution.
 */
object V24CalibrationEngine {
    data class Sample(val probability: Double, val win: Boolean)
    data class Bin(val low: Double, val high: Double, val count: Int, val meanProbability: Double, val empiricalWinRate: Double)
    data class Report(
        val samples: Int = 0,
        val brierScore: Double = 1.0,
        val logLoss: Double = 10.0,
        val ece: Double = 1.0,
        val reliability: Double = 0.0,
        val recommendedMinProbability: Double = 0.65,
        val coverageAtThreshold: Double = 0.0,
        val winRateAtThreshold: Double = 0.0,
        val verdict: String = "INCONCLUSIVE",
        val note: String = "Belum diuji",
        val bins: List<Bin> = emptyList(),
        val calibrationSamples: Int = 0,
        val testSamples: Int = 0,
        val lower95AtThreshold: Double = 0.0,
        val upper95AtThreshold: Double = 0.0
    )

    private fun wilson(wins: Int, n: Int): Pair<Double, Double> {
        if (n <= 0) return 0.0 to 0.0
        val z = 1.96
        val p = wins.toDouble() / n
        val den = 1.0 + z*z/n
        val center = (p + z*z/(2*n)) / den
        val margin = z * sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
        return (center-margin).coerceIn(0.0,1.0) to (center+margin).coerceIn(0.0,1.0)
    }

    fun evaluate(samples: List<Sample>, binCount: Int = 10): Report {
        val clean = samples.filter { it.probability.isFinite() && it.probability in 0.0..1.0 }
        if (clean.size < 60) return Report(samples = clean.size, note = "Minimal 60 settled samples untuk evaluasi OOS V34")

        val warmupN = (clean.size * 0.60).toInt().coerceAtLeast(30)
        val calEnd = (clean.size * 0.80).toInt().coerceAtLeast(warmupN + 20).coerceAtMost(clean.size - 20)
        val calibration = clean.subList(warmupN, calEnd)
        val test = clean.subList(calEnd, clean.size)
        if (calibration.size < 20 || test.size < 20) return Report(clean.size, calibrationSamples=calibration.size, testSamples=test.size, note="Calibration/test fold terlalu kecil")

        val thresholds = listOf(0.55,0.60,0.65,0.70,0.75,0.80,0.85)
        val chosen = thresholds.maxByOrNull { t ->
            val rows = calibration.filter { it.probability >= t }
            if (rows.size < 10) -1.0 else {
                val wr = rows.count { it.win }.toDouble()/rows.size
                // Mild coverage preference; never lets coverage dominate accuracy.
                wr + 0.01 * sqrt(rows.size.toDouble()/calibration.size)
            }
        } ?: 0.65

        val brier = test.map { (p, win) -> (p - if (win) 1.0 else 0.0).pow(2) }.average()
        val logLoss = test.map { (p, win) ->
            val q = p.coerceIn(1e-6, 1.0-1e-6)
            if (win) -ln(q) else -ln(1.0-q)
        }.average()
        val bins = (0 until binCount).mapNotNull { i ->
            val low = i.toDouble()/binCount
            val high = (i+1).toDouble()/binCount
            val inBin = test.filter { it.probability >= low && (it.probability < high || i == binCount-1) }
            if (inBin.isEmpty()) null else Bin(low, high, inBin.size, inBin.map { it.probability }.average(), inBin.count { it.win }*100.0/inBin.size)
        }
        val ece = bins.sumOf { b -> b.count.toDouble()/test.size * abs(b.meanProbability*100.0-b.empiricalWinRate)/100.0 }
        val selected = test.filter { it.probability >= chosen }
        val wins = selected.count { it.win }
        val wr = if (selected.isEmpty()) 0.0 else wins*100.0/selected.size
        val coverage = selected.size*100.0/test.size
        val (lo,hi)=wilson(wins,selected.size)
        val reliability = (1.0-ece).coerceIn(0.0,1.0)
        val verdict = when {
            selected.size < 20 -> "INCONCLUSIVE"
            lo >= 0.50 && ece <= 0.10 && brier <= 0.25 -> "CALIBRATED"
            lo >= 0.45 && ece <= 0.15 -> "USABLE"
            else -> "FRAGILE"
        }
        return Report(clean.size,brier,logLoss,ece,reliability,chosen,coverage,wr,verdict,
            "V34 OOS: threshold dipilih di calibration slice, lalu diuji sekali pada test slice yang lebih baru. Ini mencegah threshold tuning pada test.",bins,
            calibration.size,test.size,lo*100.0,hi*100.0)
    }
}
