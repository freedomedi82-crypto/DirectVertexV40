package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * V32: Entry Quality & Anti-Chase Gate.
 *
 * Goal: improve entry precision by abstaining from weak/late entries rather
 * than manufacturing more signals. The gate uses only information available
 * at the decision point. It is research/analysis only and never executes an order.
 */
object V32EntryQualityEngine {
    data class Config(
        val minimumQuality: Double = 0.72,
        val minimumProbability: Double = 0.68,
        val minimumSamples: Int = 10,
        val minimumBoundaryRatio: Double = 0.08,
        val maximumVolatilityRatio: Double = 2.50
    )

    data class Decision(
        val direction: String = "WAIT",
        val quality: Double = 0.0,
        val probability: Double = 0.5,
        val admitted: Boolean = false,
        val status: String = "WAIT",
        val reasons: List<String> = emptyList(),
        val components: Map<String, Double> = emptyMap()
    )

    data class FoldStats(
        val fold: Int,
        val baselineDecisions: Int,
        val baselineWins: Int,
        val baselineLosses: Int,
        val gatedDecisions: Int,
        val gatedWins: Int,
        val gatedLosses: Int,
        val baselineWinRate: Double,
        val gatedWinRate: Double,
        val gatedCoverage: Double
    )

    data class Report(
        val points: Int = 0,
        val baselineDecisions: Int = 0,
        val baselineWins: Int = 0,
        val baselineLosses: Int = 0,
        val gatedDecisions: Int = 0,
        val gatedWins: Int = 0,
        val gatedLosses: Int = 0,
        val baselineWinRate: Double = 0.0,
        val gatedWinRate: Double = 0.0,
        val baselineCoverage: Double = 0.0,
        val gatedCoverage: Double = 0.0,
        val improvement: Double = 0.0,
        val rejectedEntries: Int = 0,
        val threshold: Double = 0.72,
        val folds: List<FoldStats> = emptyList(),
        val verdict: String = "INCONCLUSIVE",
        val note: String = "Belum diuji"
    )

    fun evaluate(signal: SignalState, probability: Double, config: Config = Config()): Decision {
        val s = signal.snapshot
        val direction = signal.direction
        if (direction != "CALL" && direction != "PUT") return Decision()
        val c = components(s, direction, config.minimumSamples)
        val quality = weighted(c)
        val p = probability.coerceIn(0.0, 1.0)
        val reasons = mutableListOf<String>()
        if (s.sampleCount < config.minimumSamples) reasons += "Sampel entry belum stabil"
        if (p < config.minimumProbability) reasons += "Probability entry rendah"
        if (quality < config.minimumQuality) reasons += "Entry quality ${"%.0f".format(quality * 100)}% < ${"%.0f".format(config.minimumQuality * 100)}%"
        val boundary = if (direction == "CALL") c["room"] ?: 0.0 else c["room"] ?: 0.0
        if ((c["hasBoundary"] ?: 0.0) < 0.5) reasons += "Boundary belum terdeteksi stabil"
        else if (boundary < config.minimumBoundaryRatio) reasons += "Terlalu dekat area ekstrem"
        val volRatio = c["volatility"] ?: 0.0
        if (volRatio < 0.35) reasons += "Momentum belum cukup dibanding noise"
        if (s.volatility > 0 && abs(s.velocity ?: 0.0) > 0 && s.volatility / abs(s.velocity ?: 0.0) > config.maximumVolatilityRatio) reasons += "Volatility shock"
        val admitted = reasons.isEmpty()
        val status = when {
            admitted && quality >= 0.82 && p >= 0.80 -> "A+ ENTRY"
            admitted -> "CONFIRMED ENTRY"
            else -> "WAIT ENTRY"
        }
        return Decision(if (admitted) direction else "WAIT", quality, p, admitted, status, reasons, c)
    }

    fun components(s: SonarSnapshot, direction: String, minimumSamples: Int = Config().minimumSamples): Map<String, Double> {
        val v = s.velocity ?: 0.0
        val a = s.acceleration
        val bullish = direction == "CALL"
        val momentum = when {
            abs(v) < 1e-12 -> 0.5
            (bullish && v > 0) || (!bullish && v < 0) -> 1.0
            else -> 0.0
        }
        val acceleration = when {
            abs(a) < 1e-12 -> 0.5
            (bullish && a > 0) || (!bullish && a < 0) -> 1.0
            else -> 0.0
        }
        val candle = when {
            s.virtualCandle.bias == "NEUTRAL" -> 0.5
            (bullish && s.virtualCandle.bias == "BULLISH") || (!bullish && s.virtualCandle.bias == "BEARISH") -> 1.0
            else -> 0.0
        }
        val trendStrength = s.trendStrength.coerceIn(0.0, 1.0)
        val trendAlignment = if (momentum == 0.5) 0.5 else momentum
        val trend = (0.35 * trendStrength + 0.65 * trendAlignment).coerceIn(0.0, 1.0)

        // V32.0 used `range == 0.5` as a missing-data sentinel. That is unsafe
        // because a legitimate price range can equal exactly 0.5. V33 uses an
        // explicit boundary-availability flag instead.
        val hasBoundary = s.supportDistance != null && s.resistanceDistance != null
        val candleRange = (s.virtualCandle.high ?: 0.0) - (s.virtualCandle.low ?: 0.0)
        val hasRange = candleRange.isFinite() && candleRange > 1e-12
        val roomRaw = if (!hasBoundary || !hasRange) 0.5 else {
            val room = if (bullish) s.resistanceDistance ?: 0.0 else s.supportDistance ?: 0.0
            (room / candleRange).coerceIn(0.0, 1.0)
        }
        val volatilityRatio = if (abs(v) < 1e-12 || s.volatility <= 0.0) 1.0 else abs(v) / s.volatility
        val volatility = when {
            volatilityRatio >= 2.0 -> 1.0
            volatilityRatio >= 1.0 -> 0.78
            volatilityRatio >= 0.50 -> 0.55
            else -> 0.20
        }
        val sample = (s.sampleCount.toDouble() / minimumSamples.coerceAtLeast(1)).coerceIn(0.0, 1.0)
        return linkedMapOf(
            "momentum" to momentum,
            "trend" to trend,
            "candle" to candle,
            "acceleration" to acceleration,
            "room" to roomRaw,
            "volatility" to volatilityRatio.coerceIn(0.0, 10.0),
            "volatilityQuality" to volatility,
            "samples" to sample,
            "hasBoundary" to if (hasBoundary) 1.0 else 0.0
        )
    }

    private fun weighted(c: Map<String, Double>): Double {
        val m = c["momentum"] ?: .5
        val t = c["trend"] ?: .5
        val candle = c["candle"] ?: .5
        val a = c["acceleration"] ?: .5
        val room = c["room"] ?: .5
        val vol = c["volatilityQuality"] ?: .5
        val sample = c["samples"] ?: .5
        return (m*.22 + t*.18 + candle*.14 + a*.10 + room*.18 + vol*.10 + sample*.08).coerceIn(0.0,1.0)
    }

    /** Strict chronological comparison: fixed gate, no tuning on the test fold. */
    fun runReplay(points: List<ReplayPoint>, expirySteps: Int, config: Config = Config(), foldCount: Int = 5): Report {
        val clean = points.filter { it.timestamp >= 0 && it.price.isFinite() && it.price > 0 }.distinctBy { it.timestamp }.sortedBy { it.timestamp }
        if (clean.size < 60 || expirySteps < 1) return Report(points=clean.size, threshold=config.minimumQuality, note="Minimal 60 titik diperlukan untuk entry OOS")
        val usable = clean.size - expirySteps
        var baseD=0; var baseW=0; var baseL=0; var gateD=0; var gateW=0; var gateL=0
        val foldRows = mutableListOf<FoldStats>()
        val foldSize = max(1, usable / foldCount)
        for (f in 0 until foldCount) {
            val start = f * foldSize
            val end = if (f == foldCount-1) usable else min(usable, (f+1)*foldSize)
            if (end - start < 8) continue
            val engine = ReplayEngine(SignalEngine())
            engine.load(clean)
            var bD=0; var bW=0; var bL=0; var gD=0; var gW=0; var gL=0
            for (i in 0 until end) {
                val st = engine.step()
                if (i < start || i + expirySteps >= clean.size) continue
                val s = st.signal
                if (s.direction != "CALL" && s.direction != "PUT") continue
                val delta = clean[i+expirySteps].price-clean[i].price
                val win = (s.direction=="CALL" && delta>0) || (s.direction=="PUT" && delta<0)
                val draw = abs(delta) <= clean[i].price*1e-5
                if (!draw) { bD++; if(win)bW++ else bL++ }
                val q = evaluate(s, 0.70, config.copy(minimumProbability=0.0))
                if (q.admitted && !draw) { gD++; if(win)gW++ else gL++ }
            }
            val bwr=if(bD>0)bW*100.0/bD else 0.0
            val gwr=if(gD>0)gW*100.0/gD else 0.0
            val cov=if(bD>0)gD*100.0/bD else 0.0
            foldRows += FoldStats(f+1,bD,bW,bL,gD,gW,gL,bwr,gwr,cov)
            baseD+=bD;baseW+=bW;baseL+=bL;gateD+=gD;gateW+=gW;gateL+=gL
        }
        val bwr=if(baseD>0)baseW*100.0/baseD else 0.0
        val gwr=if(gateD>0)gateW*100.0/gateD else 0.0
        val improvement=gwr-bwr
        val coverage=gateD*100.0/baseD.coerceAtLeast(1)
        val rejected=(baseD-gateD).coerceAtLeast(0)
        val positiveFolds=foldRows.count { it.gatedDecisions >= 5 && it.gatedWinRate >= it.baselineWinRate }
        val verdict=when {
            foldRows.size < 3 || gateD < 15 -> "INCONCLUSIVE"
            positiveFolds >= max(3, foldRows.size-1) && improvement >= 2.0 -> "PROMISING"
            positiveFolds >= 3 && improvement >= 0.0 -> "STABLE"
            improvement < -2.0 -> "REJECT GATE"
            else -> "FRAGILE"
        }
        val note="Gate tidak menambah signal; hanya menyaring entry. Klaim improvement valid bila OOS menunjukkan WR naik dengan sample tetap memadai."
        return Report(clean.size,baseD,baseW,baseL,gateD,gateW,gateL,bwr,gwr,100.0,coverage,improvement,rejected,config.minimumQuality,foldRows,verdict,note)
    }
}
