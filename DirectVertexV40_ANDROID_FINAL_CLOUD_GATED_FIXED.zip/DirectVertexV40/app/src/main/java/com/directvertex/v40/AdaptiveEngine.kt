package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max

/** Offline adaptive layer. It learns which market regimes have historically produced
 * resolved wins/losses, then adjusts confidence. It never places orders. */
enum class MarketRegime { TREND_UP, TREND_DOWN, RANGE, REVERSAL, HIGH_VOLATILITY, UNKNOWN }

data class AdaptiveProfile(val regime: MarketRegime, val samples: Int, val winRate: Double, val multiplier: Double)

data class AdaptiveDecision(val regime: MarketRegime, val adjustedScore: Int, val confidence: String, val note: String)

class AdaptiveEngine {
    private val outcomes = mutableMapOf<MarketRegime, Pair<Int, Int>>() // wins, resolved losses

    fun classify(s: SonarSnapshot): MarketRegime {
        val v = s.velocity ?: 0.0
        val a = s.acceleration
        if (s.sampleCount < 4) return MarketRegime.UNKNOWN
        if (s.volatility > max(abs(v) * 1.8, 1e-12)) return MarketRegime.HIGH_VOLATILITY
        if (s.trendStrength > 0.55 && v > 0 && a >= 0) return MarketRegime.TREND_UP
        if (s.trendStrength > 0.55 && v < 0 && a <= 0) return MarketRegime.TREND_DOWN
        if (abs(a) > max(abs(v) * 0.65, 1e-12) && a * v < 0) return MarketRegime.REVERSAL
        return MarketRegime.RANGE
    }

    fun observe(regime: MarketRegime, outcome: Outcome) {
        if (regime == MarketRegime.UNKNOWN || (outcome != Outcome.WIN && outcome != Outcome.LOSS)) return
        val old = outcomes[regime] ?: (0 to 0)
        outcomes[regime] = if (outcome == Outcome.WIN) (old.first + 1 to old.second) else (old.first to old.second + 1)
    }

    fun learn(records: List<RecordedSignal>) {
        outcomes.clear()
        records.forEach { r ->
            val regime = r.regime?.let { runCatching { MarketRegime.valueOf(it) }.getOrNull() } ?: MarketRegime.UNKNOWN
            observe(regime, r.outcome)
        }
    }

    fun profiles(): List<AdaptiveProfile> = MarketRegime.values().map { r ->
        val (w,l) = outcomes[r] ?: (0 to 0); val n=w+l; val wr=if(n==0)50.0 else w.toDouble()/n*100.0
        AdaptiveProfile(r,n,wr, multiplier(r))
    }

    fun multiplier(regime: MarketRegime): Double {
        val (w,l)=outcomes[regime] ?: (0 to 0); val n=w+l
        if (n < 5) return 1.0
        val wr=w.toDouble()/n
        return (0.82 + wr*0.36).coerceIn(0.82,1.18)
    }

    fun adjust(signal: SignalState): AdaptiveDecision {
        val s=signal.snapshot; val regime=classify(s)
        if (signal.direction=="WAIT") return AdaptiveDecision(regime,signal.score,signal.confidence,"Adaptive: menunggu konfirmasi")
        if (regime==MarketRegime.HIGH_VOLATILITY) return AdaptiveDecision(regime,(signal.score*0.86).toInt(),"LOW","Adaptive: volatilitas tinggi")
        val adjusted=(signal.score*multiplier(regime)).toInt().coerceIn(0,100)
        val conf=when { adjusted>=88 -> "HIGH"; adjusted>=76 -> "MEDIUM"; else -> "LOW" }
        val p=profiles().first{it.regime==regime}
        val note=if(p.samples>=5) "Adaptive ${regime.name}: ${"%.0f".format(p.winRate)}% historis" else "Adaptive ${regime.name}: data belajar ${p.samples}"
        return AdaptiveDecision(regime,adjusted,conf,note)
    }
}
