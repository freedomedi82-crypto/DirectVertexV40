package com.directvertex.v40

import kotlin.math.abs

/**
 * V11 ensemble optimizer. Selects several stable parameter sets rather than
 * trusting one winner. All evaluation is offline and leak-free via WalkForwardEngine.
 */
data class EnsembleMember(val params: ParameterSet, val train: Double, val validation: Double, val test: Double, val testWinRate: Double, val trades: Int, val stability: Double)
data class EnsembleResult(
    val members: List<EnsembleMember>,
    val ensembleTestScore: Double,
    val ensembleWinRate: Double,
    val testTrades: Int,
    val agreement: Double,
    val verdict: String,
    val note: String
)

object EnsembleEngine {
    fun optimize(points: List<ReplayPoint>, topK: Int = 5): EnsembleResult {
        if (points.size < 120) return EnsembleResult(emptyList(),0.0,0.0,0,0.0,"INCONCLUSIVE","Butuh dataset lebih panjang untuk ensemble out-of-sample.")
        val p = points.sortedBy { it.timestamp }; val n=p.size
        val train=p.subList(0,n*60/100); val valid=p.subList(n*60/100,n*80/100); val test=p.subList(n*80/100,n)
        val grid=(72..90 step 2).flatMap { s -> listOf(30,60,120).map { e -> ParameterSet(s,e) } }
        data class Scored(val ps:ParameterSet,val tr:Double,val va:Double)
        fun eval(data:List<ReplayPoint>, ps:ParameterSet):Pair<Double,WalkForwardStats>{
            val r=WalkForwardEngine(ps.expirySeconds).run(data,ps.minScore)
            val s=r.first
            if(s.trades<10) return 0.0 to s
            val score=(s.winRate/100.0) - 0.004*s.maxLosingStreak + 0.0005*minOf(s.trades,100)
            return score to s
        }
        val ranked=grid.map { ps -> val (tr,_)=eval(train,ps); val (va,_)=eval(valid,ps); Scored(ps,tr,va) }
            .sortedByDescending { 0.55*it.tr + 0.45*it.va }
        val candidates=ranked.take(minOf(10,ranked.size))
        val members=candidates.mapNotNull { c ->
            val (_,ts)=eval(test,c.ps)
            if(ts.trades<10) null else EnsembleMember(c.ps,c.tr,c.va,ts.winRate/100.0,ts.winRate,ts.trades,
                (1.0-abs(c.tr-c.va)).coerceIn(0.0,1.0))
        }.sortedByDescending { 0.45*it.validation+0.35*it.test+0.20*it.stability }.take(topK)
        if(members.isEmpty()) return EnsembleResult(emptyList(),0.0,0.0,0,0.0,"INCONCLUSIVE","Tidak ada member yang memenuhi minimum sample.")
        val wr=members.map { it.testWinRate }.average()
        val score=members.map { it.test }.average()
        val mean=wr; val sd=kotlin.math.sqrt(members.map{(it.testWinRate-mean)*(it.testWinRate-mean)}.average())
        val agreement=(100.0-sd*2.0).coerceIn(0.0,100.0)
        val trades=members.sumOf { it.trades }
        val verdict=when {
            members.size<3 || trades<60 -> "INCONCLUSIVE"
            agreement>=85 && wr>=55 -> "ROBUST"
            agreement>=75 && wr>=52 -> "PROMISING"
            agreement<60 -> "FRAGILE"
            else -> "INCONCLUSIVE"
        }
        val note=when(verdict){
            "ROBUST"->"Beberapa konfigurasi independen menunjukkan performa test yang konsisten; tetap validasi pada periode baru."
            "PROMISING"->"Ensemble cukup konsisten, tetapi edge out-of-sample masih terbatas."
            "FRAGILE"->"Member berbeda menghasilkan performa yang terlalu menyebar."
            else->"Belum cukup bukti untuk menyebut ensemble stabil."
        }
        return EnsembleResult(members,score,wr,trades,agreement,verdict,note)
    }
}
