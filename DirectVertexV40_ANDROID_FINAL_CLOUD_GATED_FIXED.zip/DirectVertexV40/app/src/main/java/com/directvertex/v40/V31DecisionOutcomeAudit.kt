package com.directvertex.v40

/**
 * V31: Decision-to-Outcome Audit.
 * Research/replay only. No order execution or broker automation.
 * Replays the real ReplayEngine/SignalEngine and stores a compact audit trail.
 */
object V31DecisionOutcomeAudit {
    enum class Outcome { WIN, LOSS, DRAW, PENDING }

    data class AuditRow(
        val index: Int,
        val timestamp: Long,
        val entry: Double,
        val exit: Double,
        val direction: String,
        val score: Int,
        val confidence: String,
        val reason: String,
        val outcome: Outcome,
        val returnPct: Double,
        val regime: String
    )

    data class Report(
        val points: Int = 0,
        val decisions: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val winRate: Double = 0.0,
        val coverage: Double = 0.0,
        val maxLosingStreak: Int = 0,
        val callCount: Int = 0,
        val putCount: Int = 0,
        val callWinRate: Double = 0.0,
        val putWinRate: Double = 0.0,
        val topReasons: List<String> = emptyList(),
        val rows: List<AuditRow> = emptyList(),
        val verdict: String = "INCONCLUSIVE",
        val note: String = "Belum diuji"
    )

    fun run(points: List<ReplayPoint>, expirySteps: Int, maxRows: Int = 200): Report {
        val clean = points.filter { it.timestamp >= 0L && it.price.isFinite() && it.price > 0.0 }
            .distinctBy { it.timestamp }.sortedBy { it.timestamp }
        if (clean.size < 20 || expirySteps < 1 || clean.size <= expirySteps + 8) {
            return Report(points = clean.size, note = "Data belum cukup untuk audit keputusan-ke-hasil")
        }

        val engine = ReplayEngine(SignalEngine())
        engine.load(clean)
        val rows = mutableListOf<AuditRow>()
        var decisions = 0; var wins = 0; var losses = 0; var draws = 0
        var call = 0; var put = 0; var callW = 0; var callS = 0; var putW = 0; var putS = 0
        var streak = 0; var maxStreak = 0
        val reasonCounts = linkedMapOf<String, Int>()

        for (i in clean.indices) {
            val state = engine.step()
            if (i + expirySteps >= clean.size) break
            val s = state.signal
            if (s.direction != "CALL" && s.direction != "PUT") continue
            decisions++
            if (s.direction == "CALL") call++ else put++
            val entry = clean[i].price
            val exit = clean[i + expirySteps].price
            val delta = exit - entry
            val eps = entry * 1e-5
            val outcome = when {
                kotlin.math.abs(delta) <= eps -> Outcome.DRAW
                (s.direction == "CALL" && delta > 0) || (s.direction == "PUT" && delta < 0) -> Outcome.WIN
                else -> Outcome.LOSS
            }
            when (outcome) {
                Outcome.WIN -> { wins++; streak = 0; if (s.direction == "CALL") callW++ else putW++ }
                Outcome.LOSS -> { losses++; streak++; maxStreak = maxOf(maxStreak, streak) }
                Outcome.DRAW -> draws++
                Outcome.PENDING -> Unit
            }
            if (s.direction == "CALL") callS++ else putS++
            val reason = s.reason.ifBlank { "NO_REASON" }
            reason.split("•").map { it.trim() }.filter { it.isNotBlank() }.forEach { token ->
                reasonCounts[token] = (reasonCounts[token] ?: 0) + 1
            }
            if (rows.size < maxRows) {
                rows += AuditRow(
                    index = i, timestamp = clean[i].timestamp, entry = entry, exit = exit,
                    direction = s.direction, score = s.score, confidence = s.confidence,
                    reason = reason, outcome = outcome,
                    returnPct = (delta / entry) * 100.0, regime = s.regime
                )
            }
        }

        val settled = wins + losses
        val wr = if (settled > 0) wins * 100.0 / settled else 0.0
        val coverage = decisions * 100.0 / (clean.size - expirySteps).coerceAtLeast(1)
        val callSettled = callS
        val putSettled = putS
        val callWr = if (callSettled > 0) callW * 100.0 / callSettled else 0.0
        val putWr = if (putSettled > 0) putW * 100.0 / putSettled else 0.0
        val top = reasonCounts.entries.sortedByDescending { it.value }.take(6).map { "${it.key} (${it.value})" }
        val verdict = when {
            decisions < 30 -> "INCONCLUSIVE"
            wr >= 58.0 && maxStreak <= 7 -> "STRONG"
            wr >= 52.0 && maxStreak <= 10 -> "USEFUL"
            else -> "FRAGILE"
        }
        return Report(clean.size, decisions, wins, losses, draws, wr, coverage, maxStreak,
            call, put, callWr, putWr, top, rows, verdict,
            "Audit memakai ReplayEngine + SignalEngine aktual. Exit hanya dibaca setelah ${expirySteps} titik; alasan signal dicatat untuk diagnosis.")
    }
}
