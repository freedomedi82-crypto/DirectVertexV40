package com.directvertex.v40

/**
 * Leak-free offline evaluation: at each timestamp the adaptive model only knows
 * outcomes whose expiry timestamp is already in the past. No future price is
 * used to choose the current signal.
 */
data class WalkForwardTrade(
    val timestamp: Long,
    val direction: String,
    val score: Int,
    val regime: MarketRegime,
    val entry: Double,
    val exit: Double?,
    val outcome: Outcome
)

data class WalkForwardStats(
    val trades: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val skipped: Int,
    val winRate: Double,
    val maxLosingStreak: Int,
    val byRegime: Map<MarketRegime, Pair<Int, Int>>
)

class WalkForwardEngine(private val expirySeconds: Int = 60) {
    fun run(points: List<ReplayPoint>, minScore: Int = 76): Pair<WalkForwardStats, List<WalkForwardTrade>> {
        if (points.size < 20) return WalkForwardStats(0,0,0,0,points.size,0.0,0,emptyMap()) to emptyList()
        val sorted = points.sortedBy { it.timestamp }
        val temporal = TemporalEngine(12)
        val candles = VirtualCandleBuilder()
        val signalEngine = SignalEngine()
        val adaptive = AdaptiveEngine()
        val pending = mutableListOf<Pending>()
        val trades = mutableListOf<WalkForwardTrade>()
        var skipped = 0

        fun settleUntil(now: Long) {
            val done = pending.filter { it.expiryAt <= now }
            done.forEach { p ->
                val exit = sorted.firstOrNull { it.timestamp >= p.expiryAt }?.price
                if (exit != null) {
                    val outcome = when {
                        exit == p.entry -> Outcome.DRAW
                        p.direction == "CALL" && exit > p.entry -> Outcome.WIN
                        p.direction == "PUT" && exit < p.entry -> Outcome.WIN
                        else -> Outcome.LOSS
                    }
                    trades += WalkForwardTrade(p.timestamp,p.direction,p.score,p.regime,p.entry,exit,outcome)
                    adaptive.observe(p.regime, outcome)
                }
            }
            pending.removeAll { it.expiryAt <= now }
        }

        sorted.forEach { point ->
            // Only completed trades before this point can influence adaptive learning.
            settleUntil(point.timestamp)
            candles.add(point.price)
            val snapshot = temporal.push(SonarSnapshot(calibratedPrice=point.price)).copy(virtualCandle=candles.build())
            val base = signalEngine.evaluate(snapshot, temporal.velocity())
            val decision = adaptive.adjust(base)
            if (base.direction == "WAIT" || decision.adjustedScore < minScore) {
                skipped++
                return@forEach
            }
            pending += Pending(point.timestamp, point.timestamp + expirySeconds*1000L,
                base.direction, decision.adjustedScore, decision.regime, point.price)
        }
        // Do not use data after the dataset's end to invent an outcome; settle only when
        // the expiry point actually exists in the supplied dataset.
        settleUntil(Long.MAX_VALUE)
        val resolved = trades.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS || it.outcome == Outcome.DRAW }
        var streak=0; var maxStreak=0
        resolved.forEach { if(it.outcome==Outcome.LOSS){streak++;maxStreak=maxOf(maxStreak,streak)} else streak=0 }
        val wins=resolved.count{it.outcome==Outcome.WIN}; val losses=resolved.count{it.outcome==Outcome.LOSS}; val draws=resolved.count{it.outcome==Outcome.DRAW}
        val wr=if(wins+losses==0) 0.0 else wins.toDouble()/(wins+losses)*100.0
        val regimeMap=resolved.groupBy{it.regime}.mapValues { (_,rs) -> rs.count{it.outcome==Outcome.WIN} to rs.count{it.outcome==Outcome.LOSS} }
        return WalkForwardStats(resolved.size,wins,losses,draws,skipped,wr,maxStreak,regimeMap) to trades
    }

    private data class Pending(val timestamp:Long,val expiryAt:Long,val direction:String,val score:Int,val regime:MarketRegime,val entry:Double)
}
