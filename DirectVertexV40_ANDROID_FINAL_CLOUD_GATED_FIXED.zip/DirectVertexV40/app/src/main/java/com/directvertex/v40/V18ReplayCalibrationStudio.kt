package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class V18ReplayPoint(
    val timestampMs: Long,
    val price: Double
)

data class V18Calibration(
    val scale: Double,
    val offset: Double,
    val rmse: Double,
    val sampleCount: Int
)

data class V18Window(
    val startMs: Long,
    val endMs: Long,
    val samples: Int,
    val startPrice: Double,
    val endPrice: Double,
    val volatility: Double,
    val trend: String
)

data class V18ReplayReport(
    val verdict: String,
    val qualityScore: Double,
    val calibration: V18Calibration?,
    val windows: List<V18Window>,
    val coverage: Double,
    val continuity: Double,
    val reasons: List<String>
)

/**
 * V18 Replay & Calibration Studio.
 *
 * Provides deterministic dataset diagnostics before model selection:
 * - timestamp ordering/continuity
 * - price normalization calibration
 * - rolling-window market characterization
 * - coverage and quality score
 *
 * It is research-only and never executes trades.
 */
object V18ReplayCalibrationStudio {

    fun analyze(
        points: List<V18ReplayPoint>,
        expectedIntervalMs: Long = 1000L,
        windowSize: Int = 30
    ): V18ReplayReport {
        if (points.size < 10) {
            return V18ReplayReport(
                "INCONCLUSIVE", 0.0, null, emptyList(), 0.0, 0.0,
                listOf("Need at least 10 replay observations.")
            )
        }

        val sorted = points.sortedBy { it.timestampMs }
        val unique = sorted.distinctBy { it.timestampMs }
        val valid = unique.filter { it.price.isFinite() && it.price > 0.0 }

        val coverage = valid.size.toDouble() / points.size.coerceAtLeast(1)
        val gaps = valid.zipWithNext().map { it.second.timestampMs - it.first.timestampMs }
        val continuity = if (gaps.isEmpty()) 0.0 else {
            gaps.count {
                abs(it - expectedIntervalMs) <= max(250L, expectedIntervalMs / 2)
            }.toDouble() / gaps.size
        }

        val calibration = calibrateIndexToPrice(valid)
        val windows = buildWindows(valid, windowSize)
        val variation = windows.map { it.volatility }.ifEmpty { listOf(0.0) }.average()

        val quality =
            (100.0 * (
                0.45 * coverage +
                0.35 * continuity +
                0.20 * (1.0 / (1.0 + variation))
            )).coerceIn(0.0, 100.0)

        val reasons = mutableListOf<String>()
        reasons += "Valid coverage: ${"%.1f".format(coverage * 100)}%"
        reasons += "Timestamp continuity: ${"%.1f".format(continuity * 100)}%"
        reasons += "Rolling windows: ${windows.size}"
        if (calibration != null) reasons += "Calibration RMSE: ${"%.6f".format(calibration.rmse)}"

        val verdict = when {
            coverage >= 0.98 && continuity >= 0.90 && quality >= 80 -> "READY"
            coverage >= 0.90 && continuity >= 0.75 && quality >= 65 -> "USABLE"
            coverage >= 0.70 -> "FRAGILE DATA"
            else -> "INCONCLUSIVE"
        }

        return V18ReplayReport(
            verdict, quality, calibration, windows, coverage, continuity, reasons
        )
    }

    private fun calibrateIndexToPrice(
        data: List<V18ReplayPoint>
    ): V18Calibration? {
        if (data.size < 3) return null
        val n = data.size.toDouble()
        val xs = data.indices.map { it.toDouble() }
        val ys = data.map { it.price }
        val mx = xs.average()
        val my = ys.average()
        val denom = xs.sumOf { (it - mx) * (it - mx) }
        if (denom <= 1e-12) return null

        val slope = xs.zip(ys).sumOf { (x, y) -> (x - mx) * (y - my) } / denom
        val intercept = my - slope * mx
        val rmse = sqrt(
            ys.indices.map { i ->
                val err = ys[i] - (slope * xs[i] + intercept)
                err * err
            }.average()
        )
        return V18Calibration(slope, intercept, rmse, data.size)
    }

    private fun buildWindows(
        data: List<V18ReplayPoint>,
        size: Int
    ): List<V18Window> {
        if (data.size < size) return emptyList()
        val out = mutableListOf<V18Window>()
        var i = 0
        while (i + size <= data.size) {
            val chunk = data.subList(i, i + size)
            val prices = chunk.map { it.price }
            val mean = prices.average()
            val vol = sqrt(prices.map { (it - mean) * (it - mean) }.average()) /
                max(1e-12, abs(mean))
            val delta = prices.last() - prices.first()
            val trend = when {
                delta > 0 -> "UP"
                delta < 0 -> "DOWN"
                else -> "RANGE"
            }
            out += V18Window(
                chunk.first().timestampMs,
                chunk.last().timestampMs,
                chunk.size,
                prices.first(),
                prices.last(),
                vol,
                trend
            )
            i += size
        }
        return out
    }
}
