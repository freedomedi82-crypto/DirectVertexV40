package com.directvertex.v40

import kotlin.math.sqrt

/**
 * V21 Real-Time Learning & Calibration.
 *
 * Online calibration uses ONLY resolved observations whose timestamp is older
 * than `now`. Pending observations are ignored. The learner never changes the
 * directional rule itself; it estimates reliability, regime-specific edge and
 * drift so the decision layer can become more conservative when the market
 * behaviour changes.
 *
 * Analysis-only: no broker/platform execution.
 */
object V21LearningEngine {
    data class RegimeStats(
        val regime: String,
        val samples: Int,
        val wins: Int,
        val losses: Int,
        val draws: Int,
        val probability: Double
    )

    data class V21State(
        val sampleSize: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val draws: Int = 0,
        val calibratedProbability: Double = 0.5,
        val lowerBound: Double = 0.0,
        val upperBound: Double = 1.0,
        val driftScore: Double = 0.0,
        val driftDetected: Boolean = false,
        val cooldown: Boolean = false,
        val reliability: Double = 0.0,
        val regimeStats: List<RegimeStats> = emptyList(),
        val note: String = "Belum ada hasil terselesaikan"
    )

    fun learn(records: List<RecordedSignal>, now: Long = System.currentTimeMillis(), minSamplesForDrift: Int = 12): V21State {
        val resolved = records.filter {
            it.timestamp < now && it.outcome != Outcome.PENDING &&
                (it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS || it.outcome == Outcome.DRAW)
        }.sortedBy { it.timestamp }

        if (resolved.isEmpty()) return V21State()

        val wins = resolved.count { it.outcome == Outcome.WIN }
        val losses = resolved.count { it.outcome == Outcome.LOSS }
        val draws = resolved.count { it.outcome == Outcome.DRAW }
        val decisive = wins + losses

        // Jeffreys/Beta(1/2, 1/2)-like smoothing without external libraries.
        val p = (wins + 0.5) / (decisive + 1.0)
        val se = if (decisive == 0) 0.5 else sqrt((p * (1.0 - p)) / decisive.toDouble())
        val low = (p - 1.96 * se).coerceIn(0.0, 1.0)
        val high = (p + 1.96 * se).coerceIn(0.0, 1.0)

        val regimes = resolved.groupBy { it.regime?.ifBlank { "UNKNOWN" } ?: "UNKNOWN" }
            .map { (regime, rows) ->
                val rw = rows.count { it.outcome == Outcome.WIN }
                val rl = rows.count { it.outcome == Outcome.LOSS }
                val rd = rows.count { it.outcome == Outcome.DRAW }
                val rp = (rw + 0.5) / (rw + rl + 1.0)
                RegimeStats(regime, rows.size, rw, rl, rd, rp)
            }.sortedByDescending { it.samples }

        // Page-Hinkley-style drift diagnostic on decisive outcomes.
        var mean = 0.0
        var cumulative = 0.0
        var minimum = 0.0
        var drift = 0.0
        var n = 0
        resolved.filter { it.outcome != Outcome.DRAW }.forEach { row ->
            val x = if (row.outcome == Outcome.WIN) 1.0 else 0.0
            n++
            mean += (x - mean) / n
            cumulative += x - mean - 0.02
            minimum = minOf(minimum, cumulative)
            drift = maxOf(drift, cumulative - minimum)
        }
        val driftScore = (drift / 3.0).coerceIn(0.0, 1.0)
        val driftDetected = n >= minSamplesForDrift && drift >= 2.2
        val cooldown = driftDetected && drift >= 2.8

        // Reliability combines sample size, interval width and recent stability.
        val sampleFactor = (decisive / 40.0).coerceIn(0.0, 1.0)
        val intervalFactor = (1.0 - (high - low)).coerceIn(0.0, 1.0)
        val reliability = (0.55 * sampleFactor + 0.30 * intervalFactor + 0.15 * (1.0 - driftScore))
            .coerceIn(0.0, 1.0)

        val note = when {
            cooldown -> "DRIFT kuat: learning cooldown aktif"
            driftDetected -> "DRIFT terdeteksi: keputusan harus lebih konservatif"
            decisive < 12 -> "Sampel masih kecil: kalibrasi belum stabil"
            else -> "Kalibrasi online aktif dari hasil yang sudah settled"
        }

        return V21State(
            sampleSize = resolved.size,
            wins = wins,
            losses = losses,
            draws = draws,
            calibratedProbability = p,
            lowerBound = low,
            upperBound = high,
            driftScore = driftScore,
            driftDetected = driftDetected,
            cooldown = cooldown,
            reliability = reliability,
            regimeStats = regimes,
            note = note
        )
    }

    fun auditLines(records: List<RecordedSignal>, now: Long = System.currentTimeMillis()): String = buildString {
        appendLine("timestamp,id,direction,regime,outcome,score,confidence,entry,exit")
        records.filter { it.timestamp < now && it.outcome != Outcome.PENDING }.sortedBy { it.timestamp }.forEach {
            appendLine(listOf(it.timestamp, it.id, it.direction, it.regime ?: "UNKNOWN", it.outcome.name,
                it.score, it.confidence, it.entryPrice ?: "", it.exitPrice ?: "").joinToString(","))
        }
    }
}
