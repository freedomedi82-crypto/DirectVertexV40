package com.directvertex.v40

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class V16Direction { STRONG_CALL, CALL, WAIT, PUT, STRONG_PUT }

data class V16Evidence(
    val vision: Double,
    val momentum: Double,
    val structure: Double,
    val regime: Double,
    val validation: Double,
    val agreement: Double
)

data class V16Decision(
    val direction: V16Direction,
    val confidence: Double,
    val evidence: V16Evidence,
    val quality: Double,
    val reasons: List<String>,
    val rejectedReasons: List<String>
)

/**
 * Fusion layer for the existing Direct Vertex research stack.
 * It combines independent evidence and defaults to WAIT when evidence conflicts.
 * Analysis-only: never executes or submits trades.
 */
object V16FusionEngine {
    fun decide(
        visionTrend: String,
        visionQuality: Double,
        momentum: Double,
        structureScore: Double,
        regimeScore: Double,
        validationScore: Double,
        callEvidence: Double,
        putEvidence: Double
    ): V16Decision {
        val vq = visionQuality.coerceIn(0.0, 1.0)
        val m = momentum.coerceIn(-1.0, 1.0)
        val structure = structureScore.coerceIn(-1.0, 1.0)
        val regime = regimeScore.coerceIn(-1.0, 1.0)
        val validation = validationScore.coerceIn(0.0, 1.0)

        val visionSigned = when (visionTrend.uppercase()) {
            "UP" -> 1.0
            "DOWN" -> -1.0
            else -> 0.0
        }

        val call = callEvidence.coerceIn(0.0, 1.0)
        val put = putEvidence.coerceIn(0.0, 1.0)

        val signed =
            0.22 * visionSigned * vq +
            0.20 * m +
            0.18 * structure +
            0.15 * regime +
            0.15 * (call - put) +
            0.10 * (2.0 * validation - 1.0)

        val agreement = listOf(
            visionSigned,
            m,
            structure,
            regime,
            call - put
        ).map { if (abs(it) >= 0.12) if (it > 0) 1 else -1 else 0 }

        val active = agreement.filter { it != 0 }
        val majority = if (active.isEmpty()) 0 else {
            val s = active.sum()
            if (s > 0) 1 else if (s < 0) -1 else 0
        }
        val agreementRatio = if (active.isEmpty()) 0.0
        else active.count { it == majority }.toDouble() / active.size

        val confidence = (
            0.55 * abs(signed) +
            0.20 * agreementRatio +
            0.15 * vq +
            0.10 * validation
        ).coerceIn(0.0, 1.0)

        val reasons = mutableListOf<String>()
        val rejected = mutableListOf<String>()

        if (vq >= 0.65) reasons += "vision quality strong" else rejected += "vision quality weak"
        if (abs(m) >= 0.15) reasons += "momentum confirms direction" else rejected += "momentum neutral"
        if (abs(structure) >= 0.15) reasons += "structure confirms direction" else rejected += "structure neutral"
        if (abs(regime) >= 0.15) reasons += "market regime aligned" else rejected += "regime uncertain"
        if (validation >= 0.60) reasons += "historical validation supportive" else rejected += "validation not strong enough"
        if (agreementRatio >= 0.60) reasons += "multi-factor agreement" else rejected += "factor disagreement"

        val direction = when {
            confidence < 0.62 || majority == 0 -> V16Direction.WAIT
            signed >= 0.72 -> V16Direction.STRONG_CALL
            signed >= 0.22 -> V16Direction.CALL
            signed <= -0.72 -> V16Direction.STRONG_PUT
            signed <= -0.22 -> V16Direction.PUT
            else -> V16Direction.WAIT
        }

        return V16Decision(
            direction = direction,
            confidence = confidence,
            evidence = V16Evidence(
                visionSigned, m, structure, regime, validation, agreementRatio
            ),
            quality = vq,
            reasons = reasons.take(6),
            rejectedReasons = rejected.take(6)
        )
    }
}
