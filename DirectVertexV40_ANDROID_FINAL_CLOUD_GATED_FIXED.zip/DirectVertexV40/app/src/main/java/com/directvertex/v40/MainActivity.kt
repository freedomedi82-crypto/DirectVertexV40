package com.directvertex.v40

import android.Manifest
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val openCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setContent { DirectVertexTheme { Dashboard(initialReplayUri = uri.toString()) } }
    }
    private val openOosCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setContent { DirectVertexTheme { Dashboard(initialOosUri = uri.toString()) } }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionLauncher.launch(Manifest.permission.CAMERA)
        setContent { DirectVertexTheme { Dashboard() } }
    }
    fun pickReplay() = openCsv.launch(arrayOf("text/*", "text/csv", "application/csv", "application/octet-stream"))
    fun pickOos() = openOosCsv.launch(arrayOf("text/*", "text/csv", "application/csv", "application/octet-stream"))
}

@Composable private fun DirectVertexTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(background = Color(0xFF080A0D), surface = Color(0xFF11151A)), content = content
)

@Composable private fun Dashboard(initialReplayUri: String? = null, initialOosUri: String? = null) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? MainActivity
    val lifecycleOwner = LocalLifecycleOwner.current
    var signal by remember { mutableStateOf(SignalState()) }
    var running by remember { mutableStateOf(true) }
    var calibrationMode by remember { mutableStateOf(false) }
    var expirySeconds by remember { mutableIntStateOf(60) }
    var lastRecordedId by remember { mutableStateOf<Long?>(null) }
    var stats by remember { mutableStateOf(BacktestStats(0,0,0,0,0,0.0,0,0,0)) }
    var firstPoint by remember { mutableStateOf<Float?>(null) }; var secondPoint by remember { mutableStateOf<Float?>(null) }
    var firstPrice by remember { mutableStateOf("") }; var secondPrice by remember { mutableStateOf("") }; var calibrated by remember { mutableStateOf(false) }
    var robustness by remember { mutableStateOf(RobustnessStats(0,0,0,0.0,0.0,0.0,0.0,0,0,0,0,0.0,"INCONCLUSIVE","Belum diuji",emptyList())) }; var optimization by remember { mutableStateOf(OptimizationResult(null,0.0,0.0,0.0,0.0,0,0,"INCONCLUSIVE","Belum diuji")) }; var replay by remember { mutableStateOf(ReplayState()) }; var replayLoaded by remember { mutableStateOf(false) }; var replayPoints by remember { mutableStateOf<List<ReplayPoint>>(emptyList()) }; var wfStats by remember { mutableStateOf(WalkForwardStats(0,0,0,0,0,0.0,0,emptyMap())) }; var validation by remember { mutableStateOf(ValidationStats(0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,"INCONCLUSIVE","Belum diuji")) }; var ensemble by remember { mutableStateOf(EnsembleResult(emptyList(),0.0,0.0,0,0.0,"INCONCLUSIVE","Belum diuji")) }; var v12 by remember { mutableStateOf(V12Stats(0,0,0,0,0,0,0.0,50.0,0.0,0,"INCONCLUSIVE","Belum diuji",emptyList())) }; var research by remember { mutableStateOf(ResearchReport("INCONCLUSIVE",0.0,0,0,0.0,"INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE",0.0,0.0,listOf("Belum diuji"),emptyList())) }; var learning by remember { mutableStateOf(V21LearningEngine.V21State()) }; var v22 by remember { mutableStateOf(V22PipelineEngine.Result("WAIT",0.0,"WAIT",V22PipelineEngine.Verification(false,false,false,true,false,false,emptyList()),"Menunggu pipeline")) }; var v23 by remember { mutableStateOf(V23EndToEndVerification.Report()) }; var v24 by remember { mutableStateOf(V24CalibrationEngine.Report()) }; var v25 by remember { mutableStateOf(V25ProbabilityEngine.Report()) }; var v26 by remember { mutableStateOf(V26SignalGovernor.Decision()) }; var v27 by remember { mutableStateOf(V27ResearchRiskGuard.State()) }; var v29 by remember { mutableStateOf(V29MarketDataIntegrity.Report()) }; var v30 by remember { mutableStateOf(V30TrueEndToEndWalkForward.Report()) }; var v31 by remember { mutableStateOf(V31DecisionOutcomeAudit.Report()) }; var v32 by remember { mutableStateOf(V32EntryQualityEngine.Decision()) }; var v35 by remember { mutableStateOf(V35DecisionStabilityEngine.Decision()) }; var v36 by remember { mutableStateOf(V36DecisionIntegrityEngine.Decision()) }; var v37 by remember { mutableStateOf(V38EvidenceQualityEngine.Decision()) }; var v39 by remember { mutableStateOf(V39ChampionEngine.Decision()) }; var v40Report by remember { mutableStateOf(V40UntouchedOOSAudit.Report()) }; var v32Report by remember { mutableStateOf(V32EntryQualityEngine.Report()) }
    val calibrator = remember { PriceCalibrator() }; val candleBuilder = remember { VirtualCandleBuilder() }
    val temporal = remember { TemporalEngine(12) }; val history = remember { SignalHistory(50) }
    val backtest = remember { BacktestEngine() }; val store = remember { RecordStore(context) }; val exportEngine = remember { ExportEngine() }
    val engine = remember { SignalEngine() }; val adaptive = remember { AdaptiveEngine() }; val v35Engine = remember { V35DecisionStabilityEngine }; val replayEngine = remember { ReplayEngine(engine) }; val learner = remember { V21LearningEngine }

    LaunchedEffect(Unit) { val saved=store.load(); backtest.restore(saved); adaptive.learn(saved); stats = backtest.stats(); learning = learner.learn(saved) }
    LaunchedEffect(running) { while (running) { kotlinx.coroutines.delay(1000); signal.snapshot.calibratedPrice?.let { backtest.settleExpired(it) }; val all=backtest.all(); store.save(all); stats = backtest.stats(); learning = learner.learn(all) } }
    LaunchedEffect(initialOosUri) { if (initialOosUri != null) runCatching { val uri=android.net.Uri.parse(initialOosUri); val text=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}; val rows=text?.let{V40UntouchedOOSAudit.parseCsv(it)}?:emptyList(); val hash=text?.let{java.security.MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString(""){b -> "%02x".format(b)}}; v40Report=V40UntouchedOOSAudit.audit(rows,hash) }.onFailure{ Toast.makeText(context,"OOS audit gagal: ${it.message}",Toast.LENGTH_LONG).show() } }

    LaunchedEffect(initialReplayUri) { if (initialReplayUri != null) runCatching { val uri=android.net.Uri.parse(initialReplayUri); val text=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}; val pts=text?.let{ReplayParser.parseCsv(it)}?:emptyList(); replayEngine.load(pts); replayPoints=pts; replayLoaded=pts.isNotEmpty(); replay=replayEngine.state() }.onFailure{ Toast.makeText(context,"Replay gagal dibaca",Toast.LENGTH_SHORT).show() } }

    Box(Modifier.fillMaxSize().background(Color(0xFF080A0D))) {
        AndroidView(Modifier.fillMaxSize(), factory = { ctx -> PreviewView(ctx).also { pv ->
            startCamera(ctx, lifecycleOwner, pv) { snapshot ->
                if (!running) return@startCamera
                val calibratedSnapshot = if (snapshot.chartY != null && calibrated) { val cp=calibrator.calibrate(snapshot.chartY); snapshot.copy(calibratedPrice=cp.price,distanceFromEntry=cp.distanceFromEntry) } else snapshot
                calibratedSnapshot.calibratedPrice?.let { candleBuilder.add(it) }
                val smoothed=temporal.push(calibratedSnapshot).copy(virtualCandle=candleBuilder.build())
                val base=engine.evaluate(smoothed, temporal.velocity())
                val ad=adaptive.adjust(base)
                learning = learner.learn(backtest.all())
                val rawSignal=base.copy(score=ad.adjustedScore, confidence=ad.confidence, regime=ad.regime.name, reason=(base.reason + " • " + ad.note))
                v22 = V22PipelineEngine.evaluate(rawSignal, learning)
                val nativeProb=V25ProbabilityEngine.integrate(v22.confidence, learning); val governor=V26SignalGovernor.decide(v22.direction,nativeProb.probability,v25,learning,ad.adjustedScore/100.0); v26=governor; v27=V27ResearchRiskGuard.evaluate(backtest.all()); val guarded=V27ResearchRiskGuard.apply(governor,v27); v26=guarded; val entryGate=V32EntryQualityEngine.evaluate(guarded.direction.let { d -> rawSignal.copy(direction=d) }, guarded.probability); v32=entryGate; val stable=v35Engine.observe(entryGate); v35=stable; val integrity=V36DecisionIntegrityEngine.evaluate(stable, backtest.all(), rawSignal.regime); v36=integrity; val evidence=V38EvidenceQualityEngine.evaluate(integrity, backtest.all(), rawSignal.regime); v37=evidence; val champion=V39ChampionEngine.evaluate(stable,integrity,evidence); v39=champion; val finalDirection=if(champion.admitted) champion.direction else "WAIT"; signal=rawSignal.copy(direction=finalDirection, score=if(finalDirection=="WAIT") minOf(ad.adjustedScore,59) else ad.adjustedScore, confidence=(stable.quality*100).toInt().toString()+"%", decisionProbability=stable.probability, reason=(rawSignal.reason + " • " + v22.reason + " • " + V26SignalGovernor.compactReason(guarded) + " • V32 ${entryGate.status} • V35 ${stable.reason}"))
                if (signal.direction != "WAIT") history.add(signal)
            }
        }})

        // Lightweight visual sonar overlay: ROI, detected price position and directional pressure.
        Canvas(Modifier.fillMaxSize()) {
            val roi=Roi(); drawRect(Color.White.copy(alpha=.18f), androidx.compose.ui.geometry.Offset(size.width*roi.left,size.height*roi.top), androidx.compose.ui.geometry.Size(size.width*(roi.right-roi.left),size.height*(roi.bottom-roi.top)), Stroke(2f))
            signal.snapshot.chartY?.let { y -> drawLine(Color.Cyan.copy(alpha=.75f), androidx.compose.ui.geometry.Offset(size.width*.05f,size.height*y), androidx.compose.ui.geometry.Offset(size.width*.95f,size.height*y),2f) }
        }
        if (calibrationMode) Canvas(Modifier.fillMaxSize().pointerInput(firstPoint,secondPoint){detectTapGestures{offset->val y=(offset.y/size.height).coerceIn(0f,1f);if(firstPoint==null)firstPoint=y else if(secondPoint==null)secondPoint=y else {firstPoint=y;secondPoint=null}}}) {
            firstPoint?.let{drawLine(Color.Cyan,androidx.compose.ui.geometry.Offset(0f,it*size.height),androidx.compose.ui.geometry.Offset(size.width,it*size.height),3f)}
            secondPoint?.let{drawLine(Color.Yellow,androidx.compose.ui.geometry.Offset(0f,it*size.height),androidx.compose.ui.geometry.Offset(size.width,it*size.height),3f)}
        }

        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){Text("DIRECT VERTEX V39.0",style=MaterialTheme.typography.titleLarge);Text(if(running)"● SONAR LIVE" else "● PAUSED",color=if(running)Color(0xFF55E38A) else Color.Gray)}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xEE11151A))){Column(Modifier.padding(16.dp)){
                Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Metric("OCR",signal.snapshot.ocrPrice);Metric("PRICE",signal.snapshot.calibratedPrice?.let{"%.6f".format(it)}?:"—");Metric("BIAS",signal.snapshot.virtualCandle.bias)}
                Text("SIGNAL",color=Color.Gray);Text(signal.direction,style=MaterialTheme.typography.displaySmall,color=when(signal.direction){"CALL"->Color(0xFF55E38A);"PUT"->Color(0xFFFF5D5D);else->Color(0xFFFFD45A)});Text("${signal.score}/100 • ${signal.confidence}");Text(signal.reason,color=Color.LightGray)
                Text("REGIME ${signal.regime} • SAMPLES ${signal.snapshot.sampleCount} • VEL ${signal.snapshot.velocity?.let{"%+.6g".format(it)}?:"—"} • TREND ${"%.2f".format(signal.snapshot.trendStrength)} • VOL ${"%.3g".format(signal.snapshot.volatility)}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("ACC ${"%+.3g".format(signal.snapshot.acceleration)} • SUPPORT Δ ${signal.snapshot.supportDistance?.let{"%.6g".format(it)}?:"—"} • RESIST Δ ${signal.snapshot.resistanceDistance?.let{"%.6g".format(it)}?:"—"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("V21 LEARNING • N ${learning.sampleSize} • CAL ${"%.1f".format(learning.calibratedProbability*100)}% • CI ${"%.0f".format(learning.lowerBound*100)}–${"%.0f".format(learning.upperBound*100)}%",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                Text("DRIFT ${"%.2f".format(learning.driftScore)} • ${if(learning.driftDetected) "DETECTED" else "STABLE"} • REL ${"%.0f".format(learning.reliability*100)}%",color=if(learning.driftDetected) Color(0xFFFFD45A) else Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("ADAPTIVE ENGINE • belajar dari hasil backtest",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                Text("Analisis saja — tidak mengirim order otomatis.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(Modifier.weight(1f),enabled=signal.direction=="CALL"&&signal.snapshot.calibratedPrice!=null,onClick={backtest.record(signal,expirySeconds)?.let{lastRecordedId=it.id;store.save(backtest.all());stats=backtest.stats();learning=learner.learn(backtest.all())}}){Text("RECORD CALL")};Button(Modifier.weight(1f),enabled=signal.direction=="PUT"&&signal.snapshot.calibratedPrice!=null,onClick={backtest.record(signal,expirySeconds)?.let{lastRecordedId=it.id;store.save(backtest.all());stats=backtest.stats();learning=learner.learn(backtest.all())}}){Text("RECORD PUT")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("BACKTEST • ${expirySeconds}s");Text("W ${stats.wins} • L ${stats.losses} • D ${stats.draws} • P ${stats.pending} • WR ${"%.1f".format(stats.winRate)}% • Max L ${stats.maxLosingStreak}",color=Color.LightGray)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={expirySeconds=if(expirySeconds==60)30 else if(expirySeconds==30)120 else 60}){Text("EXPIRY ${expirySeconds}s")};OutlinedButton(enabled=lastRecordedId!=null&&signal.snapshot.calibratedPrice!=null,onClick={signal.snapshot.calibratedPrice?.let{backtest.settleLatest(it);lastRecordedId=null;store.save(backtest.all());stats=backtest.stats();learning=learner.learn(backtest.all())}}){Text("SETTLE NOW")};OutlinedButton(onClick={val f=File(context.filesDir,"direct_vertex_backtest.jsonl");f.writeText(exportEngine.toJsonLines(backtest.all()));Toast.makeText(context,"Export tersimpan",Toast.LENGTH_SHORT).show()}); OutlinedButton(onClick={val f=File(context.filesDir,"direct_vertex_learning_audit.csv");f.writeText(learner.auditLines(backtest.all()));Toast.makeText(context,"Learning audit tersimpan",Toast.LENGTH_SHORT).show()}){Text("LEARN AUDIT")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text("MARKET REPLAY",style=MaterialTheme.typography.titleMedium);Text(if(replayLoaded)"${replay.index+1}/${replayEngine.size()}" else "NO DATA",color=Color.Gray)}
                Text(replay.point?.let{"PRICE %.6f • t=%d".format(it.price,it.timestamp)}?:"Import CSV: timestamp,price",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                Text("REPLAY ${replay.signal.direction} • ${replay.signal.score}/100",color=when(replay.signal.direction){"CALL"->Color(0xFF55E38A);"PUT"->Color(0xFFFF5D5D);else->Color(0xFFFFD45A)})
                Text("WALK-FORWARD • W ${wfStats.wins} / L ${wfStats.losses} / D ${wfStats.draws} • WR ${"%.1f".format(wfStats.winRate)}% • Max L ${wfStats.maxLosingStreak}",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={activity?.pickReplay()}){Text("LOAD CSV")};OutlinedButton(enabled=replayLoaded,onClick={replayEngine.reset();replay=replayEngine.state();validation=ValidationStats(0,0,0,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,"INCONCLUSIVE","Belum diuji"); optimization=OptimizationResult(null,0.0,0.0,0.0,0.0,0,0,"INCONCLUSIVE","Belum diuji"); research=ResearchReport("INCONCLUSIVE",0.0,0,0,0.0,"INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE","INCONCLUSIVE",0.0,0.0,listOf("Belum diuji"),emptyList())}){Text("RESET")};Button(enabled=replayLoaded,onClick={replay=replayEngine.step()}){Text("NEXT")};OutlinedButton(enabled=replayLoaded,onClick={replay=replayEngine.runToEnd()}){Text("END")}; OutlinedButton(enabled=replayLoaded,onClick={val result=WalkForwardEngine(expirySeconds).run(replayPoints,76);wfStats=result.first;validation=ValidationEngine.evaluate(result.second)}){Text("VALIDATE")}; OutlinedButton(enabled=replayLoaded,onClick={robustness=RobustnessEngine.evaluate(replayPoints,expirySeconds,5,76)}){Text("ROBUST")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("PARAMETER OPTIMIZER • ${optimization.verdict}",style=MaterialTheme.typography.titleMedium)
                Text(optimization.best?.let { "BEST: score ≥ ${it.minScore} • expiry ${it.expirySeconds}s" } ?: "Belum dioptimasi",color=Color.LightGray)
                Text("TRAIN ${"%.1f".format(optimization.trainScore*100)} • VALID ${"%.1f".format(optimization.validationScore*100)} • TEST ${"%.1f".format(optimization.testScore*100)} • TEST WR ${"%.1f".format(optimization.testWinRate)}% • N ${optimization.testTrades}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(optimization.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={optimization=OptimizerEngine.optimize(replayPoints)}){Text("OPTIMIZE")}; OutlinedButton(enabled=replayLoaded,onClick={ensemble=EnsembleEngine.optimize(replayPoints)}){Text("ENSEMBLE")} }
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("ENSEMBLE • ${ensemble.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("MEMBERS ${ensemble.members.size} • TEST WR ${"%.1f".format(ensemble.ensembleWinRate)}% • AGREEMENT ${"%.0f".format(ensemble.agreement)}% • N ${ensemble.testTrades}",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                ensemble.members.take(5).forEachIndexed { i,m -> Text("#${i+1} score≥${m.params.minScore} / ${m.params.expirySeconds}s • test ${"%.1f".format(m.testWinRate)}% • stability ${"%.0f".format(m.stability*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                Text(ensemble.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("ROBUSTNESS • ${robustness.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("WINDOW ${robustness.validWindows}/${robustness.windows} • AVG WR ${"%.1f".format(robustness.avgWinRate)}% • MED ${"%.1f".format(robustness.medianWinRate)}%",color=Color.LightGray)
                Text("MIN ${"%.1f".format(robustness.minWinRate)}% • MAX ${"%.1f".format(robustness.maxWinRate)}% • SD ${"%.1f".format(robustness.winRateStdDev)} • CONSISTENCY ${"%.0f".format(robustness.consistency)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(robustness.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V12 ROBUSTNESS • ${v12.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("WINDOW ${v12.validWindows}/${v12.windows} • TEST N ${v12.testTrades} • WR ${"%.1f".format(v12.winRate)}% • CAL ${"%.1f".format(v12.calibratedProbability)}%",color=Color.LightGray)
                Text("CONSISTENCY ${"%.0f".format(v12.consistency)}% • MAX LOSS ${v12.maxLosingStreak} • W ${v12.wins} / L ${v12.losses} / D ${v12.draws}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("REGIME-AWARE + PURGED ROLLING OUT-OF-SAMPLE",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v12.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                v12.rows.take(5).forEach { r -> Text("F${r.window} ${r.regime.name} • ${r.params.minScore}/${r.params.expirySeconds}s • test ${"%.1f".format(r.testWinRate)}% • stab ${"%.0f".format(r.stability*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v12=V12Engine.evaluate(replayPoints)}){Text("V12 VALIDATE")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V29 MARKET DATA GATE • ${v29.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v29.points} / VALID ${v29.validPoints} • COVER ${"%.0f".format(v29.coverageScore*100)}% • INTERVAL ${v29.medianIntervalMs}ms",color=Color.LightGray)
                Text("CV ${"%.2f".format(v29.intervalCv)} • MED MOVE ${"%.4f".format(v29.medianAbsReturn*100)}% • P95 ${"%.4f".format(v29.p95AbsReturn*100)}% • JUMPS ${v29.jumpCount}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("CALIBRATED EXPIRY ${v29.suggestedExpirySeconds}s • ${v29.suggestedExpirySteps} steps",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                Text(v29.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                if(v29.issues.isNotEmpty()) Text(v29.issues.take(4).joinToString(" • "),color=Color(0xFFFFD45A),style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v29=V29MarketDataIntegrity.evaluate(replayPoints,expirySeconds)}){Text("RUN V29")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V30 TRUE END-TO-END • ${v30.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v30.points} • FOLDS ${v30.folds} • DEC ${v30.decisions} • WR ${"%.1f".format(v30.winRate)}%",color=Color.LightGray)
                Text("W ${v30.wins} • L ${v30.losses} • D ${v30.draws} • COVER ${"%.1f".format(v30.coverage)}% • MAX LOSS ${v30.maxLosingStreak}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("DATA ${v30.dataGate} • LEAKAGE ${if(v30.leakageFree) "FREE" else "FAIL"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v30.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                v30.foldsDetail.take(5).forEach { f -> Text("F${f.number}: DEC ${f.decisions} • WR ${"%.1f".format(f.winRate)}% • COVER ${"%.1f".format(f.coverage)}% • MAX ${f.maxLoss}",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v30=V30TrueEndToEndWalkForward.run(replayPoints, v29.suggestedExpirySteps.coerceAtLeast(1))}){Text("RUN V30")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V31 DECISION → OUTCOME AUDIT • ${v31.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v31.points} • DEC ${v31.decisions} • W ${v31.wins} • L ${v31.losses} • D ${v31.draws} • WR ${"%.1f".format(v31.winRate)}% • COVER ${"%.1f".format(v31.coverage)}%",color=Color.LightGray)
                Text("CALL ${v31.callCount} / WR ${"%.1f".format(v31.callWinRate)}% • PUT ${v31.putCount} / WR ${"%.1f".format(v31.putWinRate)}% • MAX LOSS ${v31.maxLosingStreak}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(if(v31.topReasons.isEmpty()) "Belum ada reason breakdown" else "TOP EVIDENCE: ${v31.topReasons.joinToString(" • ")}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v31.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                v31.rows.takeLast(5).forEach { r -> Text("#${r.index} ${r.direction} ${r.score}/100 → ${r.outcome} • ${"%.4f".format(r.returnPct)}% • ${r.regime} • ${r.reason}",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v31=V31DecisionOutcomeAudit.run(replayPoints,v29.suggestedExpirySteps.coerceAtLeast(1))}){Text("RUN V31 AUDIT")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V32 ENTRY QUALITY • ${v32.status}",style=MaterialTheme.typography.titleMedium)
                Text("ENTRY ${v32.direction} • QUALITY ${"%.1f".format(v32.quality*100)}% • P ${"%.1f".format(v32.probability*100)}%",color=Color.LightGray)
                Text(if(v32.reasons.isEmpty()) "Gate PASS — entry memenuhi filter kualitas" else "WAIT: ${v32.reasons.take(3).joinToString(" • ")}",color=if(v32.admitted) Color(0xFF55E38A) else Color(0xFFFFD45A),style=MaterialTheme.typography.bodySmall)
                Text("OOS BASE WR ${"%.1f".format(v32Report.baselineWinRate)}% → GATED WR ${"%.1f".format(v32Report.gatedWinRate)}% • Δ ${"%+.1f".format(v32Report.improvement)}pp • COVER ${"%.1f".format(v32Report.gatedCoverage)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("REJECTED ${v32Report.rejectedEntries} • VERDICT ${v32Report.verdict}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("V35 STABILITY • ${if(v35.admitted) "PASS" else "WAIT"} • AGREEMENT ${"%.0f".format(v35.stability*100)}% • P_REQ ${"%.1f".format(v35.requiredProbability*100)}% • OBS ${v35.observations}",color=Color.Gray,style=MaterialTheme.typography.bodySmall); Text("V36 INTEGRITY • ${if(v36.admitted) "PASS" else "WAIT"} • LOWER95 ${"%.1f".format(v36.lower95*100)}% • DIR-N ${v36.directionalSamples}",color=Color.Gray,style=MaterialTheme.typography.bodySmall); Text("V37 EVIDENCE • ${if(v37.admitted) "PASS" else "WAIT"} • INDEP-N ${v37.effectiveSamples} • RECENT-N ${v37.recentSamples} • INDEP ${"%.0f".format(v37.independenceRatio*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v35.reason,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v32Report=V32EntryQualityEngine.runReplay(replayPoints,v29.suggestedExpirySteps.coerceAtLeast(1))}){Text("RUN V32 OOS")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V40 UNTOUCHED CHRONOLOGICAL OOS • ${v40Report.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("ROWS ${v40Report.totalRows} • DEC ${v40Report.aggregateTestSamples} • W ${v40Report.aggregateWins} • L ${v40Report.aggregateLosses} • PREC ${"%.1f".format(v40Report.aggregatePrecision*100)}%",color=Color.LightGray)
                Text("LOWER95 ${"%.1f".format(v40Report.aggregateLower95*100)}% • COVER ${"%.2f".format(v40Report.aggregateCoverage*100)}% • MAX LOSS ${v40Report.aggregateMaxLossStreak} • FOLDS ${v40Report.folds.count{it.passed}}/${v40Report.folds.size}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("HASH ${if(v40Report.datasetHash.isBlank()) "—" else v40Report.datasetHash.take(16)+"…"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v40Report.reason,color=when(v40Report.verdict){"PASS"->Color(0xFF55E38A);"FAIL"->Color(0xFFFF5D5D);else->Color(0xFFFFD45A)},style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={activity?.pickOos()}){Text("IMPORT OOS CSV")}}
                v40Report.folds.take(5).forEach { f -> Text("F${f.index} • N${f.decisiveTestCount} • ${"%.1f".format(f.precision*100)}% • L95 ${"%.1f".format(f.lower95*100)}% • ${if(f.passed) "PASS" else "FAIL"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V23 END-TO-END • ${v23.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v23.points} • DECISIONS ${v23.decisions} • WR ${"%.1f".format(v23.winRate)}% • COVER ${"%.1f".format(v23.coverage)}%",color=Color.LightGray)
                Text("W ${v23.wins} / L ${v23.losses} / D ${v23.draws} • MAX LOSS ${v23.maxLosingStreak} • LEAKAGE ${if(v23.leakageFree) "PASS" else "BLOCK"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v23.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={v23=V23EndToEndVerification.run(replayPoints,expirySeconds.coerceAtLeast(1)/30)}){Text("RUN V23")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V26 GOVERNOR • ${v26.status}",style=MaterialTheme.typography.titleMedium); Text("V27 RESEARCH GUARD • ${if(v27.blocked) "BLOCKED" else "PASS"} • ${v27.settled} settled",style=MaterialTheme.typography.bodySmall)
                Text(if(v26.admitted) "${v26.direction} • P ${"%.1f".format(v26.probability*100)}%" else "WAIT • ${v26.reasons.take(2).joinToString(" • ")}")
                Spacer(Modifier.height(8.dp))
                Text("V24 CALIBRATION • ${v24.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v24.samples} • BRIER ${"%.3f".format(v24.brierScore)} • LOGLOSS ${"%.3f".format(v24.logLoss)} • ECE ${"%.1f".format(v24.ece*100)}%",color=Color.LightGray)
                Text("THRESHOLD ${"%.0f".format(v24.recommendedMinProbability*100)}% • WR ${"%.1f".format(v24.winRateAtThreshold)}% • COVER ${"%.1f".format(v24.coverageAtThreshold)}% • REL ${"%.0f".format(v24.reliability*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v24.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=v23.trades.isNotEmpty(),onClick={
                    v24=V24CalibrationEngine.evaluate(backtest.all().filter { it.outcome==Outcome.WIN || it.outcome==Outcome.LOSS }.map { V24CalibrationEngine.Sample(it.probability, it.outcome==Outcome.WIN) })
                    v25=V25ProbabilityEngine.evaluate(backtest.all())
                }){Text("RUN V24")}}
                v24.bins.take(5).forEach { b -> Text("${"%.0f".format(b.low*100)}-${"%.0f".format(b.high*100)}% • N${b.count} • pred ${"%.1f".format(b.meanProbability*100)}% • actual ${"%.1f".format(b.empiricalWinRate)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V25 NATIVE PROBABILITY • ${v25.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${v25.samples} • BRIER ${"%.3f".format(v25.brierScore)} • LOGLOSS ${"%.3f".format(v25.logLoss)} • ECE ${"%.1f".format(v25.ece*100)}%",color=Color.LightGray)
                Text("THRESHOLD ${"%.0f".format(v25.threshold*100)}% • WR ${"%.1f".format(v25.selectedWinRate)}% • COVER ${"%.1f".format(v25.coverage)}% • REL ${"%.0f".format(v25.reliability*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v25.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=backtest.all().isNotEmpty(),onClick={v25=V25ProbabilityEngine.evaluate(backtest.all())}){Text("RUN V25")}}
                v25.bins.take(5).forEach { b -> Text("${"%.0f".format(b.low*100)}-${"%.0f".format(b.high*100)}% • N${b.samples} • pred ${"%.1f".format(b.predicted*100)}% • actual ${"%.1f".format(b.observed*100)}% • gap ${"%.1f".format(b.gap*100)}%",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V22 PIPELINE • ${if(v22.verification.pipelineHealthy) "HEALTHY" else "BLOCKED"}",style=MaterialTheme.typography.titleMedium)
                Text("FINAL ${v22.direction} • ${v22.status} • CONF ${"%.0f".format(v22.confidence*100)}%",color=Color.LightGray)
                Text("DATA ${if(v22.verification.dataReady) "PASS" else "BLOCK"} • VISION ${if(v22.verification.visionReady) "PASS" else "BLOCK"} • CAL ${if(v22.verification.calibrationReady) "PASS" else "BLOCK"} • DRIFT ${if(v22.verification.driftSafe) "SAFE" else "BLOCK"}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                if(v22.verification.issues.isNotEmpty()) Text(v22.verification.issues.joinToString(" • "),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(v22.reason,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("V13 RESEARCH LAB • ${research.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("SCORE ${"%.0f".format(research.score)}/100 • EVIDENCE ${research.evidence}/6 • DATA ${research.dataPoints}",color=Color.LightGray)
                Text("BASE WR ${"%.1f".format(research.baseWinRate)}% • STRESS PASS ${"%.0f".format(research.stressScore)}% • MAX DROP ${"%.1f".format(research.maxStressDrop)} pt",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("V12 ${research.v12Verdict} • ROBUST ${research.robustnessVerdict} • ENSEMBLE ${research.ensembleVerdict}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text("OPT ${research.optimizerVerdict} • STATS ${research.validationVerdict}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                research.stress.take(6).forEach { r -> Text("${r.name}: ${"%.1f".format(r.winRate)}% / N${r.trades} • ${r.verdict}",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                research.reasons.take(4).forEach { Text(it,color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(enabled=replayLoaded,onClick={research=ResearchLabEngine.run(replayPoints,expirySeconds)}){Text("RUN LAB")}}
            }}
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){
                Text("STATISTICAL VALIDATION • ${validation.verdict}",style=MaterialTheme.typography.titleMedium)
                Text("N ${validation.sampleSize} • WR ${"%.1f".format(validation.winRate)}% • 95% CI ${"%.1f".format(validation.wilsonLow)}–${"%.1f".format(validation.wilsonHigh)}%",color=Color.LightGray)
                Text("EDGE ${"%+.1f".format(validation.edge)}% • PF ${if(validation.profitFactor.isInfinite()) "∞" else "%.2f".format(validation.profitFactor)} • AVG SCORE ${"%.1f".format(validation.avgScore)}",color=Color.LightGray)
                Text("MC MAX LOSS • MED ${"%.0f".format(validation.monteCarloMedianMaxLoss)} • P95 ${"%.0f".format(validation.monteCarloP95MaxLoss)}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                Text(validation.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
            }}
            if(calibrationMode) CalibrationPanel(firstPoint,secondPoint,firstPrice,secondPrice,calibrated,{firstPrice=it},{secondPrice=it},{val p1=firstPrice.toDoubleOrNull();val p2=secondPrice.toDoubleOrNull();val y1=firstPoint;val y2=secondPoint;if(p1!=null&&p2!=null&&y1!=null&&y2!=null&&y1!=y2){calibrator.setEntry(PriceAnchor(y1,p1));calibrator.setSecond(PriceAnchor(y2,p2));calibrated=true;calibrationMode=false}},{firstPoint=null;secondPoint=null;firstPrice="";secondPrice="";calibrated=false;calibrator.clear();candleBuilder.clear();temporal.clear();history.clear();v35Engine.clear();backtest.clear();store.clear();stats=backtest.stats()})
            Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){OutlinedButton(Modifier.weight(1f),onClick={running=!running}){Text(if(running)"PAUSE" else "START")};OutlinedButton(Modifier.weight(1f),onClick={calibrationMode=!calibrationMode}){Text(if(calibrationMode)"CLOSE CAL" else "CALIBRATE")};OutlinedButton(Modifier.weight(1f),onClick={backtest.clear();store.clear();stats=backtest.stats()}){Text("CLEAR")}}
        }
    }
}

@Composable private fun Metric(label:String,value:String){Column{Text(label,color=Color.Gray);Text(value)}}
@Composable private fun CalibrationPanel(firstPoint:Float?,secondPoint:Float?,firstPrice:String,secondPrice:String,calibrated:Boolean,onFirstPrice:(String)->Unit,onSecondPrice:(String)->Unit,onCalibrate:()->Unit,onReset:()->Unit){Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF211151A))){Column(Modifier.padding(12.dp)){Text("INTERACTIVE PRICE CALIBRATION");Text(if(firstPoint==null)"Tap harga pertama" else if(secondPoint==null)"Tap harga kedua" else "Masukkan dua harga",color=Color.Gray,style=MaterialTheme.typography.bodySmall);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(Modifier.weight(1f),firstPrice,onFirstPrice,label={Text("Price 1")},singleLine=true);OutlinedTextField(Modifier.weight(1f),secondPrice,onSecondPrice,label={Text("Price 2")},singleLine=true)};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(enabled=firstPoint!=null&&secondPoint!=null,onClick=onCalibrate){Text(if(calibrated)"RECALIBRATE" else "APPLY")};OutlinedButton(onClick=onReset){Text("RESET")}}}}}
private fun startCamera(context:Context,lifecycleOwner:androidx.lifecycle.LifecycleOwner,previewView:PreviewView,onSnapshot:(SonarSnapshot)->Unit){val future=ProcessCameraProvider.getInstance(context);val executor=Executors.newSingleThreadExecutor();future.addListener({val provider=future.get();val preview=Preview.Builder().build().also{it.surfaceProvider=previewView.surfaceProvider};val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().also{it.setAnalyzer(executor,VisualSonarAnalyzer(Roi(),onSnapshot))};provider.unbindAll();provider.bindToLifecycle(lifecycleOwner,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis)},ContextCompat.getMainExecutor(context))}
