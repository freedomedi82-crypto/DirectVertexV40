package com.directvertex.v40

import android.graphics.Bitmap
import android.graphics.Color
import java.nio.ByteBuffer
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicInteger

class VisualSonarAnalyzer(
    private val roi: Roi = Roi(),
    private val onResult: (SonarSnapshot) -> Unit
) : ImageAnalysis.Analyzer {

    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val frameCounter = AtomicInteger(0)

    override fun analyze(image: ImageProxy) {
        val count = frameCounter.incrementAndGet()

        // Sample every 3rd frame to reduce CPU usage.
        if (count % 3 != 0) {
            image.close()
            return
        }

        val mediaImage = image.image ?: run {
            image.close()
            return
        }

        val rotation = image.imageInfo.rotationDegrees
        val input = InputImage.fromMediaImage(mediaImage, rotation)

        // OCR is sampled less often than color analysis.
        val doOcr = count % 15 == 0
        val ocrTask = if (doOcr) recognizer.process(input) else null

        val bitmap = image.toSmallBitmap()
        val color = bitmap?.let { estimateChartPressure(it, roi) }
        bitmap?.recycle()

        if (ocrTask == null) {
            image.close()
            onResult(
                SonarSnapshot(
                    candleBias = color?.bias ?: "NEUTRAL",
                    brightness = color?.brightness ?: 0f,
                    redRatio = color?.redRatio ?: 0f,
                    greenRatio = color?.greenRatio ?: 0f,
                    chartY = color?.chartY
                )
            )
            return
        }

        ocrTask
            .addOnSuccessListener { text ->
                val price = extractPriceLikeText(text.text)
                onResult(
                    SonarSnapshot(
                        ocrPrice = price ?: "—",
                        candleBias = color?.bias ?: "NEUTRAL",
                        brightness = color?.brightness ?: 0f,
                        redRatio = color?.redRatio ?: 0f,
                        greenRatio = color?.greenRatio ?: 0f
                    )
                )
            }
            .addOnFailureListener {
                onResult(
                    SonarSnapshot(
                        candleBias = color?.bias ?: "NEUTRAL",
                        brightness = color?.brightness ?: 0f,
                        redRatio = color?.redRatio ?: 0f,
                        greenRatio = color?.greenRatio ?: 0f
                    )
                )
            }
            .addOnCompleteListener {
                image.close()
            }
    }

    private fun estimateChartPressure(bitmap: Bitmap, roi: Roi): Pressure {
        val w = bitmap.width
        val h = bitmap.height
        var red = 0
        var green = 0
        var bright = 0
        var total = 0
        var weightedY = 0.0
        var pressurePixels = 0

        // Ignore outer edges; chart UI labels can distort color ratios.
        val left = (w * roi.left).toInt().coerceIn(0, w - 1)
        val right = (w * roi.right).toInt().coerceIn(left + 1, w)
        val top = (h * roi.top).toInt().coerceIn(0, h - 1)
        val bottom = (h * roi.bottom).toInt().coerceIn(top + 1, h)

        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)

                if (r + g + b > 560) bright++
                if (g > r * 1.25f && g > b * 1.10f && g > 80) {
                    green++
                    weightedY += y.toDouble()
                    pressurePixels++
                }
                if (r > g * 1.25f && r > b * 1.10f && r > 80) {
                    red++
                    weightedY += y.toDouble()
                    pressurePixels++
                }
                total++
                x += 4
            }
            y += 4
        }

        val greenRatio = if (total == 0) 0f else green.toFloat() / total
        val redRatio = if (total == 0) 0f else red.toFloat() / total
        val brightness = if (total == 0) 0f else bright.toFloat() / total

        val chartY = if (pressurePixels > 0) {
            (weightedY / pressurePixels / h.toDouble()).toFloat().coerceIn(0f, 1f)
        } else null

        val bias = when {
            greenRatio > redRatio * 1.25f && greenRatio > 0.02f -> "BULLISH"
            redRatio > greenRatio * 1.25f && redRatio > 0.02f -> "BEARISH"
            else -> "NEUTRAL"
        }

        return Pressure(bias, brightness, redRatio, greenRatio, chartY)
    }

    private fun extractPriceLikeText(text: String): String? {
        // Conservative OCR filter. It does not assume that every number is a price.
        val regex = Regex("""\b\d{1,6}[.,]\d{2,8}\b""")
        return regex.findAll(text)
            .map { it.value.replace(',', '.') }
            .firstOrNull()
    }

    private fun ImageProxy.toSmallBitmap(): Bitmap? {
        val yPlane = planes.getOrNull(0) ?: return null
        val uPlane = planes.getOrNull(1) ?: return null
        val vPlane = planes.getOrNull(2) ?: return null

        val width = width.coerceAtMost(720)
        val height = height.coerceAtMost(1280)
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val y = yPlane.buffer
        val u = uPlane.buffer
        val v = vPlane.buffer

        val yRowStride = yPlane.rowStride
        val uRowStride = uPlane.rowStride
        val vRowStride = vPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vPixelStride = vPlane.pixelStride

        val pixels = IntArray(width * height)
        var index = 0

        for (py in 0 until height) {
            val sy = (py.toFloat() * this.height / height).toInt()
            for (px in 0 until width) {
                val sx = (px.toFloat() * this.width / width).toInt()

                val yIndex = sy * yRowStride + sx
                val uvRow = sy / 2
                val uvCol = sx / 2

                val uIndex = uvRow * uRowStride + uvCol * uPixelStride
                val vIndex = uvRow * vRowStride + uvCol * vPixelStride

                val yy = (y.getOrNull(yIndex)?.toInt() ?: 0) and 0xFF
                val uu = ((u.getOrNull(uIndex)?.toInt() ?: 128) and 0xFF) - 128
                val vv = ((v.getOrNull(vIndex)?.toInt() ?: 128) and 0xFF) - 128

                val r = (yy + 1.402f * vv).toInt().coerceIn(0, 255)
                val g = (yy - 0.344136f * uu - 0.714136f * vv).toInt().coerceIn(0, 255)
                val b = (yy + 1.772f * uu).toInt().coerceIn(0, 255)

                pixels[index++] = Color.rgb(r, g, b)
            }
        }

        out.setPixels(pixels, 0, width, 0, 0, width, height)
        return out
    }

    private fun ByteBuffer.getOrNull(index: Int): Byte? {
        if (index < 0 || index >= limit()) return null
        return get(index)
    }

    data class Pressure(
        val bias: String,
        val brightness: Float,
        val redRatio: Float,
        val greenRatio: Float,
        val chartY: Float?
    )
}
