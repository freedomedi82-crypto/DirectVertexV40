package com.directvertex.v40

import java.util.ArrayDeque

data class Roi(
    val left: Float = 0.05f,
    val top: Float = 0.12f,
    val right: Float = 0.92f,
    val bottom: Float = 0.88f
)

data class PriceAnchor(
    val yFraction: Float,
    val price: Double
)

data class CalibratedPrice(
    val price: Double?,
    val distanceFromEntry: Double?,
    val yFraction: Float?
)

class PriceCalibrator {
    private var entry: PriceAnchor? = null
    private var second: PriceAnchor? = null

    fun setEntry(anchor: PriceAnchor) {
        entry = anchor
    }

    fun setSecond(anchor: PriceAnchor) {
        second = anchor
    }

    fun clear() {
        entry = null
        second = null
    }

    fun isReady(): Boolean = entry != null && second != null &&
        entry!!.yFraction != second!!.yFraction

    fun calibrate(yFraction: Float): CalibratedPrice {
        val a = entry ?: return CalibratedPrice(null, null, yFraction)
        val b = second ?: return CalibratedPrice(null, null, yFraction)
        val slope = (b.price - a.price) / (b.yFraction - a.yFraction)
        val price = a.price + slope * (yFraction - a.yFraction)
        return CalibratedPrice(price, price - a.price, yFraction)
    }
}

data class VirtualCandle(
    val open: Double?,
    val high: Double?,
    val low: Double?,
    val close: Double?,
    val bodyRatio: Double,
    val bias: String
)

class VirtualCandleBuilder {
    private val prices = ArrayDeque<Double>()

    fun clear() {
        prices.clear()
    }

    fun add(price: Double) {
        prices.addLast(price)
        while (prices.size > 60) prices.removeFirst()
    }

    fun build(): VirtualCandle {
        if (prices.isEmpty()) return VirtualCandle(null, null, null, null, 0.0, "NEUTRAL")
        val list = prices.toList()
        val open = list.first()
        val close = list.last()
        val high = list.maxOrNull() ?: close
        val low = list.minOrNull() ?: close
        val range = (high - low).coerceAtLeast(1e-12)
        val body = kotlin.math.abs(close - open)
        val ratio = body / range
        val bias = when {
            close > open && ratio >= .35 -> "BULLISH"
            close < open && ratio >= .35 -> "BEARISH"
            else -> "NEUTRAL"
        }
        return VirtualCandle(open, high, low, close, ratio, bias)
    }
}
