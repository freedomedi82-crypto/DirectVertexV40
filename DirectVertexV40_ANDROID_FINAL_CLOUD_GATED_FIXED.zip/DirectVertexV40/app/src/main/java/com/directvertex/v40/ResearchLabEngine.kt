package com.directvertex.v40


/** V13 Research Lab: combines independent offline validation layers and stress tests. */
data class StressResult(
    val name: String,
    val winRate: Double,
    val trades: Int,
    val deltaFromBase: Double,
    val verdict: String
)

data class ResearchReport(
    val verdict: String,
    val score: Double,
    val evidence: Int,
    val dataPoints: Int,
    val baseWinRate: Double,
    val v12Verdict: String,
    val robustnessVerdict: String,
    val ensembleVerdict: String,
    val optimizerVerdict: String,
    val validationVerdict: String,
    val stressScore: Double,
    val maxStressDrop: Double,
    val reasons: List<String>,
    val stress: List<StressResult>
)

object ResearchLabEngine {
    fun run(points: List<ReplayPoint>, expirySeconds: Int = 60): ResearchReport {
        val p = points.sortedBy { it.timestamp }
        if (p.size < 240) return empty(p.size, "Dataset minimal 240 titik untuk Research Lab.")

        val v12 = V12Engine.evaluate(p)
        val robust = RobustnessEngine.evaluate(p, expirySeconds, 5, 76)
        val ensemble = EnsembleEngine.optimize(p)
        val optimizer = OptimizerEngine.optimize(p)
        val wf = WalkForwardEngine(expirySeconds).run(p, 76)
        val validation = ValidationEngine.evaluate(wf.second)
        val base = wf.first.winRate

        val stresses = listOf(
            stress(p, expirySeconds, 74, "Score -2"),
            stress(p, expirySeconds, 78, "Score +2"),
            stress(p, 76, 30, "Expiry 30s"),
            stress(p, 76, 120, "Expiry 120s"),
            blockStress(p, expirySeconds, "Early 70%"),
            blockStress(p, expirySeconds, "Late 70%")
        )
        val validStress = stresses.filter { it.trades >= 10 }
        val stressScore = if (validStress.isEmpty()) 0.0 else validStress.count { it.verdict == "PASS" }.toDouble() / validStress.size * 100.0
        val maxDrop = validStress.maxOfOrNull { maxOf(0.0, base - it.winRate) } ?: 0.0

        var evidence = 0
        if (v12.verdict == "ROBUST") evidence++
        if (robust.verdict == "ROBUST") evidence++
        if (ensemble.verdict == "ROBUST") evidence++
        if (optimizer.verdict == "ROBUST") evidence++
        if (validation.verdict == "ROBUST") evidence++
        if (stressScore >= 66.0) evidence++

        val score = (evidence * 16.0 + minOf(stressScore, 100.0) * 0.04 + minOf(v12.consistency, 100.0) * 0.02).coerceAtMost(100.0)
        val overfitSignals = listOf(optimizer.verdict, ensemble.verdict).count { it == "OVERFIT RISK" || it == "FRAGILE" }
        val verdict = when {
            p.size < 500 || wf.first.trades < 100 -> "INCONCLUSIVE"
            overfitSignals >= 2 || maxDrop >= 12.0 -> "OVERFIT RISK"
            evidence >= 5 && stressScore >= 66.0 && v12.verdict == "ROBUST" -> "ROBUST"
            evidence >= 3 && stressScore >= 50.0 -> "PROMISING"
            stressScore < 40.0 || maxDrop >= 18.0 -> "FRAGILE"
            else -> "INCONCLUSIVE"
        }
        val reasons = mutableListOf<String>()
        reasons += "V12=${v12.verdict}; multi-window=${robust.verdict}; ensemble=${ensemble.verdict}."
        reasons += "Optimizer=${optimizer.verdict}; statistical=${validation.verdict}; stress pass=${"%.0f".format(stressScore)}%."
        if (maxDrop > 0) reasons += "Penurunan WR stress terburuk ${"%.1f".format(maxDrop)} poin dari baseline ${"%.1f".format(base)}%."
        reasons += if (evidence >= 4) "Bukti lintas metode cukup selaras." else "Bukti lintas metode belum cukup selaras."
        return ResearchReport(verdict, score, evidence, p.size, base, v12.verdict, robust.verdict, ensemble.verdict, optimizer.verdict, validation.verdict, stressScore, maxDrop, reasons, stresses)
    }

    private fun stress(p: List<ReplayPoint>, expiry: Int, score: Int, name: String): StressResult {
        val s = WalkForwardEngine(expiry).run(p, score).first
        val verdict = if (s.trades >= 10 && s.winRate >= 50.0) "PASS" else "FAIL"
        return StressResult(name, s.winRate, s.trades, 0.0, verdict)
    }

    private fun blockStress(p: List<ReplayPoint>, expiry: Int, name: String): StressResult {
        val n = p.size
        val data = if (name.startsWith("Early")) p.take((n * 0.70).toInt()) else p.takeLast((n * 0.70).toInt())
        val s = WalkForwardEngine(expiry).run(data, 76).first
        val verdict = if (s.trades >= 10 && s.winRate >= 50.0) "PASS" else "FAIL"
        return StressResult(name, s.winRate, s.trades, 0.0, verdict)
    }

    private fun empty(n: Int, reason: String) = ResearchReport("INCONCLUSIVE", 0.0, 0, n, 0.0, "INCONCLUSIVE", "INCONCLUSIVE", "INCONCLUSIVE", "INCONCLUSIVE", "INCONCLUSIVE", 0.0, 0.0, listOf(reason), emptyList())
}
