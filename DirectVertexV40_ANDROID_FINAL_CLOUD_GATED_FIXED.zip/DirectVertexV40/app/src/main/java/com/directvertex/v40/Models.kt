package com.directvertex.v40

data class SonarSnapshot(
    val ocrPrice: String = "—",
    val candleBias: String = "NEUTRAL",
    val brightness: Float = 0f,
    val redRatio: Float = 0f,
    val greenRatio: Float = 0f,
    val chartY: Float? = null,
    val calibratedPrice: Double? = null,
    val distanceFromEntry: Double? = null,
    val virtualCandle: VirtualCandle = VirtualCandle(null, null, null, null, 0.0, "NEUTRAL"),
    val velocity: Double? = null,
    val sampleCount: Int = 0,
    val trendStrength: Double = 0.0,
    val volatility: Double = 0.0,
    val acceleration: Double = 0.0,
    val supportDistance: Double? = null,
    val resistanceDistance: Double? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

data class SignalState(
    val direction: String = "WAIT",
    val score: Int = 0,
    val confidence: String = "LOW",
    val expiry: String = "1 MIN",
    val regime: String = "UNKNOWN",
    val reason: String = "Menunggu data Visual Sonar",
    val decisionProbability: Double = 0.5,
    val snapshot: SonarSnapshot = SonarSnapshot()
)
