package com.directvertex.v40

import kotlin.math.abs

/**
 * V26 Confidence-Aware Signal Governor.
 *
 * Converts calibrated probability into a conservative admission decision.
 * The governor can only abstain; it never creates a CALL/PUT by itself.
 * Analysis-only: no broker/platform execution.
 */
object V26SignalGovernor {
    data class Config(
        val minProbability: Double = 0.65,
        val minReliability: Double = 0.60,
        val minSampleSize: Int = 30,
        val maxCalibrationError: Double = 0.12,
        val maxDriftScore: Double = 0.65,
        val minAgreement: Double = 0.62,
        val cooldownOnDrift: Boolean = true
    )

    data class Decision(
        val direction: String = "WAIT",
        val probability: Double = 0.5,
        val admitted: Boolean = false,
        val status: String = "BLOCKED",
        val reasons: List<String> = emptyList(),
        val margin: Double = 0.0
    )

    fun decide(
        candidateDirection: String,
        probability: Double,
        calibration: V25ProbabilityEngine.Report,
        learning: V21LearningEngine.V21State,
        agreement: Double,
        config: Config = Config()
    ): Decision {
        val p = probability.coerceIn(0.0, 1.0)
        val reasons = mutableListOf<String>()
        if (candidateDirection != "CALL" && candidateDirection != "PUT") reasons += "Arah belum valid"
        if (calibration.samples < config.minSampleSize) reasons += "Sampel kalibrasi kurang (${calibration.samples}/${config.minSampleSize})"
        if (calibration.verdict == "FRAGILE" || calibration.verdict == "INCONCLUSIVE") reasons += "Kalibrasi ${calibration.verdict}"
        if (calibration.ece > config.maxCalibrationError) reasons += "ECE terlalu tinggi"
        if (learning.reliability < config.minReliability) reasons += "Reliability learning rendah"
        if (learning.driftScore > config.maxDriftScore) reasons += "Drift terlalu tinggi"
        if (config.cooldownOnDrift && learning.cooldown) reasons += "Learning cooldown aktif"
        if (agreement < config.minAgreement) reasons += "Evidence agreement rendah"
        if (p < config.minProbability) reasons += "Probabilitas di bawah threshold"

        val margin = p - config.minProbability
        val admitted = reasons.isEmpty()
        val status = when {
            admitted && p >= 0.80 -> "HIGH_CONVICTION"
            admitted -> "CONFIRMED"
            reasons.any { it.contains("drift", true) || it.contains("cooldown", true) } -> "DRIFT_BLOCKED"
            else -> "WAIT"
        }
        return Decision(
            direction = if (admitted) candidateDirection else "WAIT",
            probability = p,
            admitted = admitted,
            status = status,
            reasons = reasons,
            margin = margin
        )
    }

    fun compactReason(decision: Decision): String = if (decision.admitted) {
        "V26 ${decision.status} • P ${"%.1f".format(decision.probability * 100)}% • margin ${"%.1f".format(decision.margin * 100)}%"
    } else {
        "V26 WAIT • ${decision.reasons.take(3).joinToString(" • ")}"
    }
}
