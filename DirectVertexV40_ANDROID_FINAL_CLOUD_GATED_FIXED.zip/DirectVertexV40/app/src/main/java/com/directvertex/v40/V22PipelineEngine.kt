package com.directvertex.v40


/**
 * V22 Full Pipeline Integration & Verification.
 *
 * One deterministic path from the live SignalState + V21 learning state to the
 * final analysis decision. It also exposes verification flags so the UI can
 * show why a decision is blocked. No broker/platform execution is performed.
 */
object V22PipelineEngine {
    data class Verification(
        val dataReady: Boolean,
        val visionReady: Boolean,
        val learningReady: Boolean,
        val driftSafe: Boolean,
        val calibrationReady: Boolean,
        val pipelineHealthy: Boolean,
        val issues: List<String>
    )

    data class Result(
        val direction: String,
        val confidence: Double,
        val status: String,
        val verification: Verification,
        val reason: String
    )

    fun evaluate(signal: SignalState, learning: V21LearningEngine.V21State): Result {
        val s = signal.snapshot
        val dataReady = s.sampleCount >= 4 && s.brightness.isFinite()
        val visionReady = s.chartY != null && s.redRatio.isFinite() && s.greenRatio.isFinite()
        val learningReady = learning.sampleSize >= 12 && learning.reliability >= 0.60
        val driftSafe = !learning.cooldown
        val calibrationReady = s.calibratedPrice != null

        val issues = buildList {
            if (!dataReady) add("DATA belum stabil")
            if (!visionReady) add("VISION belum stabil")
            if (!calibrationReady) add("Harga belum terkalibrasi")
            if (!driftSafe) add("Learning cooldown karena drift")
        }

        val dataQuality = (s.sampleCount / 12.0).coerceIn(0.0, 1.0)
        val visionQuality = if (visionReady) {
            (0.55 + 0.45 * (1.0 - (s.volatility * 0.15).coerceIn(0.0, 1.0))).coerceIn(0.0, 1.0)
        } else 0.0
        val regimeAlignment = when {
            signal.direction == "WAIT" -> 0.50
            signal.regime == "UNKNOWN" -> 0.50
            else -> 0.68
        }
        val evidenceAgreement = (signal.score / 100.0).coerceIn(0.0, 1.0)
        val modelValidation = if (learningReady) learning.reliability else 0.50
        val stressResilience = when {
            learning.cooldown -> 0.20
            learning.driftDetected -> 0.40
            else -> 0.65
        }

        val v20 = V20DecisionIntelligenceCore.decide(
            candidateDirection = signal.direction,
            dataQuality = dataQuality,
            visionQuality = visionQuality,
            regimeAlignment = regimeAlignment,
            evidenceAgreement = evidenceAgreement,
            modelValidation = modelValidation,
            stressResilience = stressResilience,
            rawConfidence = (signal.score / 100.0).coerceIn(0.0, 1.0)
        )

        val forcedWait = !dataReady || !visionReady || !calibrationReady || learning.cooldown
        val direction = if (forcedWait) "WAIT" else v20.direction
        val confidence = if (forcedWait) minOf(v20.confidence, 0.59) else v20.confidence
        val healthy = dataReady && visionReady && driftSafe && calibrationReady
        val verification = Verification(
            dataReady, visionReady, learningReady, driftSafe, calibrationReady, healthy, issues
        )
        val reason = buildString {
            append("V22 ${v20.status}")
            if (issues.isNotEmpty()) append(" • ${issues.joinToString(" • ")}")
            if (learning.sampleSize > 0) append(" • CAL ${"%.1f".format(learning.calibratedProbability * 100)}%")
        }
        return Result(direction, confidence, if (direction == "WAIT") "WAIT" else v20.status, verification, reason)
    }
}
