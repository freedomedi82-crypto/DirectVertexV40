package com.directvertex.v40

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class RecordStore(context: Context) {
    private val prefs = context.getSharedPreferences("direct_vertex_records", Context.MODE_PRIVATE)

    fun save(records: List<RecordedSignal>) {
        val arr = JSONArray()
        records.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("timestamp", r.timestamp)
                put("direction", r.direction)
                put("score", r.score)
                put("confidence", r.confidence)
                put("probability", r.probability)
                if (r.entryPrice == null) put("entryPrice", JSONObject.NULL)
                else put("entryPrice", r.entryPrice)
                put("expirySeconds", r.expirySeconds)
                put("regime", r.regime)
                if (r.exitPrice == null) put("exitPrice", JSONObject.NULL)
                else put("exitPrice", r.exitPrice)
                put("outcome", r.outcome.name)
            })
        }
        prefs.edit().putString("records", arr.toString()).apply()
    }

    fun load(): List<RecordedSignal> {
        val raw = prefs.getString("records", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        RecordedSignal(
                            id = o.getLong("id"),
                            timestamp = o.getLong("timestamp"),
                            direction = o.getString("direction"),
                            score = o.getInt("score"),
                            confidence = o.getString("confidence"),
                            probability = o.optDouble("probability", 0.5),
                            entryPrice = if (o.isNull("entryPrice")) null else o.getDouble("entryPrice"),
                            expirySeconds = o.getInt("expirySeconds"),
                            regime = if (o.isNull("regime")) null else o.optString("regime", null),
                            exitPrice = if (o.isNull("exitPrice")) null else o.getDouble("exitPrice"),
                            outcome = Outcome.valueOf(o.getString("outcome"))
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }
}
