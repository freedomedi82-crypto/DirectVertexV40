# Direct Vertex V40 currently keeps release minification disabled for predictable builds.
# Add rules here only when release shrinking is enabled and verified on-device.
