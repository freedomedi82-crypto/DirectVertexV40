# V40 Build Checklist

1. Open this `DirectVertexV40` folder in Android Studio.
2. Use JDK 17 for Gradle/Android build.
3. Install Android SDK Platform 36 and Build Tools 36.x.
4. Sync Gradle.
5. Run `:app:assembleDebug`.
6. Install `app/build/outputs/apk/debug/app-debug.apk` on Android.
7. Grant Camera permission when the app starts.
8. Verify camera/chart analysis, manual RECORD CALL/PUT, replay import, and V40 OOS CSV import.
9. For release distribution, configure a developer-owned signing keystore.

The project intentionally does not automate Quotex order execution.
