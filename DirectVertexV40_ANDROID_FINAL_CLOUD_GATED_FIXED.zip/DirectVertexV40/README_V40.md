# DirectVertex V40 — Untouched Chronological OOS Audit

V40 adds a final-evidence audit harness around the precision-first V39 champion.

## Purpose
- chronological evaluation only;
- no shuffle;
- train/calibration/test separation per fold;
- configurable purge gap before each test window;
- test window is never used for threshold/parameter tuning;
- SHA-256 provenance hash of the canonical signal/outcome rows;
- Wilson 95% lower confidence bound;
- fold-level and aggregate verdict;
- PASS/FAIL/INCONCLUSIVE status instead of optimistic marketing metrics.

## Important
V40 evaluates recorded signal outcomes. It does **not** fabricate market history and it does not claim Quotex-specific OOS performance unless the supplied dataset is actually Quotex data.

The live application remains analysis/signal-only. It does not log in to Quotex, extract sessions, auto-click, or place orders.
