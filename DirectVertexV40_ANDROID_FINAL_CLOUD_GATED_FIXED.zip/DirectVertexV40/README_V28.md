# Direct Vertex V28.0

V28 adds strict walk-forward production verification for replay/research. The verifier separates training history from out-of-sample windows, checks timestamp integrity, and reports aggregate and fold-level performance. It is not a profit guarantee and does not execute orders.
