# DirectVertex V37 — Evidence Quality / Independence Gate

V37 is a conservative analysis-only layer added after V36.

## Why V37 exists

A large number of recorded signals does not necessarily mean a large amount of independent evidence. Camera-driven signal systems can emit multiple observations while one market move is still unfolding, and expiry windows can overlap. Counting every observation equally can make confidence intervals look artificially precise.

V37 therefore adds an **independence-adjusted evidence gate**:

- chronological clustering of settled outcomes;
- directional evidence separated from global evidence;
- empirical-Bayes shrinkage for small samples;
- capped regime contribution;
- recent independent evidence check;
- Wilson 95% lower bound;
- payout-aware required probability;
- explicit independence ratio in the audit output.

## Decision chain

V22 → V25 → V26 → V27 → V32 → V35 → V36 → **V37** → final CALL/PUT or WAIT.

V37 can only reject a candidate. It does not create a new trading direction.

## Important limitation

The independence gap is a conservative research heuristic, not a proof of statistical independence. Real validation still requires chronological, untouched out-of-sample testing on sufficiently long data. Forex data is not Quotex OTC data and must not be presented as such.

No login automation, session-token extraction, browser automation, order execution, or protection bypass is included.
