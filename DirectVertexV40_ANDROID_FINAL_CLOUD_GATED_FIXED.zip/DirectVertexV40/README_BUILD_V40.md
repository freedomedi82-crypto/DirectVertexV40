# Direct Vertex V40 — Build & Install

1. Open the `DirectVertexV40` folder in Android Studio.
2. Install Android SDK Platform 36 and Build Tools 36.0.0.
3. Use JDK 17 for the Gradle build.
4. Sync Gradle.
5. Run `:app:assembleDebug`.
6. Install `app/build/outputs/apk/debug/app-debug.apk` on an Android device.

For a reproducible clean build, run the included GitHub Actions workflow `Direct Vertex V40 Android Build`. It uploads the APK and SHA-256 checksum only after the APK file exists.

Do not put signing passwords or private keystores into source control.


### One-command verification

```bash
bash scripts/verify_v40.sh
./gradlew :app:assembleDebug
sha256sum app/build/outputs/apk/debug/app-debug.apk
```

For the most reproducible build, use the included GitHub Actions workflow `android-release.yml`, which pins JDK 17, Gradle 8.13, Android SDK 36, and Build Tools 35.0.0.
