# V34.1 — Research Integrity Upgrade + Proxy Audit Fixes

Tujuan V34 bukan mengejar angka win-rate tertinggi pada data yang sama, tetapi membuat hasil lebih sulit tertipu oleh leakage/overfitting.

### Perubahan utama
1. **V24 leakage-safe** — threshold dipilih di calibration slice, metrik dilaporkan pada test slice yang lebih baru.
2. **V25 leakage-safe** — native probability reliability memakai chronological calibration/test split.
3. **Wilson 95% CI** — setiap hasil thresholded punya batas ketidakpastian.
4. **V27 semantics fix** — cooldown yang tidak pernah diterapkan dihapus dari konfigurasi; session block dibuat eksplisit.
5. **V34WalkForwardQualityAudit** — lima fold rolling OOS, purge gap, fold stability, coverage, dan aggregate CI.

### Standar verdict
- `ROBUST`: semua fold cukup sampel, lower 95% CI tiap fold >= 50%, dan aggregate lower CI >= 50%.
- `PROMISING`: mayoritas fold lolos dan aggregate lower CI >= 48%.
- `FRAGILE`: tidak stabil / lower CI terlalu rendah.
- `INCONCLUSIVE`: sampel/fold belum cukup.

Semua audit ini research-only. Dataset OHLC publik bukan bukti bahwa model identik dengan visual camera/ML Kit atau harga Quotex OTC.


### V34.1 fixes
- Memperbaiki konstruksi `SonarSnapshot` pada audit OHLC dengan named arguments; V34.0 sebelumnya memiliki urutan argumen yang tidak sesuai tipe model.
- Menyamakan `redRatio/greenRatio`, `calibratedPrice`, boundary distances, dan timestamp dengan data OHLC yang sedang diuji.
- Audit tetap proxy OHLC; tidak boleh dipresentasikan sebagai hasil kamera/ML Kit atau Quotex OTC.
